-- Change the default Omarchy look'n'feel.

-- https://wiki.hypr.land/Configuring/Basics/Variables/#general
-- hl.config({
--   general = {
--     -- No gaps between windows or borders.
--     gaps_in = 0,
--     gaps_out = 0,
--     border_size = 0,
--
--     -- Change to niri-like side-scrolling layout.
--     layout = "scrolling",
--   },
-- })

-- https://wiki.hypr.land/Configuring/Basics/Variables/#decoration
hl.config({
  general = {
    gaps_in = 4,
    gaps_out = 8,
    border_size = 0,
    resize_on_border = true,
  },

  decoration = {
    rounding = 12,

    shadow = {
      enabled = true,
      range = 4,
      render_power = 2,
      color = "rgba(1a1a1aee)",
      color_inactive = "rgba(1a1a1aee)",
    },

    blur = {
      enabled = true,
      size = 6,
      passes = 2,
      noise = 0,
      new_optimizations = true,
      xray = false,
      vibrancy_darkness = 0.40,
      popups = true,
      popups_ignorealpha = 0.20,
      ignore_opacity = true,
    },
  },
})

-- HyprGlass' Apple Liquid Glass preset: refracted edges and a soft lit bevel
-- instead of a dark opaque overlay.
if hl.plugin.hyprglass then
  local hg = hl.plugin.hyprglass

  hg.config({
    enabled = true,
    manage_window_blur = true,
    skip_opaque_windows = true,
    default_theme = "dark",
    default_preset = "pomme",
    layers = {
      enabled = true,
    },
  })
end

-- Give terminals a translucent glass surface without changing other apps.
o.window({ tag = "terminal" }, { opacity = "0.80 0.60" })

-- https://wiki.hypr.land/Configuring/Basics/Variables/#animations
-- hl.config({
--   animations = {
--     -- Disable all animations.
--     enabled = false,
--   },
-- })

-- https://wiki.hypr.land/Configuring/Basics/Variables/#layout
-- hl.config({
--   layout = {
--     -- Avoid overly wide single-window layouts on wide screens.
--     single_window_aspect_ratio = { 1, 1 },
--   },
-- })

-- https://wiki.hypr.land/Configuring/Layouts/Scrolling-Layout/
-- hl.config({
--   scrolling = {
--     -- See only one column per screen instead of two.
--     column_width = 0.97,
--   },
-- })
