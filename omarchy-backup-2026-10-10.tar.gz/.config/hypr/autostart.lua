-- Extra autostart processes.
-- o.launch_on_start("my-service")

-- HyprPM persists enabled plugins but loads them after Hyprland starts.
-- Reload once more so the guarded HyprGlass configuration is applied.
o.exec_on_start("hyprpm reload && hyprctl reload")
