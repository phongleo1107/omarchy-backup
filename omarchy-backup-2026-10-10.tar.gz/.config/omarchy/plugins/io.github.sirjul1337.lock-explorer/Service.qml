import QtQuick
import Quickshell
import Quickshell.Io
import Quickshell.Services.Pam
import Quickshell.Wayland
import qs.Commons
import "Designs.js" as Designs
import "DisplayPower.js" as DisplayPower
import "Bridge.js" as Bridge
import "designs/Strings.js" as Strings

Item {
  id: root

  property var shell: null
  property var manifest: null
  property string omarchyPath: ""

  LocalSettings { id: localSettings; pluginId: root.pluginId }
  readonly property var settingsConfig: shell && shell.shellConfig
    ? shell.shellConfig : localSettings.config

  // selected design lives on this plugin's entry in shell.json
  readonly property string pluginId: manifest && manifest.id ? String(manifest.id) : "io.github.sirjul1337.lock-explorer"
  property string designOverride: ""
  readonly property string configuredDesignId: {
    var cfg = root.settingsConfig
    var list = cfg && Array.isArray(cfg.plugins) ? cfg.plugins : []
    for (var i = 0; i < list.length; i++) {
      var entry = list[i]
      if (entry && String(entry.id || "") === pluginId && entry.design) return String(entry.design)
    }
    return Designs.DEFAULT_ID
  }
  readonly property string designId: designOverride.length > 0 ? designOverride : configuredDesignId
  readonly property bool designHasClip: {
    var r = designsRevision
    var d = Designs.byId(designId)
    return !!(d && d.clip)
  }
  // The video file behind the current clip design; user ClipDesigns get their
  // clipFile filled in by the lock-designs scan.
  readonly property string designClipPath: {
    var r = designsRevision
    var d = Designs.byId(designId)
    if (!d || !d.clip || !d.clipFile) return ""
    return home + "/.config/omarchy/lock-videos/" + d.clipFile
  }

  // "all" or an output name (see `omarchy-shell lock monitors`). Other
  // monitors get the companion screen.
  property string inputMonitorOverride: ""
  readonly property string configuredInputMonitor: {
    var cfg = root.settingsConfig
    var list = cfg && Array.isArray(cfg.plugins) ? cfg.plugins : []
    for (var i = 0; i < list.length; i++) {
      var entry = list[i]
      if (entry && String(entry.id || "") === pluginId && entry.inputMonitor) return String(entry.inputMonitor)
    }
    return "all"
  }
  readonly property string inputMonitor: inputMonitorOverride.length > 0 ? inputMonitorOverride : configuredInputMonitor

  // How the lock screen leaves the screen when the password checks out. Off by
  // default, the unlock stays instant until it is turned on. Saved on the
  // plugin entry as `unlock` and `unlockMs`.
  readonly property var unlockAnimations: ["fade", "zoom", "rise", "none"]
  readonly property int defaultUnlockDuration: 400
  property string unlockOverride: ""
  property int unlockDurationOverride: -1
  readonly property string configuredUnlock: {
    var cfg = root.settingsConfig
    var list = cfg && Array.isArray(cfg.plugins) ? cfg.plugins : []
    for (var i = 0; i < list.length; i++) {
      var entry = list[i]
      if (entry && String(entry.id || "") === pluginId && entry.unlock) return String(entry.unlock)
    }
    return "none"
  }
  readonly property int configuredUnlockDuration: {
    var cfg = root.settingsConfig
    var list = cfg && Array.isArray(cfg.plugins) ? cfg.plugins : []
    for (var i = 0; i < list.length; i++) {
      var entry = list[i]
      if (entry && String(entry.id || "") === pluginId && entry.unlockMs !== undefined)
        return Math.max(0, Math.min(2000, Number(entry.unlockMs) || 0))
    }
    return defaultUnlockDuration
  }
  readonly property string unlockAnimation: {
    var value = unlockOverride.length > 0 ? unlockOverride : configuredUnlock
    return unlockAnimations.indexOf(value) === -1 ? "none" : value
  }
  readonly property int unlockDuration: unlockDurationOverride >= 0 ? unlockDurationOverride : configuredUnlockDuration
  readonly property bool unlockAnimated: unlockAnimation !== "none" && unlockDuration > 0

  // How long the unlock screen stays lit before the display is blanked. The
  // session is locked before every suspend, so on a machine that sleeps this
  // delay is what the user sees on resume: too short and the screen goes dark
  // before there is time to type. Saved on the plugin entry as `blankMs`.
  readonly property int defaultBlankDelay: 5000
  property int blankDelayOverride: -1
  readonly property int configuredBlankDelay: {
    var cfg = root.settingsConfig
    var list = cfg && Array.isArray(cfg.plugins) ? cfg.plugins : []
    for (var i = 0; i < list.length; i++) {
      var entry = list[i]
      if (entry && String(entry.id || "") === pluginId && entry.blankMs !== undefined)
        return Math.max(1000, Math.min(3600000, Number(entry.blankMs) || defaultBlankDelay))
    }
    return defaultBlankDelay
  }
  readonly property int blankDelay: blankDelayOverride >= 0 ? blankDelayOverride : configuredBlankDelay

  // How long after the wake has run the password field stays inert, so the
  // keys that lit a dark panel do not land in the password. Nothing reports a
  // panel as physically lit, so this is the allowance for one to come up; 0
  // drops only the keys pressed before the wake ran. Saved on the plugin entry
  // as `wakeGraceMs`.
  readonly property int defaultWakeGrace: 1000
  readonly property int maxWakeGrace: 5000
  property int wakeGraceOverride: -1
  readonly property int configuredWakeGrace: {
    var cfg = root.settingsConfig
    var list = cfg && Array.isArray(cfg.plugins) ? cfg.plugins : []
    for (var i = 0; i < list.length; i++) {
      var entry = list[i]
      if (entry && String(entry.id || "") === pluginId && entry.wakeGraceMs !== undefined)
        return Math.max(0, Math.min(maxWakeGrace, Number(entry.wakeGraceMs) || 0))
    }
    return defaultWakeGrace
  }
  readonly property int wakeInputGrace: wakeGraceOverride >= 0 ? wakeGraceOverride : configuredWakeGrace

  // When face unlock starts scanning on its own. "wake" (the default) scans
  // when a blanked or sleeping panel comes back -- a lid opened, a key
  // pressed -- but not when the screen is locked while you are sitting in
  // front of it, which would recognise you and unlock again. "always" scans
  // as soon as the session locks, "off" leaves it to Enter on an empty field
  // or the face button. Saved on the plugin entry as `faceStart`.
  readonly property string defaultFaceStart: "wake"
  readonly property var faceStartOptions: ["always", "wake", "off"]
  property string faceStartOverride: ""
  readonly property string configuredFaceStart: {
    var cfg = root.settingsConfig
    var list = cfg && Array.isArray(cfg.plugins) ? cfg.plugins : []
    for (var i = 0; i < list.length; i++) {
      var entry = list[i]
      if (entry && String(entry.id || "") === pluginId && entry.faceStart !== undefined) {
        var value = String(entry.faceStart)
        if (faceStartOptions.indexOf(value) !== -1) return value
      }
    }
    return defaultFaceStart
  }
  readonly property string faceStart: faceStartOverride.length > 0 ? faceStartOverride : configuredFaceStart
  // "wake" needs a moment that says somebody came back. A panel powering on
  // is the clear one, but a screen that never blanks (the keep-lit option, or
  // hardware the display-power helper cannot drive) has none -- so an
  // interaction a while after the lock counts too. The delay keeps the lock
  // you just asked for from scanning the face still sitting in front of it.
  readonly property int faceWakeQuiet: 15000
  readonly property int faceRoundGap: 10000
  property real lockedAt: 0
  property real lastFaceRound: 0

  // Sleep, restart and shut down from the lock screen. Off by default: a
  // locked machine anyone can reboot is a different trade than a locked
  // machine that only takes a password, and that is the owner's call. Saved
  // on the plugin entry as `powerActions`.
  property int powerActionsOverride: -1
  readonly property bool configuredPowerActions: {
    var cfg = root.settingsConfig
    var list = cfg && Array.isArray(cfg.plugins) ? cfg.plugins : []
    for (var i = 0; i < list.length; i++) {
      var entry = list[i]
      if (entry && String(entry.id || "") === pluginId) return entry.powerActions === true
    }
    return false
  }
  readonly property bool powerActions: powerActionsOverride >= 0 ? powerActionsOverride === 1 : configuredPowerActions

  // Omarchy's own commands, so a lock screen reboot is the reboot the menu
  // does. Nothing here runs without the setting on and a second click.
  function runPowerAction(action) {
    if (!powerActions) return false
    if (action === "suspend") Quickshell.execDetached(["systemctl", "suspend"])
    else if (action === "reboot") Quickshell.execDetached(["omarchy-system-reboot"])
    else if (action === "shutdown") Quickshell.execDetached(["omarchy-system-shutdown"])
    else return false
    logEvent("power-action=" + action)
    return true
  }

  // When true the display stays powered while locked: the DPMS-off is skipped
  // entirely, so video designs keep playing and slow monitors are never
  // re-blanked. Takes precedence over blankDelay. Lives on the plugin entry
  // in shell.json.
  property int keepDisplayOnOverride: -1
  readonly property bool configuredKeepDisplayOn: {
    var cfg = root.settingsConfig
    var list = cfg && Array.isArray(cfg.plugins) ? cfg.plugins : []
    for (var i = 0; i < list.length; i++) {
      var entry = list[i]
      if (entry && String(entry.id || "") === pluginId) return entry.keepDisplayOn === true
    }
    return false
  }
  readonly property bool keepDisplayOn: keepDisplayOnOverride >= 0 ? keepDisplayOnOverride === 1 : configuredKeepDisplayOn

  // Some monitors drop off the bus when DPMS turns them off (a lone DisplayPort
  // panel on NVIDIA, issue #34). With no output left while the session lock is
  // held the shell dies, relaunches, recovers the stranded lock and blanks
  // again -- a loop for as long as the session stays locked. The blank leaves
  // a marker in the runtime dir that the wake removes, so a shell that starts
  // up and finds it knows its predecessor died with the display off, and
  // keeps the displays lit for the rest of this login instead.
  readonly property string blankMarkerDir: (Quickshell.env("XDG_RUNTIME_DIR") || "/tmp") + "/omarchy-lock-explorer"
  property bool blankCrashed: false

  // Opt-in HDMI workaround; Never still applies independently on every setup.
  readonly property bool displayBlankingSuppressed: keepDisplayOn || blankCrashed || DisplayPower.keepDisplaysOn(
    root.settingsConfig, pluginId, Quickshell.screens)
  onDisplayBlankingSuppressedChanged: {
    // The one-shot blank timer may already have fired while HDMI was present.
    // Start a fresh delay on disconnect (or when the option is turned off).
    if (lockRequested && !displayBlankingSuppressed) armBlankTimer()
  }

  // Avatar picture for the designs that show the user. The chosen path lives on
  // the plugin entry in shell.json; "none" there means the user cleared it and
  // wants the initial back, an empty setting falls back to the usual dotfiles.
  property string avatarOverride: ""
  readonly property string configuredAvatar: {
    var cfg = root.settingsConfig
    var list = cfg && Array.isArray(cfg.plugins) ? cfg.plugins : []
    for (var i = 0; i < list.length; i++) {
      var entry = list[i]
      if (entry && String(entry.id || "") === pluginId && entry.avatar) return String(entry.avatar)
    }
    return ""
  }
  property string detectedAvatar: ""
  property int avatarVersion: 0
  readonly property string avatarSetting: avatarOverride.length > 0 ? avatarOverride : configuredAvatar
  readonly property string avatarPath: avatarSetting === "none" ? ""
    : (avatarSetting.length > 0 ? avatarSetting : detectedAvatar)
  readonly property string avatarUrl: {
    if (avatarPath.length === 0) return ""
    var encoded = String(avatarPath).split("/").map(encodeURIComponent).join("/")
    return "file://" + encoded + "?v=" + avatarVersion
  }

  // A looping video for the designs that show one (Motion), and a clip that
  // plays over the desktop right after the password checks out. Both live on
  // the plugin entry in shell.json, as `video` and `sting`; "none" there means
  // it was cleared on purpose.
  property string videoOverride: ""
  readonly property string configuredVideo: {
    var cfg = root.settingsConfig
    var list = cfg && Array.isArray(cfg.plugins) ? cfg.plugins : []
    for (var i = 0; i < list.length; i++) {
      var entry = list[i]
      if (entry && String(entry.id || "") === pluginId && entry.video) return String(entry.video)
    }
    return ""
  }
  readonly property string videoSetting: videoOverride.length > 0 ? videoOverride : configuredVideo
  readonly property string videoPath: videoSetting === "none" ? "" : videoSetting

  property string stingOverride: ""
  readonly property string configuredSting: {
    var cfg = root.settingsConfig
    var list = cfg && Array.isArray(cfg.plugins) ? cfg.plugins : []
    for (var i = 0; i < list.length; i++) {
      var entry = list[i]
      if (entry && String(entry.id || "") === pluginId && entry.sting) return String(entry.sting)
    }
    return ""
  }
  readonly property string stingSetting: stingOverride.length > 0 ? stingOverride : configuredSting
  readonly property string stingPath: stingSetting === "none" ? "" : stingSetting
  readonly property string stingUrl: {
    if (stingPath.length === 0) return ""
    var encoded = String(stingPath).split("/").map(encodeURIComponent).join("/")
    return "file://" + encoded
  }

  property int stingVolumeOverride: -1
  readonly property int configuredStingVolume: {
    var cfg = root.settingsConfig
    var list = cfg && Array.isArray(cfg.plugins) ? cfg.plugins : []
    for (var i = 0; i < list.length; i++) {
      var entry = list[i]
      if (entry && String(entry.id || "") === pluginId && entry.stingVolume !== undefined)
        return Math.max(0, Math.min(100, Number(entry.stingVolume) || 0))
    }
    return 0
  }
  readonly property int stingVolume: stingVolumeOverride >= 0 ? stingVolumeOverride : configuredStingVolume

  // How fast unlock clips play, 1.0 is natural speed. Applies to the clip
  // designs and the separate unlock clip. Saved on the plugin entry as
  // `clipSpeed` when it is not 1.
  property real clipSpeedOverride: -1
  readonly property real configuredClipSpeed: {
    var cfg = root.settingsConfig
    var list = cfg && Array.isArray(cfg.plugins) ? cfg.plugins : []
    for (var i = 0; i < list.length; i++) {
      var entry = list[i]
      if (entry && String(entry.id || "") === pluginId && entry.clipSpeed !== undefined) {
        var v = Number(entry.clipSpeed)
        if (isFinite(v) && v > 0) return Math.max(0.25, Math.min(4, v))
      }
    }
    return 1
  }
  readonly property real clipSpeed: clipSpeedOverride > 0 ? clipSpeedOverride : configuredClipSpeed

  function setClipSpeed(v) {
    var speed = Number(v)
    if (!isFinite(speed) || speed <= 0) return false
    speed = Math.max(0.25, Math.min(4, speed))
    clipSpeedOverride = speed
    if (shell && typeof shell.updateEntryInline === "function") {
      var current = pluginEntry()
      if (speed === 1) delete current.clipSpeed
      else current.clipSpeed = speed
      writeEntry(current)
    }
    logEvent("clip-speed=" + speed)
    return true
  }

  // 24-hour clocks by default; on, every design's clock reads 12-hour with
  // AM/PM. Saved on the plugin entry as `clock12` only when it is on, so a
  // 24-hour setup keeps the entry it always had.
  property int twelveHourOverride: -1
  readonly property bool configuredTwelveHour: {
    var cfg = root.settingsConfig
    var list = cfg && Array.isArray(cfg.plugins) ? cfg.plugins : []
    for (var i = 0; i < list.length; i++) {
      var entry = list[i]
      if (entry && String(entry.id || "") === pluginId && entry.clock12 !== undefined)
        return entry.clock12 === true || String(entry.clock12) === "true"
    }
    return false
  }
  readonly property bool twelveHour: twelveHourOverride >= 0 ? twelveHourOverride === 1 : configuredTwelveHour

  function setTwelveHour(v) {
    var on = v === true || v === 1 || v === "true" || v === "12" || v === "on"
    twelveHourOverride = on ? 1 : 0
    if (shell && typeof shell.updateEntryInline === "function") {
      var current = pluginEntry()
      if (on) current.clock12 = true
      else delete current.clock12
      writeEntry(current)
    }
    logEvent("clock=" + (on ? "12h" : "24h"))
    return true
  }

  // After an unlock, a notification for the failed attempts made while you
  // were away. On by default: it says nothing unless somebody tried. Saved on
  // the plugin entry as `awayReportOff` only when it is turned off.
  property int awayReportOverride: -1
  readonly property bool configuredAwayReport: {
    var cfg = root.settingsConfig
    var list = cfg && Array.isArray(cfg.plugins) ? cfg.plugins : []
    for (var i = 0; i < list.length; i++) {
      var entry = list[i]
      if (entry && String(entry.id || "") === pluginId && entry.awayReportOff !== undefined)
        return !(entry.awayReportOff === true || String(entry.awayReportOff) === "true")
    }
    return true
  }
  readonly property bool awayReport: awayReportOverride >= 0 ? awayReportOverride === 1 : configuredAwayReport

  // Both off by default. Pulling the security key out locks the session, and
  // plugging it in lights a blanked lock screen ready for a touch. Saved on
  // the plugin entry as `lockOnKeyRemoval` and `wakeOnKeyInsert`, only when on.
  property int lockOnKeyRemovalOverride: -1
  readonly property bool configuredLockOnKeyRemoval: pluginFlag("lockOnKeyRemoval")
  readonly property bool lockOnKeyRemoval: lockOnKeyRemovalOverride >= 0 ? lockOnKeyRemovalOverride === 1 : configuredLockOnKeyRemoval
  property int wakeOnKeyInsertOverride: -1
  readonly property bool configuredWakeOnKeyInsert: pluginFlag("wakeOnKeyInsert")
  readonly property bool wakeOnKeyInsert: wakeOnKeyInsertOverride >= 0 ? wakeOnKeyInsertOverride === 1 : configuredWakeOnKeyInsert

  function pluginFlag(name) {
    var cfg = root.settingsConfig
    var list = cfg && Array.isArray(cfg.plugins) ? cfg.plugins : []
    for (var i = 0; i < list.length; i++) {
      var entry = list[i]
      if (entry && String(entry.id || "") === pluginId) return entry[name] === true
    }
    return false
  }

  function setPluginFlag(name, value) {
    var on = value === true || value === "true" || value === 1 || value === "1" || value === "on"
    var off = value === false || value === "false" || value === 0 || value === "0" || value === "off"
    if (!on && !off) return false
    if (name === "lockOnKeyRemoval") lockOnKeyRemovalOverride = on ? 1 : 0
    else if (name === "wakeOnKeyInsert") wakeOnKeyInsertOverride = on ? 1 : 0
    else return false
    if (shell && typeof shell.updateEntryInline === "function") {
      var current = pluginEntry()
      if (on) current[name] = true
      else delete current[name]
      writeEntry(current)
    }
    logEvent(name + "=" + (on ? "on" : "off"))
    return true
  }

  function setLockOnKeyRemoval(value) { return setPluginFlag("lockOnKeyRemoval", value) }
  function setWakeOnKeyInsert(value) { return setPluginFlag("wakeOnKeyInsert", value) }

  function setAwayReport(value) {
    var on = value === true || value === "true" || value === 1 || value === "1" || value === "on"
    var off = value === false || value === "false" || value === 0 || value === "0" || value === "off"
    if (!on && !off) return false

    awayReportOverride = on ? 1 : 0
    if (shell && typeof shell.updateEntryInline === "function") {
      var current = pluginEntry()
      if (on) delete current.awayReportOff
      else current.awayReportOff = true
      writeEntry(current)
    }
    logEvent("away-report=" + (on ? "on" : "off"))
    return true
  }

  // When each failed attempt of this lock happened. The ones that run into
  // the unlock, each within awayGapMs of the next, are the person unlocking
  // getting it wrong on the way in; anything before that is reported.
  readonly property int awayGapMs: 30000
  property var failureTimes: []
  property var pendingAwayReport: null

  function awayFailures(unlockAt) {
    var times = failureTimes.slice()
    var edge = unlockAt
    while (times.length > 0 && edge - times[times.length - 1] <= awayGapMs)
      edge = times.pop()
    return times
  }

  function sendAwayReport(times) {
    var count = times.length
    var last = new Date(times[count - 1])
    var today = new Date()
    var locale = Qt.locale(Strings.localeName(language))
    var clock = last.toLocaleString(locale, twelveHour ? "h:mm AP" : "HH:mm")
    var when = last.toDateString() === today.toDateString() ? clock : last.toLocaleString(locale, "ddd") + " " + clock
    var summary = count === 1 ? t("1 failed attempt to unlock") : t("%1 failed attempts to unlock").arg(count)
    Quickshell.execDetached(["notify-send", "-a", t("Lock screen"), summary,
                             t("While the screen was locked, the last at %1").arg(when)])
    logEvent("away-report count=" + count)
  }

  // Designs starred with F in the explorer, listed under Favorites. Saved on
  // the plugin entry as `favorites`, a list of design ids, only once there is
  // one; ids of designs that no longer exist are kept and simply not shown.
  property var favoritesOverride: null
  readonly property var configuredFavorites: {
    var cfg = root.settingsConfig
    var list = cfg && Array.isArray(cfg.plugins) ? cfg.plugins : []
    for (var i = 0; i < list.length; i++) {
      var entry = list[i]
      if (entry && String(entry.id || "") === pluginId && Array.isArray(entry.favorites))
        return entry.favorites.map(function(id) { return String(id) })
    }
    return []
  }
  readonly property var favorites: favoritesOverride !== null ? favoritesOverride : configuredFavorites

  function setFavorite(id, on) {
    var key = String(id || "")
    if (key.length === 0 || !Designs.byId(key)) return false
    var next = favorites.filter(function(f) { return f !== key })
    if (on) next.push(key)
    favoritesOverride = next
    if (shell && typeof shell.updateEntryInline === "function") {
      var current = pluginEntry()
      if (next.length > 0) current.favorites = next
      else delete current.favorites
      writeEntry(current)
    }
    logEvent("favorite " + key + "=" + (on ? "on" : "off"))
    return true
  }

  function toggleFavorite(id) {
    return setFavorite(id, favorites.indexOf(String(id || "")) === -1)
  }

  // What the password field shows beside the text, each shown unless hidden
  // in Settings. Saved on the plugin entry as hideLayoutBadge, hideCapsBadge,
  // hidePasswordToggle and hideAuthIcons, and only while hidden.
  readonly property var fieldItems: ({ layout: "hideLayoutBadge", caps: "hideCapsBadge",
                                       reveal: "hidePasswordToggle", icons: "hideAuthIcons" })
  property var fieldItemOverrides: ({})
  function fieldItemHidden(key) {
    if (fieldItemOverrides[key] !== undefined) return fieldItemOverrides[key]
    var cfg = root.settingsConfig
    var list = cfg && Array.isArray(cfg.plugins) ? cfg.plugins : []
    for (var i = 0; i < list.length; i++) {
      var entry = list[i]
      if (entry && String(entry.id || "") === pluginId) return entry[key] === true
    }
    return false
  }
  readonly property bool showLayoutBadge: !fieldItemHidden("hideLayoutBadge")
  readonly property bool showCapsBadge: !fieldItemHidden("hideCapsBadge")
  readonly property bool allowPasswordToggle: !fieldItemHidden("hidePasswordToggle")
  readonly property bool showAuthIcons: !fieldItemHidden("hideAuthIcons")

  function setFieldItem(name, show) {
    var key = fieldItems[String(name || "")]
    if (!key) return false
    var on = show === true || show === "true" || show === "on" || show === "show" || show === 1
    var next = {}
    for (var k in fieldItemOverrides) next[k] = fieldItemOverrides[k]
    next[key] = !on
    fieldItemOverrides = next
    if (shell && typeof shell.updateEntryInline === "function") {
      var current = pluginEntry()
      if (on) delete current[key]
      else current[key] = true
      writeEntry(current)
    }
    logEvent("field-" + name + "=" + (on ? "show" : "hide"))
    return true
  }

  // The lock screen's language: the system's (LANG, through Qt.locale()) when
  // Strings.js has it, English otherwise, or one picked in Settings. Saved on
  // the plugin entry as `language` only once it is picked.
  readonly property var languages: Strings.LANGUAGES
  readonly property string systemLanguage: Strings.fromLocale(Qt.locale().name)
  property string languageOverride: ""
  readonly property string configuredLanguage: {
    var cfg = root.settingsConfig
    var list = cfg && Array.isArray(cfg.plugins) ? cfg.plugins : []
    for (var i = 0; i < list.length; i++) {
      var entry = list[i]
      if (entry && String(entry.id || "") === pluginId && entry.language !== undefined && Strings.known(String(entry.language)))
        return String(entry.language)
    }
    return "auto"
  }
  readonly property string languageSetting: languageOverride.length > 0 ? languageOverride : configuredLanguage
  readonly property string language: languageSetting === "auto" ? systemLanguage : languageSetting
  function t(text) { return Strings.tr(language, text) }

  function setLanguage(value) {
    var text = String(value === undefined ? "" : value).trim().toLowerCase()
    if (text !== "auto") text = text === "no" || text === "nn" ? "nb" : text
    if (text !== "auto" && !Strings.known(text)) return false
    languageOverride = text
    if (shell && typeof shell.updateEntryInline === "function") {
      var current = pluginEntry()
      if (text === "auto") delete current.language
      else current.language = text
      writeEntry(current)
    }
    logEvent("language=" + text)
    return true
  }

  // Reduce motion: off, on, or only while on battery. Size: how much larger
  // than the design drew itself the lock screen is shown. Both are applied by
  // LockHost to every design, and saved on the plugin entry as `reduceMotion`
  // and `uiScale` only once they are changed.
  readonly property var reduceMotionOptions: ["off", "on", "battery"]
  readonly property var uiScaleOptions: [1, 1.25, 1.5]
  property string reduceMotionOverride: ""
  property real uiScaleOverride: 0
  readonly property string configuredReduceMotion: {
    var cfg = root.settingsConfig
    var list = cfg && Array.isArray(cfg.plugins) ? cfg.plugins : []
    for (var i = 0; i < list.length; i++) {
      var entry = list[i]
      if (entry && String(entry.id || "") === pluginId && reduceMotionOptions.indexOf(String(entry.reduceMotion)) !== -1)
        return String(entry.reduceMotion)
    }
    return "off"
  }
  readonly property real configuredUiScale: {
    var cfg = root.settingsConfig
    var list = cfg && Array.isArray(cfg.plugins) ? cfg.plugins : []
    for (var i = 0; i < list.length; i++) {
      var entry = list[i]
      if (entry && String(entry.id || "") === pluginId && uiScaleOptions.indexOf(Number(entry.uiScale)) !== -1)
        return Number(entry.uiScale)
    }
    return 1
  }
  readonly property string reduceMotion: reduceMotionOverride.length > 0 ? reduceMotionOverride : configuredReduceMotion
  readonly property real uiScale: uiScaleOverride > 0 ? uiScaleOverride : configuredUiScale
  readonly property bool onBattery: powerState.item ? powerState.item.onBattery === true : false
  // A battery running down while the screen is locked is easy to miss: the
  // lock screen says so at this level or below, on every design, while the
  // machine is not charging.
  readonly property int batteryLowAt: 15
  readonly property int batteryPercent: powerState.item ? powerState.item.percent : -1
  readonly property bool batteryLow: onBattery && batteryPercent >= 0 && batteryPercent <= batteryLowAt
  readonly property bool motionReduced: reduceMotion === "on" || (reduceMotion === "battery" && onBattery)

  Loader {
    id: powerState
    source: "PowerState.qml"
  }

  function setReduceMotion(value) {
    var text = String(value === undefined ? "" : value).trim().toLowerCase()
    if (text === "true" || text === "1") text = "on"
    if (text === "false" || text === "0") text = "off"
    if (reduceMotionOptions.indexOf(text) === -1) return false
    reduceMotionOverride = text
    if (shell && typeof shell.updateEntryInline === "function") {
      var current = pluginEntry()
      if (text === "off") delete current.reduceMotion
      else current.reduceMotion = text
      writeEntry(current)
    }
    logEvent("reduce-motion=" + text)
    return true
  }

  function setUiScale(value) {
    var text = String(value === undefined ? "" : value).trim().replace(/%$/, "")
    var n = Number(text)
    if (n >= 50) n = n / 100
    if (uiScaleOptions.indexOf(n) === -1) return false
    uiScaleOverride = n
    if (shell && typeof shell.updateEntryInline === "function") {
      var current = pluginEntry()
      if (n === 1) delete current.uiScale
      else current.uiScale = n
      writeEntry(current)
    }
    logEvent("ui-scale=" + n)
    return true
  }

  // How the wallpaper behind a design looks. Blur replaces the design's own
  // (sharp, soft or heavy); dim moves the design's own up or down, since some
  // designs darken the picture a lot to keep their text readable and one
  // value for all of them would undo that. "design" leaves both alone and is
  // not written, so the entry only gets `wallpaperBlur` / `wallpaperDim` once
  // they are changed.
  readonly property var wallpaperBlurOptions: ({ design: -1, sharp: 0, soft: 0.45, heavy: 1 })
  readonly property var wallpaperDimOptions: ({ design: 0, lighter: -0.15, darker: 0.2 })
  property string wallpaperBlurOverride: ""
  property string wallpaperDimOverride: ""
  function configuredWallpaperOption(key, options) {
    var cfg = root.settingsConfig
    var list = cfg && Array.isArray(cfg.plugins) ? cfg.plugins : []
    for (var i = 0; i < list.length; i++) {
      var entry = list[i]
      if (entry && String(entry.id || "") === pluginId && options[String(entry[key])] !== undefined)
        return String(entry[key])
    }
    return "design"
  }
  readonly property string wallpaperBlur: wallpaperBlurOverride.length > 0 ? wallpaperBlurOverride
                                                                           : configuredWallpaperOption("wallpaperBlur", wallpaperBlurOptions)
  readonly property string wallpaperDim: wallpaperDimOverride.length > 0 ? wallpaperDimOverride
                                                                         : configuredWallpaperOption("wallpaperDim", wallpaperDimOptions)
  readonly property real wallpaperBlurValue: wallpaperBlurOptions[wallpaperBlur]
  readonly property real wallpaperDimShift: wallpaperDimOptions[wallpaperDim]

  function setWallpaperOption(key, value, options) {
    var text = String(value === undefined ? "" : value).trim().toLowerCase()
    if (options[text] === undefined) return false
    if (key === "wallpaperBlur") wallpaperBlurOverride = text
    else wallpaperDimOverride = text
    if (shell && typeof shell.updateEntryInline === "function") {
      var current = pluginEntry()
      if (text === "design") delete current[key]
      else current[key] = text
      writeEntry(current)
    }
    logEvent(key + "=" + text)
    return true
  }
  function setWallpaperBlur(value) { return setWallpaperOption("wallpaperBlur", value, wallpaperBlurOptions) }
  function setWallpaperDim(value) { return setWallpaperOption("wallpaperDim", value, wallpaperDimOptions) }

  // Security-key unlock, on whenever a key is set up. Saved on the plugin
  // entry as `fido2Off` only when it is turned off, so a setup that never
  // touches this keeps the entry it always had.
  property int fido2EnabledOverride: -1
  readonly property bool configuredFido2Enabled: {
    var cfg = root.settingsConfig
    var list = cfg && Array.isArray(cfg.plugins) ? cfg.plugins : []
    for (var i = 0; i < list.length; i++) {
      var entry = list[i]
      if (entry && String(entry.id || "") === pluginId && entry.fido2Off !== undefined)
        return !(entry.fido2Off === true || String(entry.fido2Off) === "true")
    }
    return true
  }
  readonly property bool fido2Enabled: fido2EnabledOverride >= 0 ? fido2EnabledOverride === 1 : configuredFido2Enabled

  function setFido2Enabled(v) {
    var on = v === true || v === 1 || v === "true" || v === "on"
    fido2EnabledOverride = on ? 1 : 0
    if (shell && typeof shell.updateEntryInline === "function") {
      var current = pluginEntry()
      if (on) delete current.fido2Off
      else current.fido2Off = true
      writeEntry(current)
    }
    // Turning it off mid-lock hands the screen back to the password.
    if (!on && fido2Active) setAuthMode("password")
    logEvent("fido2=" + (on ? "on" : "off"))
    return true
  }

  readonly property string backgroundUrl: {
    if (backgroundPath.length === 0) return ""
    var encoded = String(backgroundPath).split("/").map(encodeURIComponent).join("/")
    return "file://" + encoded + "?v=" + backgroundVersion
  }

  function showsInput(screen) {
    if (inputMonitor === "all" || !screen) return true
    var names = []
    var screens = Quickshell.screens || []
    for (var i = 0; i < screens.length; i++) if (screens[i] && screens[i].name) names.push(screens[i].name)
    if (names.indexOf(inputMonitor) === -1) return true
    return screen.name === inputMonitor
  }

  function pluginEntry() {
    var cfg = root.settingsConfig
    var list = cfg && Array.isArray(cfg.plugins) ? cfg.plugins : []
    for (var i = 0; i < list.length; i++)
      if (list[i] && String(list[i].id || "") === pluginId) return Util.cloneJson(list[i])
    return {}
  }

  // Every setting is saved read-modify-write on this plugin's entry, and the
  // host replaces the entry with what it is handed. The write-through copy in
  // LocalSettings is what keeps two changes made back to back from clobbering
  // each other while the file watcher catches up.
  function writeEntry(entry) {
    localSettings.remember(entry)
    saveSettingsBackup(entry)
    return shell.updateEntryInline(pluginId, entry)
  }

  // A copy of these settings outside ~/.config/omarchy/plugins/. Omarchy drops
  // a plugin's entry from shell.json when the plugin is removed, so removing
  // and adding it again -- the usual way out of a broken install -- started
  // over from every default. Every write is mirrored here, and at startup an
  // entry with no settings left takes them back from the copy. The copy always
  // matches the last write, so settings put back to their defaults stay that
  // way; deleting the file is how to really start over.
  readonly property string settingsBackupPath: home + "/.config/omarchy/lock-explorer.json"
  // Keys Omarchy keeps on the entry for itself.
  readonly property var hostEntryKeys: ["id", "enabled"]
  property bool settingsRestoreChecked: false
  // The copy is a few hundred bytes of settings; anything bigger is not it.
  readonly property int settingsCopyMaxBytes: 65536

  // Writes only. The file is the user's to edit or replace with anything, and
  // a FileView loads whatever sits at its path: a FIFO would stall the shell
  // and an oversized file would sit in its memory. Reads go through
  // settingsCopyRead, which checks the file before handing it over.
  FileView {
    id: settingsBackup
    path: root.settingsBackupPath
    preload: false
    atomicWrites: true
    printErrors: false
  }

  function settingKeys(entry) {
    return Object.keys(entry || {}).filter(function(k) { return hostEntryKeys.indexOf(k) === -1 })
  }

  function saveSettingsBackup(entry) {
    var copy = {}
    settingKeys(entry).forEach(function(k) { copy[k] = entry[k] })
    settingsBackup.setText(JSON.stringify(copy, null, 2) + "\n")
  }

  // Exit 0 with the file on stdout, 1 when there is nothing at the path,
  // 2 when what is there is not a plain file (a symlink or FIFO included),
  // 3 when it is over the cap. The cap bounds the read as well as the
  // check, so a file growing in between still cannot get past it.
  Process {
    id: settingsCopyRead
    command: ["bash", "-c",
      "f=$1; max=$2; " +
      "[ -e \"$f\" ] || [ -L \"$f\" ] || exit 1; " +
      "[ -f \"$f\" ] && [ ! -L \"$f\" ] || exit 2; " +
      "[ \"$(stat -c %s -- \"$f\")\" -le \"$max\" ] || exit 3; " +
      "head -c \"$max\" -- \"$f\"",
      "bash", root.settingsBackupPath, String(root.settingsCopyMaxBytes)]
    stdout: StdioCollector { id: settingsCopyOut; waitForEnd: true }
    onExited: function(exitCode) { root.applySettingsCopy(exitCode, String(settingsCopyOut.text || "")) }
  }

  function restoreSettings() {
    if (settingsRestoreChecked) return
    settingsRestoreChecked = true
    if (!shell || typeof shell.updateEntryInline !== "function") return
    var current = pluginEntry()
    if (settingKeys(current).length > 0) {
      // The entry is the settings; the copy only has to match it. Writing it
      // here, without reading it first, is also what gives an install from
      // before the copy existed one.
      saveSettingsBackup(current)
      return
    }
    settingsCopyRead.running = true
  }

  function applySettingsCopy(exitCode, text) {
    if (exitCode === 1) return
    if (exitCode !== 0) {
      logEvent("settings-copy-skipped: " + (exitCode === 2 ? "not a plain file" : "over " + settingsCopyMaxBytes + " bytes"))
      return
    }
    var saved = null
    try { saved = JSON.parse(text) } catch (e) { saved = null }
    if (!saved || typeof saved !== "object" || Array.isArray(saved)) return
    var keys = settingKeys(saved)
    if (keys.length === 0) return
    // A setting saved while the copy was being read is newer than the copy.
    var current = pluginEntry()
    if (settingKeys(current).length > 0) return
    keys.forEach(function(k) { current[k] = saved[k] })
    writeEntry(current)
    logEvent("settings-restored " + keys.join(","))
  }

  // Once the entry has been read and the host has settled after a reload.
  Timer {
    id: settingsRestoreTimer
    interval: 2000
    onTriggered: root.restoreSettings()
  }

  function setInputMonitor(name) {
    var value = String(name || "all")
    inputMonitorOverride = value
    if (shell && typeof shell.updateEntryInline === "function") {
      var current = pluginEntry()
      if (value === "all") delete current.inputMonitor
      else current.inputMonitor = value
      writeEntry(current)
    }
    logEvent("input-monitor=" + value)
    return true
  }

  function setUnlockAnimation(name) {
    var value = String(name || "").trim().toLowerCase()
    if (unlockAnimations.indexOf(value) === -1) return false

    unlockOverride = value
    if (shell && typeof shell.updateEntryInline === "function") {
      var current = pluginEntry()
      if (value === "none") delete current.unlock
      else current.unlock = value
      writeEntry(current)
    }
    logEvent("unlock=" + value)
    return true
  }

  function setUnlockDuration(ms) {
    var text = String(ms === undefined ? "" : ms).trim()
    var value = Math.round(Number(text))
    if (text.length === 0 || !isFinite(value) || value < 0 || value > 2000) return false

    unlockDurationOverride = value
    if (shell && typeof shell.updateEntryInline === "function") {
      var current = pluginEntry()
      if (value === defaultUnlockDuration) delete current.unlockMs
      else current.unlockMs = value
      writeEntry(current)
    }
    logEvent("unlock-ms=" + value)
    return true
  }

  function setPowerActions(value) {
    var on = value === true || value === "true" || value === 1 || value === "1" || value === "on"
    var off = value === false || value === "false" || value === 0 || value === "0" || value === "off"
    if (!on && !off) return false

    powerActionsOverride = on ? 1 : 0
    if (shell && typeof shell.updateEntryInline === "function") {
      var current = pluginEntry()
      if (on) current.powerActions = true
      else delete current.powerActions
      writeEntry(current)
    }
    logEvent("power-actions=" + (on ? "on" : "off"))
    return true
  }

  function setFaceStart(value) {
    var text = String(value === undefined ? "" : value).trim().toLowerCase()
    if (faceStartOptions.indexOf(text) === -1) return false

    faceStartOverride = text
    if (shell && typeof shell.updateEntryInline === "function") {
      var current = pluginEntry()
      if (text === defaultFaceStart) delete current.faceStart
      else current.faceStart = text
      writeEntry(current)
    }
    logEvent("face-start=" + text)
    if (text === "off") stopFace()
    return true
  }

  function setWakeGrace(ms) {
    var text = String(ms === undefined ? "" : ms).trim()
    var value = Math.round(Number(text))
    if (text.length === 0 || !isFinite(value) || value < 0 || value > maxWakeGrace) return false

    wakeGraceOverride = value
    if (shell && typeof shell.updateEntryInline === "function") {
      var current = pluginEntry()
      if (value === defaultWakeGrace) delete current.wakeGraceMs
      else current.wakeGraceMs = value
      writeEntry(current)
    }
    logEvent("wake-grace=" + value)
    return true
  }

  function setBlankDelay(ms) {
    var text = String(ms === undefined ? "" : ms).trim()
    var value = Math.round(Number(text))
    if (text.length === 0 || !isFinite(value) || value < 1000 || value > 3600000) return false

    blankDelayOverride = value
    if (shell && typeof shell.updateEntryInline === "function") {
      var current = pluginEntry()
      if (value === defaultBlankDelay) delete current.blankMs
      else current.blankMs = value
      writeEntry(current)
    }
    logEvent("blank-ms=" + value)
    return true
  }

  function setKeepDisplayOn(on) {
    var value = on === true || on === 1 || on === "true"
    keepDisplayOnOverride = value ? 1 : 0
    if (shell && typeof shell.updateEntryInline === "function") {
      var current = pluginEntry()
      if (!value) delete current.keepDisplayOn
      else current.keepDisplayOn = true
      writeEntry(current)
    }
    logEvent("keep-display-on=" + value)
    return true
  }

  property string previewDesignId: ""
  property string previewTyped: ""
  property string previewFailure: ""
  property bool previewUnlocking: false
  Timer { id: previewFailureTimer; interval: 2500; onTriggered: root.previewFailure = "" }

  // Runs the unlock animation on the preview so it can be seen without locking.
  Timer {
    id: previewUnlockTimer
    interval: Math.max(1, root.unlockDuration + 80)
    repeat: false
    onTriggered: {
      root.previewVisible = false
      root.previewDesignId = ""
      root.previewTyped = ""
      root.previewUnlocking = false
    }
  }

  readonly property string userDesignsDir: home + "/.config/omarchy/lock-designs"
  property int designsRevision: 0

  function rescanUserDesigns() {
    if (!userDesignsProc.running) userDesignsProc.running = true
  }

  // The clip designs' videos ship in <plugin>/videos; link any that are
  // missing into ~/.config/omarchy/lock-videos, where ClipDesign and the
  // boot twins resolve them. Idempotent, never overwrites a user's file.
  Process {
    id: shippedClipsProc
    running: true
    command: ["bash", "-c",
      "dst=\"$HOME/.config/omarchy/lock-videos\"; mkdir -p \"$dst\"; for f in \"$0\"/videos/*.mp4; do [ -e \"$f\" ] || continue; b=$(basename \"$f\"); [ -e \"$dst/$b\" ] || ln -s \"$f\" \"$dst/$b\"; done",
      root.pluginDir]
  }

  // Bumps the revision so every LockHost showing a user design reloads it.
  function reloadDesigns() {
    designsRevision += 1
  }

  readonly property string pluginDir: {
    var u = String(Qt.resolvedUrl("."))
    return decodeURIComponent(u.replace(/^file:\/\//, "")).replace(/\/$/, "")
  }

  // A timestamped backup copy left in ~/.config/omarchy/plugins/ is found as a
  // second plugin with this same id, and which of the two the shell loads is
  // not something either copy decides. It costs an afternoon to work out from
  // the symptoms, so say it plainly at startup (issue #29).
  property var shadowingDirs: []

  Process {
    id: duplicatePluginProc
    // The id is matched in the manifest rather than parsed out of it: a
    // grep says whether this file claims the same id, which is the whole
    // question. Hidden directories count, and a backup copy is usually one.
    command: ["bash", "-c",
      "find \"$1\" -mindepth 2 -maxdepth 2 -name manifest.json 2>/dev/null | while read -r m; do " +
      "grep -q \"\\\"id\\\"[[:space:]]*:[[:space:]]*\\\"$2\\\"\" \"$m\" && dirname \"$m\"; done",
      "bash", Quickshell.env("HOME") + "/.config/omarchy/plugins", root.pluginId]
    stdout: StdioCollector { id: duplicatePluginStdout; waitForEnd: true }
    onExited: {
      var found = String(duplicatePluginStdout.text || "").split("\n")
        .map(function(line) { return line.trim().replace(/\/$/, "") })
        .filter(function(line) { return line.length > 0 && line !== root.pluginDir })
      root.shadowingDirs = found
      if (found.length === 0) return
      root.logEvent("shadowed-by " + found.join(" "))
      console.warn("lock-explorer: another copy of this plugin is installed under the same id and"
        + " may load instead of this one: " + found.join(", ")
        + ". Move it out of ~/.config/omarchy/plugins/ (a backup belongs anywhere else).")
    }
  }

  // Another enabled plugin that also replaces omarchy.lock registers the same
  // `lock` IPC target. Whichever loads first keeps it, so `omarchy-shell lock
  // explore` answers "Function not found" and nothing in the shell says why
  // (issue #41). Ask the shell which plugins are on and name the other one.
  property var rivalLockPlugins: []
  property bool rivalLockNotified: false

  Timer {
    id: rivalLockCheckTimer
    // After the shell has settled; right after a reload it may still list the
    // stock lock being swapped out.
    interval: 5000
    onTriggered: if (!rivalLockProc.running) rivalLockProc.running = true
  }

  Process {
    id: rivalLockProc
    command: ["omarchy-shell", "shell", "listPlugins"]
    stdout: StdioCollector { id: rivalLockStdout; waitForEnd: true }
    onExited: {
      var plugins = []
      try { plugins = JSON.parse(String(rivalLockStdout.text || "[]")) } catch (e) { return }
      if (!Array.isArray(plugins)) return
      var found = plugins.filter(function(p) {
        return p && p.enabled === true && String(p.clonedFrom || "") === "omarchy.lock"
          && String(p.id || "") !== root.pluginId
      }).map(function(p) { return String(p.id) })
      root.rivalLockPlugins = found
      if (found.length === 0) return
      root.logEvent("rival-lock " + found.join(" "))
      console.warn("lock-explorer: another lock screen plugin is enabled and may own the `lock` IPC target: "
        + found.join(", ") + ". Keep one: omarchy plugin disable " + found[0] + " && omarchy restart shell")
      if (root.rivalLockNotified) return
      root.rivalLockNotified = true
      Quickshell.execDetached(["notify-send", "-a", "Lock Screen Explorer", found.join(", ") + " is also enabled",
        "Two lock screen plugins are on. Keep one:\nomarchy plugin disable " + found[0] + "\nomarchy restart shell"])
    }
  }

  // What the explorer's Settings offers when something is missing. Both run
  // in a terminal the user can see: pacman asks for the password there, and
  // the doctor's report stays on screen until a key is pressed. Only the
  // packages the plugin itself uses can be asked for.
  readonly property var installablePackages: ["qt6-multimedia", "qt6-imageformats"]
  readonly property string doctorPath: pluginDir + "/extras/doctor.sh"

  function shellQuote(text) { return "'" + String(text).replace(/'/g, "'\\''") + "'" }

  // The terminal is Omarchy's floating one. Whether it came up is read off
  // Hyprland's window list: a terminal that cannot start (Ghostty without
  // OpenGL 4.3, a missing default) would otherwise close the explorer onto
  // nothing at all, so then a notification gives the command to run by hand.
  property string terminalFallback: ""
  Process {
    id: terminalProc
    onExited: function(exitCode) {
      if (exitCode === 0) return
      root.logEvent("terminal-missing")
      Quickshell.execDetached(["notify-send", "-a", "Lock Screen Explorer", "No terminal opened",
                               "Run this in a terminal instead:\n" + root.terminalFallback])
    }
  }

  function openInTerminal(command, fallback) {
    if (terminalProc.running) return false
    terminalFallback = fallback || command
    terminalProc.command = ["bash", "-c", "count() { hyprctl clients -j 2>/dev/null | jq '[.[] | select(.class == \"org.omarchy.terminal\")] | length' 2>/dev/null; }; launch() { setsid -f omarchy-launch-floating-terminal-with-presentation \"$1\" >/dev/null 2>&1; }; if ! command -v hyprctl >/dev/null || ! command -v jq >/dev/null; then launch \"$1\"; exit 0; fi; before=$(count); before=${before:-0}; launch \"$1\"; for _ in $(seq 24); do sleep 0.25; now=$(count); (( ${now:-0} > before )) && exit 0; done; exit 1", "bash", command]
    terminalProc.running = true
    return true
  }

  function installPackages(names) {
    var list = (names || []).map(String).filter(function(n) { return installablePackages.indexOf(n) !== -1 })
    if (list.length === 0) return false
    openInTerminal("omarchy-pkg-add " + list.join(" ") + " && omarchy restart shell",
                   "omarchy pkg add " + list.join(" ") + " && omarchy restart shell")
    logEvent("install " + list.join(" "))
    return true
  }

  // A second copy of the plugin found at startup (shadowingDirs), moved out of
  // the plugins folder by the doctor's --fix, which only ever moves what its
  // own check found. The check runs again after, so the warning goes.
  property bool movingCopies: false
  Process {
    id: moveCopiesProc
    command: ["bash", root.doctorPath, "--fix"]
    onExited: {
      root.movingCopies = false
      root.logEvent("doctor-fix exit=" + exitCode)
      duplicatePluginProc.running = true
    }
  }
  function moveCopies() {
    if (moveCopiesProc.running || shadowingDirs.length === 0) return false
    movingCopies = true
    moveCopiesProc.running = true
    return true
  }

  function runDoctor() {
    openInTerminal("bash " + shellQuote(doctorPath), "bash " + shellQuote(doctorPath))
    logEvent("doctor")
    return true
  }

  readonly property string checkFaceAuthPath: pluginDir + "/check-face-auth.sh"
  readonly property string checkFido2AuthPath: pluginDir + "/check-fido2-auth.sh"

  // The app launcher entry and the Omarchy menu entry (Style -> Lock Screen).
  // A plugin cannot run anything when it is installed, so they are opt-in:
  // the Settings tab's "Omarchy menu" row and `omarchy-shell lock setMenuEntry`
  // run extras/install.sh, which also takes them out again.
  readonly property string menuInstallPath: pluginDir + "/extras/install.sh"

  // Every embedded script that writes a file of the user's sources this first
  // (it arrives as the script's $0): an owner-checked, symlink-free directory
  // chain under $HOME and atomic replacement from inside the target directory.
  readonly property string safePathsLib: pluginDir + "/extras/safe-paths.sh"
  property bool menuEntryInstalled: false

  function refreshMenuEntry() {
    if (!menuEntryStatusProc.running) menuEntryStatusProc.running = true
  }

  function setMenuEntry(v) {
    var on = v === true || v === 1 || v === "true" || v === "on" || v === "1"
    if (menuEntryApplyProc.running) return false
    menuEntryApplyProc.command = on ? [menuInstallPath] : [menuInstallPath, "--remove"]
    menuEntryApplyProc.running = true
    logEvent("menu-entry=" + (on ? "on" : "off"))
    return true
  }

  Process {
    id: menuEntryStatusProc
    command: [root.menuInstallPath, "--status"]
    stdout: StdioCollector { id: menuEntryStatusOut; waitForEnd: true }
    onExited: root.menuEntryInstalled = String(menuEntryStatusOut.text || "").trim() === "installed"
  }

  Process {
    id: menuEntryApplyProc
    onExited: root.refreshMenuEntry()
  }

  signal designCustomized(string id, string path)

  function customizeDesign(id) {
    var d = String(id || "") === "new"
      ? { id: "new", file: "MyDesign.qml", name: "new", template: true }
      : Designs.byId(String(id || ""))
    if (!d) return false
    if (d.path) { designCustomized(d.id, decodeURIComponent(d.path.replace(/^file:\/\//, ""))); return true }
    var source = d.template ? pluginDir + "/extras/lock-designs/" + d.file : pluginDir + "/designs/" + d.file
    if (customizeProc.running) return false
    var importLine = 'import "../plugins/' + pluginId + '/designs"'
    customizeProc.command = ["bash", "-c", customizeScript, safePathsLib, source, userDesignsDir, d.file.replace(/\.qml$/, ""), d.template ? "" : importLine, d.name]
    customizeProc.running = true
    return true
  }

  readonly property string customizeScript: '
set -e; source "$0"
src="$1"; dir="$2"; base="$3"; imp="$4"; name="$5"
safe_dir "$dir"
target="$dir/$base.qml"; n=2
while [[ -e "$target" ]]; do target="$dir/$base$n.qml"; n=$((n+1)); done
{
  if [[ $name == new ]]; then echo "// New design. Edit it in the explorer (E) or with:"; else echo "// Customized copy of the $name design. Edit it here or with:"; fi
  echo "//   omarchy-shell lock editDesign my-$(basename "$target" .qml | tr "[:upper:]" "[:lower:]")"
  awk -v imp="$imp" \'
    /^import / { last = NR }
    { lines[NR] = $0 }
    END { for (i = 1; i <= NR; i++) { print lines[i]; if (i == last && imp != "") print imp } }
  \' "$src"
} | put_file "$dir" "$(basename "$target")"
echo "$target"
'

  Process {
    id: customizeProc
    stdout: StdioCollector {
      id: customizeOut
      waitForEnd: true
      onStreamFinished: {
        var target = String(customizeOut.text || "").trim()
        if (target.length === 0) return
        var d = Designs.fromUserFile(target)
        Designs.setUser(Designs.USER.concat([d]))
        root.designsRevision += 1
        root.designCustomized(d.id, target)
        root.rescanUserDesigns()
      }
    }
  }

  // ---------------------------------------------------------------- designer
  //
  // The visual designer writes ordinary designs into the same folder; a
  // layout comment at the top is what tells it apart, and is what lets the
  // designer open one again. Explorer.qml owns the editing, the service owns
  // the files.

  signal designerDesignCreated(string id, string path)

  // Makes the file and hands its path back, so the explorer can drop straight
  // into the designer on it.
  function createDesignerDesign(content) {
    if (designerCreateProc.running) return false
    designerCreateProc.command = ["bash", "-c", designerCreateScript, safePathsLib, userDesignsDir, String(content)]
    designerCreateProc.running = true
    return true
  }

  readonly property string designerCreateScript: '
set -e; source "$0"
dir="$1"; content="$2"
safe_dir "$dir"
target="$dir/MyLayout.qml"; n=2
while [[ -e $target ]]; do target="$dir/MyLayout$n.qml"; n=$((n+1)); done
printf %s "$content" | put_file "$dir" "$(basename "$target")"
echo "$target"
'

  Process {
    id: designerCreateProc
    stdout: StdioCollector {
      id: designerCreateOut
      waitForEnd: true
      onStreamFinished: {
        var target = String(designerCreateOut.text || "").trim()
        if (target.length === 0) return
        var d = Designs.fromUserFile(target)
        d.designer = true
        Designs.setUser(Designs.USER.concat([d]))
        root.designsRevision += 1
        root.designerDesignCreated(d.id, target)
        root.rescanUserDesigns()
        root.logEvent("designer-design=" + d.id)
      }
    }
  }

  // -------------------------------------------------------------- components
  //
  // Pieces saved out of the designer, so they can be dropped into any design
  // later. One JSON file each in ~/.config/omarchy/lock-components, written
  // on a single line; the scan below reads them all in one go.

  readonly property string componentsDir: home + "/.config/omarchy/lock-components"
  property var components: []

  function rescanComponents() {
    if (!componentsProc.running) componentsProc.running = true
  }

  function saveComponent(slug, json) {
    var safe = String(slug || "").toLowerCase().replace(/[^a-z0-9-]+/g, "-").replace(/^-+|-+$/g, "")
    if (safe.length === 0 || String(json || "").length === 0) return false
    if (componentSaveProc.running) return false
    componentSaveProc.command = ["bash", "-c",
      'mkdir -p "$1" && printf %s "$3" > "$1/$2.json"', "savecomponent", componentsDir, safe, String(json)]
    componentSaveProc.running = true
    logEvent("component-saved=" + safe)
    return true
  }

  function deleteComponent(slug) {
    var safe = String(slug || "").toLowerCase().replace(/[^a-z0-9-]+/g, "-").replace(/^-+|-+$/g, "")
    if (safe.length === 0) return false
    if (componentDeleteProc.running) return false
    componentDeleteProc.command = ["bash", "-c",
      'rm -f -- "$1/$2.json"', "delcomponent", componentsDir, safe]
    componentDeleteProc.running = true
    logEvent("component-deleted=" + safe)
    return true
  }

  Process {
    id: componentsProc
    running: true
    // slug<TAB>json, one component per line. The files the designer writes
    // have no newlines in them; tr keeps a hand-edited one from splitting the
    // listing across lines.
    command: ["bash", "-c",
      'dir="$1"; mkdir -p "$dir"; for f in "$dir"/*.json; do [ -e "$f" ] || continue; printf "%s\\t" "$(basename "$f" .json)"; tr -d "\\n" < "$f"; printf "\\n"; done',
      "components", root.componentsDir]
    stdout: StdioCollector {
      id: componentsOut
      waitForEnd: true
      onStreamFinished: {
        var lines = String(componentsOut.text || "").split("\n")
        var list = []
        for (var i = 0; i < lines.length; i++) {
          var tab = lines[i].indexOf("\t")
          if (tab === -1) continue
          var slug = lines[i].substring(0, tab).trim()
          try {
            var comp = JSON.parse(lines[i].substring(tab + 1))
            if (comp && comp.nodes instanceof Array) list.push({ slug: slug, comp: comp })
          } catch (e) {
            console.warn("lock-explorer: cannot read component", slug, e)
          }
        }
        list.sort(function(a, b) { return String(a.comp.name).localeCompare(String(b.comp.name)) })
        if (JSON.stringify(list) === JSON.stringify(root.components)) return
        root.components = list
      }
    }
  }

  Process {
    id: componentSaveProc
    onExited: root.rescanComponents()
  }

  Process {
    id: componentDeleteProc
    onExited: root.rescanComponents()
  }

  // The file dialog again, for the designer's Image piece. Same dance as the
  // avatar: the explorer steps aside while it is up.
  signal imagePicked(string path)
  property bool imagePickReopens: false

  function pickImage(reopenExplorer) {
    if (imagePickProc.running) return false
    imagePickReopens = reopenExplorer === true
    imagePickProc.running = true
    return true
  }

  Process {
    id: imagePickProc
    command: ["omarchy-file-select", "--title", "Pick an image for the design", "--extensions", "png jpg jpeg webp svg"]
    stdout: StdioCollector {
      id: imagePickOut
      waitForEnd: true
      onStreamFinished: {
        var picked = String(imagePickOut.text || "").trim().split("\n")[0] || ""
        if (picked.length > 0) root.imagePicked(picked)
        if (root.imagePickReopens && root.shell && typeof root.shell.summon === "function")
          root.shell.summon(root.pluginId, "{}")
        root.imagePickReopens = false
      }
    }
  }

  // ------------------------------------------------------------------ avatar

  function setAvatar(path) {
    var value = String(path || "").trim()
    if (value.indexOf("file://") === 0) value = decodeURIComponent(value.replace(/^file:\/\//, ""))
    var setting = value.length > 0 ? value : "none"
    avatarOverride = setting
    if (shell && typeof shell.updateEntryInline === "function") {
      var current = pluginEntry()
      current.avatar = setting
      writeEntry(current)
    }
    avatarVersion += 1
    logEvent("avatar=" + setting)
    return true
  }

  function clearAvatar() {
    return setAvatar("")
  }

  // Back to the detected ~/.face and friends.
  function resetAvatar() {
    avatarOverride = ""
    if (shell && typeof shell.updateEntryInline === "function") {
      var current = pluginEntry()
      delete current.avatar
      writeEntry(current)
    }
    avatarVersion += 1
    detectAvatar()
    logEvent("avatar=auto")
    return true
  }

  function detectAvatar() {
    if (!detectAvatarProc.running) detectAvatarProc.running = true
  }

  // The desktop file chooser, so picking a picture is a normal file dialog.
  // The explorer grabs the keyboard, so it closes itself before asking for one
  // and comes back when the dialog is answered.
  property bool avatarPickReopens: false
  function pickAvatar(reopenExplorer) {
    if (avatarPickProc.running) return false
    avatarPickReopens = reopenExplorer === true
    avatarPickProc.running = true
    return true
  }

  readonly property string detectAvatarScript: '
for f in "$HOME/.config/omarchy/lock-avatar.png" "$HOME/.config/omarchy/lock-avatar.jpg" \
         "$HOME/.config/omarchy/lock-avatar.jpeg" "$HOME/.config/omarchy/lock-avatar.webp" \
         "$HOME/.face" "$HOME/.face.icon" "/var/lib/AccountsService/icons/$USER"; do
  [[ -f $f ]] && { echo "$f"; exit 0; }
done
'

  Process {
    id: detectAvatarProc
    command: ["bash", "-c", root.detectAvatarScript]
    stdout: StdioCollector {
      id: detectAvatarOut
      waitForEnd: true
      onStreamFinished: {
        var found = String(detectAvatarOut.text || "").trim().split("\n")[0] || ""
        if (found !== root.detectedAvatar) {
          root.detectedAvatar = found
          root.avatarVersion += 1
        }
      }
    }
  }

  Process {
    id: avatarPickProc
    command: ["omarchy-file-select", "--title", "Pick a lock screen avatar", "--extensions", "png jpg jpeg webp"]
    stdout: StdioCollector {
      id: avatarPickOut
      waitForEnd: true
      onStreamFinished: {
        var picked = String(avatarPickOut.text || "").trim().split("\n")[0] || ""
        if (picked.length > 0) root.setAvatar(picked)
        if (root.avatarPickReopens && root.shell && typeof root.shell.summon === "function")
          root.shell.summon(root.pluginId, "{}")
        root.avatarPickReopens = false
      }
    }
  }

  // ------------------------------------------------------------------- video

  function setVideo(path) {
    var value = String(path || "").trim()
    if (value.indexOf("file://") === 0) value = decodeURIComponent(value.replace(/^file:\/\//, ""))
    var setting = value.length > 0 ? value : "none"
    videoOverride = setting
    if (shell && typeof shell.updateEntryInline === "function") {
      var current = pluginEntry()
      if (setting === "none") delete current.video
      else current.video = setting
      writeEntry(current)
    }
    logEvent("video=" + setting)
    return true
  }

  function clearVideo() { return setVideo("") }

  function setSting(path) {
    var value = String(path || "").trim()
    if (value.indexOf("file://") === 0) value = decodeURIComponent(value.replace(/^file:\/\//, ""))
    var setting = value.length > 0 ? value : "none"
    stingOverride = setting
    if (shell && typeof shell.updateEntryInline === "function") {
      var current = pluginEntry()
      if (setting === "none") delete current.sting
      else current.sting = setting
      writeEntry(current)
    }
    logEvent("sting=" + setting)
    return true
  }

  function clearSting() { return setSting("") }

  function setStingVolume(value) {
    var text = String(value === undefined ? "" : value).trim()
    var v = Math.round(Number(text))
    if (text.length === 0 || !isFinite(v) || v < 0 || v > 100) return false
    stingVolumeOverride = v
    if (shell && typeof shell.updateEntryInline === "function") {
      var current = pluginEntry()
      if (v === 0) delete current.stingVolume
      else current.stingVolume = v
      writeEntry(current)
    }
    logEvent("sting-volume=" + v)
    return true
  }

  // Same dance as the avatar picker: the explorer steps aside for the dialog.
  property bool videoPickReopens: false
  property string videoPickTarget: "video"
  function pickVideo(reopenExplorer, target) {
    if (videoPickProc.running) return false
    videoPickTarget = String(target || "video")
    videoPickReopens = reopenExplorer === true
    videoPickProc.command = ["omarchy-file-select",
      "--title", videoPickTarget === "sting" ? "Pick an unlock clip"
        : videoPickTarget === "clip" ? "Pick a video for a new clip design"
        : "Pick a lock screen video",
      "--extensions", "mp4 mkv webm mov m4v"]
    videoPickProc.running = true
    return true
  }

  Process {
    id: videoPickProc
    stdout: StdioCollector {
      id: videoPickOut
      waitForEnd: true
      onStreamFinished: {
        var picked = String(videoPickOut.text || "").trim().split("\n")[0] || ""
        if (picked.length > 0) {
          if (root.videoPickTarget === "sting") root.setSting(picked)
          else if (root.videoPickTarget === "clip") root.createClipDesign(picked)
          else root.setVideo(picked)
        }
        if (root.videoPickReopens && root.shell && typeof root.shell.summon === "function")
          root.shell.summon(root.pluginId, "{}")
        root.videoPickReopens = false
      }
    }
  }

  // A picked video becomes a one-line ClipDesign in ~/.config/omarchy/lock-designs,
  // with the file itself copied to ~/.config/omarchy/lock-videos where ClipDesign
  // resolves clips from. Same freeze-then-play-on-unlock behavior as Storm.
  signal clipDesignAdded(string id)

  function createClipDesign(path) {
    var src = String(path || "").trim()
    if (src.indexOf("file://") === 0) src = decodeURIComponent(src.replace(/^file:\/\//, ""))
    if (src.length === 0 || clipDesignProc.running) return false
    var importLine = 'import "../plugins/' + pluginId + '/designs"'
    clipDesignProc.command = ["bash", "-c", clipDesignScript, safePathsLib,
      src, home + "/.config/omarchy/lock-videos", userDesignsDir, importLine]
    clipDesignProc.running = true
    return true
  }

  readonly property string clipDesignScript: '
set -e; source "$0"
src="$1"; videos="$2"; dir="$3"; imp="$4"
safe_dir "$videos"; safe_dir "$dir"
base=$(basename "$src")
# The copied name is embedded in QML, comments and tab-separated metadata.
# Keep it inert in all three, and compatible with the clipName scanner.
# Only the imported copy is renamed; the source file is left untouched.
base=$(printf %s "$base" | LC_ALL=C tr -c "a-zA-Z0-9._-" "_")
if [[ -e "$videos/$base" ]] && ! cmp -s "$src" "$videos/$base"; then
  stem="${base%.*}"; ext="${base##*.}"; n=2
  while [[ -e "$videos/$stem-$n.$ext" ]]; do n=$((n+1)); done
  base="$stem-$n.$ext"
fi
[[ -e "$videos/$base" ]] || put_file "$videos" "$base" < "$src"
stem="${base%.*}"
name=$(printf %s "$stem" | tr -cd "[:alnum:]_-")
[[ -n "$name" ]] || name=Clip
target="$dir/$name.qml"; n=2
while [[ -e "$target" ]]; do target="$dir/$name$n.qml"; n=$((n+1)); done
q=\'"\'
{
  echo "// Clip design: $base holds its first frame while locked and plays"
  echo "// through as the unlock. The video lives in ~/.config/omarchy/lock-videos."
  echo "$imp"
  echo ""
  echo "ClipDesign { clipName: $q$base$q }"
} | put_file "$dir" "$(basename "$target")"
printf "%s\\t%s\\n" "$target" "$base"
'

  Process {
    id: clipDesignProc
    stdout: StdioCollector {
      id: clipDesignOut
      waitForEnd: true
      onStreamFinished: {
        var last = String(clipDesignOut.text || "").trim().split("\n").pop() || ""
        var parts = last.split("\t")
        var target = (parts[0] || "").trim()
        if (target.length === 0) return
        var d = Designs.fromUserFile(target)
        d.anim = true
        d.clip = true
        if (parts.length > 1 && parts[1].trim().length > 0) d.clipFile = parts[1].trim()
        Designs.setUser(Designs.USER.concat([d]))
        root.designsRevision += 1
        root.rescanUserDesigns()
        root.clipDesignAdded(d.id)
        root.logEvent("clip-design=" + target)
      }
    }
  }

  // Delete a user design from ~/.config/omarchy/lock-designs. A clip design's
  // video goes with it, unless the boot screen, the Motion video or the unlock
  // clip still point at it, or another design names it.
  function deleteDesign(id) {
    var d = Designs.byId(String(id || ""))
    if (!d || !d.path) return false
    var file = decodeURIComponent(String(d.path).replace(/^file:\/\//, ""))
    if (file.indexOf(userDesignsDir + "/") !== 0) return false
    var clip = String(d.clipFile || "")
    if (clip.length > 0) {
      var tail = "/" + clip
      var keep = bootSetting === "video:" + clip
        || (videoPath.length >= tail.length && videoPath.lastIndexOf(tail) === videoPath.length - tail.length)
        || (stingPath.length >= tail.length && stingPath.lastIndexOf(tail) === stingPath.length - tail.length)
      if (keep) clip = ""
    }
    if (designId === d.id) setDesign(Designs.DEFAULT_ID)
    deleteDesignProc.command = ["bash", "-c", deleteDesignScript, "deldesign",
      file, home + "/.config/omarchy/lock-videos", clip, userDesignsDir]
    deleteDesignProc.running = true
    logEvent("delete-design=" + d.id)
    return true
  }

  readonly property string deleteDesignScript: '
set -e
file="$1"; videos="$2"; clip="$3"; dir="$4"
rm -f -- "$file"
if [[ -n $clip ]] && ! grep -qs -- "$clip" "$dir"/*.qml 2>/dev/null; then
  rm -f -- "$videos/$clip"
fi
'

  Process {
    id: deleteDesignProc
    onExited: function(exitCode) {
      root.rescanUserDesigns()
      root.refreshBootLists()
    }
  }

  // Delete a boot card of the user's own: a video from
  // ~/.config/omarchy/lock-videos (video:<file>) or a custom boot layout
  // (custom:<name>, taking its generated lock design along). Videos still
  // used as the Motion video or the unlock clip are left alone.
  function deleteBootItem(id) {
    var v = String(id || "")
    if (v.indexOf("video:") !== 0 && v.indexOf("custom:") !== 0) return false
    if (v.indexOf("video:") === 0) {
      var tail = "/" + v.substring(6)
      if ((videoPath.length >= tail.length && videoPath.lastIndexOf(tail) === videoPath.length - tail.length)
        || (stingPath.length >= tail.length && stingPath.lastIndexOf(tail) === stingPath.length - tail.length)) return false
    }
    if (bootSetting === v) setBoot("stock")
    deleteBootItemProc.command = ["bash", "-c", deleteBootItemScript, "delboot",
      v, home + "/.config/omarchy/lock-videos", home + "/.config/omarchy/boot-designs",
      home + "/.config/omarchy/lock-designs",
      home + "/.local/state/omarchy/lock-explorer-boot-previews"]
    deleteBootItemProc.running = true
    logEvent("delete-boot=" + v)
    return true
  }

  readonly property string deleteBootItemScript: '
set -e
id="$1"; videos="$2"; bootdir="$3"; lockdir="$4"; previews="$5"
case "$id" in
  video:*)
    f="${id#video:}"
    rm -f -- "$videos/$f"
    rm -f -- "$previews/video-$f-"*.png
    ;;
  custom:*)
    n="${id#custom:}"
    rm -f -- "$bootdir/$n.conf"
    rm -f -- "$lockdir/$n.qml"
    rm -f -- "$previews/custom-$n-"*.png
    ;;
esac
'

  Process {
    id: deleteBootItemProc
    onExited: function(exitCode) {
      root.refreshBootLists()
      root.rescanUserDesigns()
      root.refreshBootPreviews()
    }
  }

  // The clip that plays once the lock surface is gone. It runs over the live
  // desktop rather than holding the session lock, so nothing it does can leave
  // the screen stuck: any key, any click, the end of the clip or the failsafe
  // timer takes it away.
  property bool stingPlaying: false

  function playSting() {
    if (stingPath.length === 0 || stingPlaying) return false
    // No player without qt6-multimedia; setting stingPlaying anyway would
    // stick, since only the window's timers ever call endSting().
    if (!multimediaAvailable) return false
    stingPlaying = true
    logEvent("sting-playing")
    return true
  }

  function endSting() {
    if (!stingPlaying) return
    stingPlaying = false
    logEvent("sting-done")
    commitClipWallpaper()
  }

  // "The last frame becomes your wallpaper": with clipWallpaper on, the frame
  // the unlock video ends on is extracted while the screen is still locked and
  // handed to omarchy-theme-bg-set the moment the clip gives the screen back,
  // so the desktop opens exactly where the video stopped. Saved on the plugin
  // entry as `clipWallpaper: true`, off by default.
  property int clipWallpaperOverride: -1
  readonly property bool configuredClipWallpaper: {
    var cfg = root.settingsConfig
    var list = cfg && Array.isArray(cfg.plugins) ? cfg.plugins : []
    for (var i = 0; i < list.length; i++) {
      var entry = list[i]
      if (entry && String(entry.id || "") === pluginId && entry.clipWallpaper === true) return true
    }
    return false
  }
  readonly property bool clipWallpaper: clipWallpaperOverride === -1 ? configuredClipWallpaper : clipWallpaperOverride === 1

  function setClipWallpaper(on) {
    var enabled = on === true || on === "true" || on === "on"
    clipWallpaperOverride = enabled ? 1 : 0
    if (shell && typeof shell.updateEntryInline === "function") {
      var current = pluginEntry()
      if (enabled) current.clipWallpaper = true
      else delete current.clipWallpaper
      writeEntry(current)
    }
    logEvent("clip-wallpaper=" + enabled)
    return true
  }

  property string preparedClipWallpaper: ""

  function prepareClipWallpaper(path) {
    if (!clipWallpaper || !path || String(path).length === 0) return
    if (clipWallPrepProc.running) return
    preparedClipWallpaper = ""
    clipWallPrepProc.command = ["bash", "-c", clipWallScript, safePathsLib,
      String(path), home + "/.local/state/omarchy/lock-explorer-clip-wallpapers"]
    clipWallPrepProc.running = true
  }

  function commitClipWallpaper() {
    if (!clipWallpaper || preparedClipWallpaper.length === 0) return
    Quickshell.execDetached(["omarchy-theme-bg-set", preparedClipWallpaper])
    logEvent("clip-wallpaper-set=" + preparedClipWallpaper)
  }

  readonly property string clipWallScript: '
set -e; source "$0"
src="$1"; dir="$2"
safe_dir "$dir"
stem=$(basename "$src"); stem="${stem%.*}"
out="$dir/$stem.png"
if [[ ! -s "$out" || "$src" -nt "$out" ]]; then
  tmp=$(mktemp --suffix=.png)
  trap "rm -f -- $tmp" EXIT
  ffmpeg -y -loglevel error -sseof -1 -i "$src" -update 1 "$tmp" || true
  [[ -s "$tmp" ]] || ffmpeg -y -loglevel error -i "$src" -update 1 "$tmp"
  put_file "$dir" "$stem.png" < "$tmp"
fi
echo "$out"
'

  Process {
    id: clipWallPrepProc
    stdout: StdioCollector {
      id: clipWallPrepOut
      waitForEnd: true
      onStreamFinished: {
        root.preparedClipWallpaper = String(clipWallPrepOut.text || "").trim().split("\n").pop() || ""
      }
    }
  }

  // The boot (LUKS decrypt) screen, styled with Plymouth. Saved on the plugin
  // entry as `boot`: "follow" keeps it matched to the lock design whenever the
  // design has a twin under plymouth/, a design id pins it to that design, and
  // absent means the stock Omarchy boot theme is left alone. Applying bakes the
  // current theme colors into a generated theme and rebuilds the initramfs
  // through a single polkit prompt (see plymouth/apply.sh).
  property string bootOverride: ""
  readonly property string configuredBoot: {
    var cfg = root.settingsConfig
    var list = cfg && Array.isArray(cfg.plugins) ? cfg.plugins : []
    for (var i = 0; i < list.length; i++) {
      var entry = list[i]
      if (entry && String(entry.id || "") === pluginId && entry.boot) return String(entry.boot)
    }
    return "stock"
  }
  readonly property string bootSetting: {
    var value = bootOverride.length > 0 ? bootOverride : configuredBoot
    if (value === "follow" || value === "stock" || value === "theme" || value === "rotate") return value
    if (value.indexOf("snapshot:") === 0 || value.indexOf("video:") === 0 || value.indexOf("custom:") === 0) return value
    var d = Designs.byId(value)
    return d && d.boot === true ? value : "stock"
  }
  property bool bootApplying: false
  property string bootApplyTarget: ""
  property string bootApplied: ""  // last installed twin, "" = stock/untouched
  property int bootAppliedVersion: 0
  readonly property string bootTarget: {
    if (bootSetting === "stock") return "stock"
    if (bootSetting === "theme") return "theme"
    if (bootSetting === "rotate") return ""
    if (bootSetting.indexOf("snapshot:") === 0) return bootSetting
    if (bootSetting === "follow") {
      var d = Designs.byId(designId)
      return d && d.boot === true ? d.id : ""
    }
    return bootSetting
  }

  function setBoot(value) {
    var v = String(value || "").trim().toLowerCase()
    if (v !== "follow" && v !== "stock" && v !== "theme" && v !== "rotate" && v.indexOf("video:") !== 0 && v.indexOf("custom:") !== 0 && v.indexOf("snapshot:") !== 0) {
      var d = Designs.byId(v)
      if (!d || d.boot !== true) return false
    }
    if (bootApplying) return false
    bootOverride = v
    if (shell && typeof shell.updateEntryInline === "function") {
      var current = pluginEntry()
      if (v === "stock") delete current.boot
      else current.boot = v
      writeEntry(current)
    }
    logEvent("boot=" + v)
    // Redesign: picking a boot option only sets the desired choice; the
    // rebuild happens when the Apply button is pressed.
    return true
  }

  // force reapplies even when the target already matches, so a changed Omarchy
  // theme gets its colors baked in again.
  function applyBoot(force, explicitTarget) {
    if (bootApplying) return
    var target = explicitTarget !== undefined && String(explicitTarget).length > 0 ? String(explicitTarget) : bootTarget
    if (target.length === 0) return  // follow, but this design has no twin
    if (target === "stock" && bootApplied.length === 0) return  // nothing to restore
    if (!force && target === bootApplied) return
    bootApplying = true
    bootApplyTarget = target
    bootApplyProc.command = ["env", "BOOT_CLIP_SECONDS=" + bootClipSeconds, "bash", pluginDir + "/plymouth/apply.sh", target]
    bootApplyProc.running = true
  }

  Process {
    id: bootApplyProc
    stdout: StdioCollector { }
    stderr: StdioCollector {
      id: bootApplyErr
      waitForEnd: true
    }
    onExited: function(exitCode) {
      root.bootApplying = false
      if (exitCode === 0) {
        root.bootApplied = root.bootApplyTarget === "stock" ? "" : root.bootApplyTarget
        root.logEvent("boot-applied=" + (root.bootApplied.length > 0 ? root.bootApplied : "stock"))
      } else {
        root.logEvent("boot-apply-failed=" + exitCode)
        console.warn("lock-explorer: plymouth apply failed:", String(bootApplyErr.text || "").trim())
      }
    }
  }

  // apply.sh records what it installed and which Omarchy theme the colors
  // came from; picking it up here keeps the state right across shell restarts
  // and command line applies.
  FileView {
    path: root.stateHome + "/omarchy/lock-explorer-boot"
    watchChanges: true
    printErrors: false
    onLoaded: {
      var parts = String(text()).trim().split(/\s+/)
      var value = parts[0] || ""
      root.bootApplied = value === "stock" ? "" : value
      root.bootAppliedTheme = parts.length > 1 ? parts[1] : ""
      // Cache-buster for the applied-boot preview image, which is rewritten
      // on every apply (same-id re-applies included).
      root.bootAppliedVersion += 1
    }
    onLoadFailed: { root.bootApplied = ""; root.bootAppliedTheme = "" }
    onFileChanged: reload()
  }

  // The boot screen colors are baked in at apply time, so a theme switch
  // would leave it in the old palette right until the retained last frame
  // hands over to the new wallpaper. Regenerate when the theme changes,
  // unless the user opted out (`bootResync: false` on the plugin entry).
  property string bootAppliedTheme: ""
  property string bootCurrentTheme: ""
  property int bootResyncOverride: -1
  readonly property bool configuredBootResync: {
    var cfg = root.settingsConfig
    var list = cfg && Array.isArray(cfg.plugins) ? cfg.plugins : []
    for (var i = 0; i < list.length; i++) {
      var entry = list[i]
      if (entry && String(entry.id || "") === pluginId && entry.bootResync === false) return false
    }
    return true
  }
  readonly property bool bootResync: bootResyncOverride === -1 ? configuredBootResync : bootResyncOverride === 1

  function setBootResync(on) {
    var enabled = on === true || on === "on" || on === "true"
    bootResyncOverride = enabled ? 1 : 0
    if (shell && typeof shell.updateEntryInline === "function") {
      var current = pluginEntry()
      if (enabled) delete current.bootResync
      else current.bootResync = false
      writeEntry(current)
    }
    logEvent("boot-resync=" + (enabled ? "on" : "off"))
    if (enabled) maybeResyncBoot()
    return true
  }

  // Snapshot boot screens can't be re-baked from the old picture: the theme
  // change moved the wallpaper and colors, so the explorer has to take a
  // fresh snapshot (which also carries the entry geometry).
  signal bootResnapshotRequested(string designId, bool persist)
  signal exploreTabRequested(string tab)

  function maybeResyncBoot() {
    if (!bootResync || bootApplying || !bootResyncArmed) return
    if (bootApplied.length === 0 || bootAppliedTheme.length === 0 || bootCurrentTheme.length === 0) return
    if (bootAppliedTheme === bootCurrentTheme) return
    logEvent("boot-resync " + bootAppliedTheme + " -> " + bootCurrentTheme)
    if (bootApplied.indexOf("snapshot:") === 0) {
      // The fresh snapshot carries the new background too.
      bootBgResyncTimer.stop()
      bootResnapshotRequested(bootApplied.substring(9), bootSetting !== "follow")
      return
    }
    // Re-bake what is actually installed: with follow and a twin-less lock
    // design the setting resolves to nothing, but the installed twin still
    // needs the new colors.
    applyBoot(true, bootApplied)
  }

  // Cycling the background inside a theme leaves an applied snapshot showing
  // the old wallpaper. Retake it once the cycling settles; same opt-out as
  // the theme resync.
  property string bootLastBackground: ""

  onBackgroundPathChanged: {
    if (backgroundPath.length === 0) return
    if (bootLastBackground.length === 0) { bootLastBackground = backgroundPath; return }
    if (bootLastBackground === backgroundPath) return
    bootLastBackground = backgroundPath
    if (!bootResync || !bootResyncArmed) return
    if (bootApplied.indexOf("snapshot:") !== 0) return
    bootBgResyncTimer.restart()
  }

  Timer {
    id: bootBgResyncTimer
    interval: 8000
    onTriggered: {
      if (!root.bootResync || root.bootApplying) return
      if (root.bootApplied.indexOf("snapshot:") !== 0) return
      root.logEvent("boot-resync background")
      root.bootResnapshotRequested(root.bootApplied.substring(9), root.bootSetting !== "follow")
    }
  }


  // Thumbnails for the explorer's boot cards, one per option and theme,
  // rendered in the background by plymouth/previews.sh.
  property int bootPreviewsVersion: 0
  property bool bootPreviewsRunning: false

  property bool bootPreviewsPending: false

  function refreshBootPreviews() {
    refreshBootLists()
    // A request landing mid-run must queue a follow-up: the running pass
    // rendered the state before this change and would leave stale previews.
    if (bootPreviewsRunning) { bootPreviewsPending = true; return }
    bootPreviewsRunning = true
    bootPreviewsProc.command = ["bash", pluginDir + "/plymouth/previews.sh"]
    bootPreviewsProc.running = true
  }

  Process {
    id: bootPreviewsProc
    stdout: StdioCollector { }
    stderr: StdioCollector { }
    onExited: function(exitCode) {
      root.bootPreviewsRunning = false
      root.bootPreviewsVersion++
      if (root.bootPreviewsPending) {
        root.bootPreviewsPending = false
        root.refreshBootPreviews()
      }
    }
  }


  // The user's own clips and boot layouts, listed as cards on the boot tab.
  property var bootVideos: []
  property var bootCustomDesigns: []

  function refreshBootLists() { bootListsProc.running = true }

  Process {
    id: bootListsProc
    command: ["bash", "-c", "ls -1 \"$HOME/.config/omarchy/lock-videos\" 2>/dev/null; echo ::; for f in \"$HOME\"/.config/omarchy/boot-designs/*.conf; do [ -f \"$f\" ] && basename \"$f\" .conf; done"]
    stdout: StdioCollector {
      id: bootListsOut
      waitForEnd: true
      onStreamFinished: {
        var parts = String(bootListsOut.text || "").split("::")
        root.bootVideos = (parts[0] || "").split("\n")
          .map(function(l) { return l.trim() })
          .filter(function(l) { return /\.(mp4|mkv|webm|mov|m4v)$/i.test(l) })
        root.bootCustomDesigns = (parts.length > 1 ? parts[1] : "").split("\n")
          .map(function(l) { return l.trim() })
          .filter(function(l) { return l.length > 0 })
      }
    }
  }

  // How much of a clip boot screen plays, in seconds; 0 plays it all. Saved
  // on the plugin entry as bootClipSeconds.
  property int bootClipSecondsOverride: -1
  readonly property int configuredBootClipSeconds: {
    var cfg = root.settingsConfig
    var list = cfg && Array.isArray(cfg.plugins) ? cfg.plugins : []
    for (var i = 0; i < list.length; i++) {
      var entry = list[i]
      if (entry && String(entry.id || "") === pluginId && entry.bootClipSeconds !== undefined)
        return Math.max(0, Math.min(30, Number(entry.bootClipSeconds) || 0))
    }
    return 0
  }
  readonly property int bootClipSeconds: bootClipSecondsOverride >= 0 ? bootClipSecondsOverride : configuredBootClipSeconds

  function setBootClipSeconds(n) {
    var v = Math.max(0, Math.min(30, Math.round(Number(n) || 0)))
    bootClipSecondsOverride = v
    if (shell && typeof shell.updateEntryInline === "function") {
      var current = pluginEntry()
      if (v === 0) delete current.bootClipSeconds
      else current.bootClipSeconds = v
      writeEntry(current)
    }
    logEvent("boot-clip=" + v)
    var appliedIsClip = bootApplied.indexOf("video:") === 0
    if (!appliedIsClip) {
      var d = Designs.byId(bootApplied)
      appliedIsClip = !!(d && d.bootKind === "clip")
    }
    if (appliedIsClip) applyBoot(true, bootApplied)
    return true
  }

  // Plumbing for the boot layout editor in the explorer.
  signal bootDesignLoaded(string name, string content)
  property string bootDesignPendingLoad: ""

  function loadBootDesign(name) {
    bootDesignPendingLoad = String(name)
    bootLoadProc.command = ["cat", home + "/.config/omarchy/boot-designs/" + bootDesignPendingLoad + ".conf"]
    bootLoadProc.running = true
  }

  Process {
    id: bootLoadProc
    stdout: StdioCollector {
      id: bootLoadOut
      waitForEnd: true
      onStreamFinished: root.bootDesignLoaded(root.bootDesignPendingLoad, String(bootLoadOut.text || ""))
    }
  }

  property string bootSaveName: ""
  function saveBootDesign(name, content) {
    bootSaveName = String(name)
    bootSaveProc.command = ["bash", "-c",
      'mkdir -p "$HOME/.config/omarchy/boot-designs" && printf %s "$1" > "$HOME/.config/omarchy/boot-designs/$2.conf"',
      "--", String(content), String(name)]
    bootSaveProc.running = true
  }

  Process {
    id: bootSaveProc
    onExited: function(exitCode) {
      // Generate the matching lock screen QML + its preview from the same
      // layout, so the pair stays in sync.
      var previews = root.stateHome + "/omarchy/lock-explorer-boot-previews"
      lockGenProc.command = ["bash", "-c",
        'mkdir -p "$3" && bash "$1" "$HOME/.config/omarchy/boot-designs/$2.conf" "$2" "$3/custom-$2-lock-$4.png"',
        "--", root.pluginDir + "/plymouth/custom/genlock.sh", root.bootSaveName, previews, root.bootCurrentTheme]
      lockGenProc.running = true
    }
  }

  Process {
    id: lockGenProc
    onExited: function(exitCode) {
      root.refreshBootPreviews()
      root.rescanUserDesigns()
      root.logEvent("boot-design-saved")
    }
  }

  function createBootDesign() {
    bootCreateProc.command = ["bash", "-c",
      'dir="$HOME/.config/omarchy/boot-designs"; mkdir -p "$dir"; n="my-boot"; i=2; while [ -f "$dir/$n.conf" ]; do n="my-boot-$i"; i=$((i+1)); done; cp "$1" "$dir/$n.conf"; echo "$n"',
      "--", pluginDir + "/plymouth/custom/template.conf"]
    bootCreateProc.running = true
  }

  Process {
    id: bootCreateProc
    stdout: StdioCollector {
      id: bootCreateOut
      waitForEnd: true
      onStreamFinished: {
        var n = String(bootCreateOut.text || "").trim()
        if (n.length > 0) {
          root.refreshBootLists()
          root.loadBootDesign(n)
        }
      }
    }
  }


  // Boot screen rotation: a set of options that advances one step after
  // every boot. The screen is baked into the boot image, so the swap happens
  // in the background right after login -- silently through the root path
  // unit rotate-setup.sh installs (one pkexec, once), with a normal polkit
  // prompt as the fallback. Saved on the plugin entry as bootRotation.
  property var bootRotationOverride: null
  readonly property var configuredBootRotation: {
    var cfg = root.settingsConfig
    var list = cfg && Array.isArray(cfg.plugins) ? cfg.plugins : []
    for (var i = 0; i < list.length; i++) {
      var entry = list[i]
      if (entry && String(entry.id || "") === pluginId && Array.isArray(entry.bootRotation)) return entry.bootRotation
    }
    return []
  }
  readonly property var bootRotation: bootRotationOverride !== null ? bootRotationOverride : configuredBootRotation
  property bool bootRotateSilent: false
  property string bootRotateNext: ""

  function toggleBootRotation(id) {
    var v = String(id || "")
    if (v.length === 0 || v === "stock") return false
    var list = bootRotation.slice()
    var idx = list.indexOf(v)
    if (idx === -1) list.push(v)
    else list.splice(idx, 1)
    bootRotationOverride = list
    if (shell && typeof shell.updateEntryInline === "function") {
      var current = pluginEntry()
      if (list.length === 0) delete current.bootRotation
      else current.bootRotation = list
      writeEntry(current)
    }
    logEvent("boot-rotation=" + list.join(","))
    return true
  }

  // persist=false applies the snapshot as the on-disk artifact but leaves the
  // saved boot setting alone (used by follow mode, which stays "follow").
  // entryRect ("cx,cy,w,h" in percent) is where the design's own input box
  // sits in the snapshot; the boot theme puts its bullets there.
  function applyBootSnapshot(id, persist, entryRect) {
    if (bootApplying) return
    if (persist === undefined) persist = true
    if (persist) {
      bootOverride = "snapshot:" + id
      if (shell && typeof shell.updateEntryInline === "function") {
        var current = pluginEntry()
        current.boot = "snapshot:" + id
        writeEntry(current)
      }
    }
    bootApplying = true
    bootApplyTarget = "snapshot:" + id
    bootApplyProc.command = ["env", "BOOT_CLIP_SECONDS=0",
      "SNAPSHOT_ENTRY=" + String(entryRect || ""),
      "bash", pluginDir + "/plymouth/apply.sh", "snapshot:" + id]
    bootApplyProc.running = true
    logEvent("boot-snapshot=" + id + (persist ? "" : " (follow)"))
  }

  function enableBootRotation() {
    if (bootRotateSilent) { setBoot("rotate"); return }
    // No home argument: the setup script reads it from the account that
    // authenticated to pkexec. It lands in a root-owned helper, and $HOME is
    // whatever the process that started the shell set it to.
    bootRotateSetupProc.command = ["pkexec", "bash", pluginDir + "/plymouth/rotate-setup.sh", "install"]
    bootRotateSetupProc.running = true
  }

  Process {
    id: bootRotateSetupProc
    stdout: StdioCollector { }
    stderr: StdioCollector { }
    onExited: function(exitCode) {
      if (exitCode === 0) {
        root.bootRotateSilent = true
        root.setBoot("rotate")
        root.logEvent("boot-rotate-setup=ok")
      } else {
        root.logEvent("boot-rotate-setup-failed=" + exitCode)
      }
    }
  }

  Process {
    id: bootRotateCheckProc
    // The helper rotate-setup.sh wrote has to be one that takes the spooled
    // theme as a tar file; an older one that walked a directory is not used,
    // so rotation falls back to the prompt until it is set up again.
    command: ["bash", "-c", "[ -f /etc/systemd/system/omarchy-lock-explorer-boot.path ] && grep -q lock-explorer-boot-spool.tar /usr/local/lib/omarchy-lock-explorer-rotate.sh 2>/dev/null && echo yes || echo no"]
    stdout: StdioCollector {
      id: bootRotateCheckOut
      waitForEnd: true
      onStreamFinished: {
        root.bootRotateSilent = String(bootRotateCheckOut.text || "").trim() === "yes"
        root.maybeRotateBoot()
      }
    }
  }

  // Advance at most once per boot: the stamp file keeps the boot id, so
  // shell restarts inside the same boot leave the rotation alone.
  function maybeRotateBoot() {
    if (bootSetting !== "rotate") return
    var list = bootRotation
    if (!list || list.length === 0) return
    var idx = list.indexOf(bootApplied)
    var next = list[(idx + 1) % list.length]
    if (next === bootApplied) return
    bootRotateNext = next
    bootRotateStampProc.running = true
  }

  Process {
    id: bootRotateStampProc
    command: ["bash", "-c", "bid=$(cat /proc/sys/kernel/random/boot_id); f=\"$HOME/.local/state/omarchy/lock-explorer-boot-rotated\"; [ \"$(cat \"$f\" 2>/dev/null)\" = \"$bid\" ] && echo skip || { echo \"$bid\" > \"$f\"; echo go; }"]
    stdout: StdioCollector {
      id: bootRotateStampOut
      waitForEnd: true
      onStreamFinished: {
        if (String(bootRotateStampOut.text || "").trim() !== "go") return
        if (root.bootRotateNext.length === 0 || root.bootApplying) return
        root.logEvent("boot-rotate -> " + root.bootRotateNext)
        if (root.bootRotateSilent) {
          root.bootApplying = true
          root.bootApplyTarget = root.bootRotateNext
          bootApplyProc.command = ["env", "BOOT_CLIP_SECONDS=" + root.bootClipSeconds, "bash", root.pluginDir + "/plymouth/apply.sh", root.bootRotateNext, "--spool"]
          bootApplyProc.running = true
        } else {
          root.applyBoot(true, root.bootRotateNext)
        }
      }
    }
  }

  // Armed a little after startup so a stale palette right after login gets
  // one polkit prompt once the desktop has settled, not mid-splash.
  property bool bootResyncArmed: false

  Timer {
    interval: 12000
    running: true
    onTriggered: {
      root.bootResyncArmed = true
      root.refreshBootLists()
      // The silent-rotation check chains into maybeRotateBoot; the resync
      // runs after so a rotation that just advanced satisfies it.
      bootRotateCheckProc.running = true
      root.maybeResyncBoot()
    }
  }

  FileView {
    path: root.stateHome + "/omarchy/current/theme.name"
    watchChanges: true
    printErrors: false
    onLoaded: { root.bootCurrentTheme = String(text()).trim(); root.maybeResyncBoot() }
    onLoadFailed: root.bootCurrentTheme = ""
    onFileChanged: reload()
  }

  function setDesign(id) {
    var d = Designs.byId(String(id || ""))
    if (!d) return false
    designOverride = d.id
    if (shell && typeof shell.updateEntryInline === "function") {
      var current = pluginEntry()
      current.design = d.id
      writeEntry(current)
    }
    logEvent("design=" + d.id)
    if (bootSetting === "follow") applyBoot(false)
    return true
  }

  readonly property string home: Quickshell.env("HOME")
  readonly property string stateHome: home + "/.local/state"
  readonly property string userName: Quickshell.env("USER") || Quickshell.env("LOGNAME")
  readonly property string currentBackgroundLink: stateHome + "/omarchy/current/background"

  property bool lockRequested: false
  property bool pendingSessionLock: false
  property bool authenticatingPassword: false
  property bool fingerprintAuthenticating: false
  property bool faceAuthenticating: false
  // Face retries on its own after a miss, but not forever: a camera that
  // errors out at once would otherwise spin the PAM stack four times a
  // second for as long as the screen stays locked. Enter on an empty field
  // or the face button starts a fresh round.
  readonly property int faceRetryLimit: 5
  property int faceMisses: 0
  property bool passwordPamConfigured: false
  property bool fingerprintConfigured: false
  property bool faceConfigured: false
  // Security-key unlock is a mode the user is in. It does not run alongside
  // the password: pam_u2f gets its own PAM service and its own context, since
  // sharing omarchy-lock-password would send every mistyped password to the
  // key as a PIN attempt, and a key locks itself out after eight.
  property string authMode: "password" // "password" | "fido2"
  // Picked once per lock by the probe; a later probe never overrides a choice.
  property bool authModeSettled: false
  // What the probe found, and what the lock screen does with it. Everything
  // downstream reads fido2Configured, so the Settings toggle only has to turn
  // this one property off.
  property bool fido2Installed: false
  readonly property bool fido2Configured: fido2Installed && fido2Enabled
  property bool fido2TokenPresent: false
  property bool fido2Authenticating: false
  property bool fido2NeedsPin: false
  property string fido2Status: ""
  // What the fingerprint reader is saying, in pam_fprintd's own words: "Place
  // your finger on the fingerprint reader", "Failed to match fingerprint".
  // Empty while no scan is running. The fido2Status of the fingerprint path.
  property string fingerprintStatus: ""
  property bool fingerprintStatusIsError: false
  property string fingerprintPendingStatus: ""

  // A failed match is followed within a moment by the next attempt's prompt,
  // which would wipe it before anyone could read it. It is held on screen for
  // a beat, with the prompt that arrives meanwhile queued behind it. None of
  // it wakes the display: the prompt repeats after every attempt, and
  // pam_fprintd reports its own periodic timeout as an error too, so waking
  // on either would keep a blanked screen lit for as long as it is locked.
  // What a PAM module says is shown on the lock screen, so it is treated as
  // foreign text: the first line only, capped, and every design renders it as
  // PlainText. A module that sends markup, a novel or a screenful of newlines
  // cannot reshape the lock screen with it.
  readonly property int pamMessageMax: 120

  function pamMessageText(raw) {
    var text = String(raw || "").replace(/\s+/g, " ").trim()
    return text.length > pamMessageMax ? text.substring(0, pamMessageMax - 1) + "…" : text
  }

  function handleFingerprintMessage() {
    if (!lockRequested) return
    var text = pamMessageText(fingerprintPam.message)
    if (text.length === 0) return
    if (fingerprintPam.messageIsError) {
      fingerprintPendingStatus = ""
      fingerprintStatus = text
      fingerprintStatusIsError = true
      fingerprintErrorHold.restart()
      return
    }
    if (fingerprintErrorHold.running) {
      fingerprintPendingStatus = text
      return
    }
    fingerprintStatus = text
    fingerprintStatusIsError = false
  }

  function clearFingerprintStatus() {
    fingerprintErrorHold.stop()
    fingerprintPendingStatus = ""
    fingerprintStatus = ""
    fingerprintStatusIsError = false
  }
  // Last thing pam_u2f said that did not want an answer, i.e. the cue.
  property string fido2Cue: ""
  // PIN attempts in this lock. A wrong PIN costs one of the key's retries,
  // and the key itself refuses further PINs after three in a row until it is
  // replugged, so the screen stops offering it at the same point and asks for
  // the password. Attempts that never reached a PIN (no touch, no key) are
  // free and do not count.
  property int fido2PinAttempts: 0
  property bool fido2PinSubmitted: false
  readonly property int fido2PinAttemptLimit: 3
  // pam_u2f waits about 30s for a touch and then returns PamResult.Failed --
  // the same code a touch that did not verify gives. A round that ran the
  // whole wait with no PIN typed is the no-touch case, and it spends nothing:
  // no PIN retry, no on-key biometric retry. Anything shorter had a user in it.
  readonly property int fido2NoTouchMs: 20000
  property real fido2RoundStarted: 0
  // A touch that did not verify costs one of the key's own UV retries, not a
  // PIN retry, and the key caps those itself and resets them on a match. The
  // round is offered again rather than the user having to Tab back, and this
  // many in a row is the key at its own limit: hand over the password.
  readonly property int fido2TouchRetryLimit: 3
  property int fido2TouchMisses: 0
  // A failed round with no PIN in it waits here while the probe says whether
  // the key is still attached; see handleFido2Finished.
  property bool fido2FailurePending: false
  readonly property bool fido2Exhausted: fido2PinAttempts >= fido2PinAttemptLimit
  readonly property bool fido2Active: authMode === "fido2"
  property bool previewVisible: false
  property string enteredPassword: ""
  property string pendingPassword: ""
  property string failureMessage: ""
  property int failedAttempts: 0
  property string backgroundPath: ""
  property int backgroundVersion: 0
  property string lastEvent: "init"
  property string lastEventAt: ""
  property bool strandedLock: false
  property bool strandedLockResolved: false
  property bool unlocking: false
  // The clip designs (Storm, Eyes, ...) hold the lock surface while their
  // video plays through as the unlock. unlockPlayback reaches the design,
  // clipUnlocking is the hold, clipFailsafe the way out if the file misbehaves.
  property bool clipUnlocking: false
  property bool unlockPlayback: false
  property bool previewClipPlaying: false
  // Nothing should decode video into a screen that is switched off.
  property bool screenBlanked: false
  // The layout being typed on, as a short code ("DK"), and whether that is
  // something other than a plain US keyboard. A password is typed blind, so a
  // layout switched since last time is invisible without this: the field shows
  // the code when it is not US. Read from Hyprland, which is what the session
  // is running under; anywhere else this stays empty and nothing is shown.
  property string keyboardLayout: ""
  // Caps lock, the other thing a password typed blind cannot show. The state
  // is read from Hyprland, never inferred from a key: Omarchy maps Caps Lock
  // to Compose by default (`compose:caps`), so the key that looks like it
  // toggles caps usually does not, and a lock screen that says CAPS when it
  // does not is worse than one that says nothing. Hyprland raises no event
  // for it either, so the lock screen asks while someone is typing into it,
  // at most this often.
  property bool capsLock: false
  readonly property int capsProbeInterval: 1500
  property double lastCapsProbe: 0

  function probeCapsLock() {
    var now = Date.now()
    if (now - lastCapsProbe < capsProbeInterval) return
    lastCapsProbe = now
    refreshKeyboardLayout()
  }
  readonly property bool foreignLayout: keyboardLayout.length > 0 && keyboardLayout !== "US"
  // With more than one layout configured the badge in the field switches to
  // the next one when clicked, the same as Hyprland's own layout toggle.
  property int keyboardLayoutCount: 1
  property string keyboardDevice: ""

  Process {
    id: switchLayoutProc
    command: ["hyprctl", "switchxkblayout", root.keyboardDevice.length > 0 ? root.keyboardDevice : "all", "next"]
    onExited: root.refreshKeyboardLayout()
  }

  function switchKeyboardLayout() {
    if (keyboardLayoutCount < 2 || switchLayoutProc.running) return false
    switchLayoutProc.running = true
    logEvent("layout-switch")
    return true
  }

  function refreshKeyboardLayout() {
    if (!keyboardLayoutProc.running) keyboardLayoutProc.running = true
  }

  // Keys pressed into a dark panel only wake it: the field stays inert until
  // the wake has run and the panel has had wakeInputGrace to light up, so the
  // keystrokes that switched the screen on never land in the password.
  property bool inputBlocked: false

  // With `misc:session_lock_xray` the compositor keeps drawing the desktop
  // under the lock surface, so the unlock fades straight into it and the
  // wallpaper the animation otherwise lands on would only be in the way.
  property bool sessionLockXray: false

  readonly property bool locked: lockRequested || sessionLock.locked || sessionLock.secure
  readonly property bool authenticating: authenticatingPassword || fingerprintAuthenticating || faceAuthenticating || fido2Authenticating

  function realScreenCount() {
    var screens = Quickshell.screens || []
    var count = 0

    for (var i = 0; i < screens.length; i++) {
      var screen = screens[i]
      if (screen && screen.name && screen.width > 0 && screen.height > 0) count += 1
    }

    return count
  }

  function hasRealScreen() {
    return realScreenCount() > 0
  }

  function queueSessionLock() {
    pendingSessionLock = true
    if (!sessionLockStabilizeTimer.running) logEvent("lock-pending: screen-stabilizing")
    sessionLockStabilizeTimer.restart()
    if (!pendingSessionLockTimer.running) pendingSessionLockTimer.start()
  }

  function requestSessionLock() {
    // Only this copy's own request counts. `secure` can already be true with
    // no surface of ours -- a copy of this service that held the lock was
    // reloaded away, and Hyprland is showing its crashed-lock screen -- and
    // waiting on it then leaves that screen up for good.
    if (!lockRequested || sessionLock.locked) return
    if (sessionLockStabilizeTimer.running) return

    if (!hasRealScreen()) {
      if (!pendingSessionLock || lastEvent !== "lock-pending: no-real-screen") logEvent("lock-pending: no-real-screen")
      pendingSessionLock = true
      if (!pendingSessionLockTimer.running) pendingSessionLockTimer.start()
      return
    }

    pendingSessionLock = false
    pendingSessionLockTimer.stop()
    sessionLock.locked = true
  }

  // ext-session-lock outlives its client, and a restart carries no lock over, so
  // a session locked this early is an orphan behind Hyprland's failsafe. Outputs
  // are often still absent here, so ask until the answer means something.
  function checkStrandedLock() {
    if (strandedLockResolved || strandedLockCheckProc.running) return

    // A lock this shell took is nobody's orphan.
    if (locked || lockRequested) {
      strandedLockResolved = true
      return
    }

    strandedLockCheckProc.running = true
  }

  // Which copy of this service holds the lock. Omarchy hot-reloads a local
  // plugin when its files change and can run the new copy next to the old one
  // for a while; a lock the old copy holds is not an orphan, and locking again
  // from the new one leaves a second lock that never comes up. The holder says
  // so once a second in this file; a check that finds the session locked and
  // the claim fresh and someone else's waits, and takes over only once the
  // claim goes stale -- the holder gone with the session still locked.
  // The account's full name, for the designs' greetings (DesignBase.displayName).
  property string accountName: ""
  Process {
    id: accountNameProc
    running: true
    command: ["bash", "-c", "getent passwd -- \"$(id -un)\" | cut -d: -f5 | cut -d, -f1"]
    stdout: StdioCollector {
      waitForEnd: true
      onStreamFinished: root.accountName = String(text || "").trim().substring(0, 80)
    }
  }

  readonly property string lockClaimPath: (Quickshell.env("XDG_RUNTIME_DIR") || "/tmp") + "/omarchy-lock-explorer.lock-held"
  readonly property string instanceToken: String(Date.now()) + "-" + String(Math.floor(Math.random() * 1e9))
  readonly property bool holdsLock: sessionLock.locked || sessionLock.secure

  FileView {
    id: lockClaim
    path: root.lockClaimPath
    atomicWrites: true
    printErrors: false
  }

  Timer {
    id: lockClaimHeartbeat
    interval: 1000
    repeat: true
    triggeredOnStart: true
    running: root.holdsLock
    onTriggered: lockClaim.setText(root.instanceToken + "\n")
  }

  onHoldsLockChanged: if (!holdsLock) lockClaim.setText("")

  // A claim that was fresh: ask again until it is released or goes stale.
  Timer {
    id: strandedDeferTimer
    interval: 1500
    onTriggered: root.checkStrandedLock()
  }

  function recoverStrandedLock() {
    if (!strandedLock || locked || !passwordPamConfigured) return

    strandedLock = false
    logEvent("lock-stranded: recovering")
    beginLock()
  }

  function refreshBackground() {
    if (!readlinkProc.running) readlinkProc.running = true
  }

  function refreshFingerprintStatus() {
    if (!fingerprintCheckProc.running) fingerprintCheckProc.running = true
  }

  function refreshFaceStatus() {
    if (!faceCheckProc.running) faceCheckProc.running = true
  }

  // A probe already running is not an answer to a request made after it
  // started, so the request is queued and the probe runs once more.
  // Capped: a flapping hidraw device (a bad cable, a receiver reconnecting)
  // could otherwise keep every answer discarded and a pending failure or the
  // next round waiting on it for good.
  property bool fido2ProbeQueued: false
  property int fido2ProbeReruns: 0
  readonly property int fido2ProbeRerunLimit: 2
  function refreshFido2Status() {
    if (fido2CheckProc.running) fido2ProbeQueued = true
    else fido2CheckProc.running = true
  }

  function refreshSessionLockXray() {
    if (!sessionLockXrayProc.running) sessionLockXrayProc.running = true
  }

  function logEvent(event) {
    lastEvent = event
    lastEventAt = new Date().toISOString()
    console.log("omarchy lock " + lastEventAt + " " + event)
  }

  function resetAuthenticationState() {
    enteredPassword = ""
    pendingPassword = ""
    failureMessage = ""
    failedAttempts = 0
    failureTimes = []
    fido2FailurePending = false
    authenticatingPassword = false
    fingerprintAuthenticating = false
    fingerprintRetryTimer.stop()
    clearFingerprintStatus()
    faceMisses = 0
    faceRetryTimer.stop()
    if (passwordPam.active) passwordPam.abort()
    if (fingerprintPam.active) fingerprintPam.abort()
    if (facePam.active) facePam.abort()
    abortFido2()
    fido2PinAttempts = 0
    fido2PinSubmitted = false
    fido2TouchMisses = 0
    authMode = "password"
    authModeSettled = false
  }

  function beginLock() {
    if (!passwordPamConfigured) {
      logEvent("lock-denied: missing-pam")
      return false
    }

    cancelUnlockAnimation()
    resetAuthenticationState()
    inputBlocked = false
    inputUnblockTimer.stop()
    lockRequested = true
    lockedAt = Date.now()
    lastFaceRound = 0
    armBlankTimer()
    logEvent("lock-requested")
    queueSessionLock()

    Qt.callLater(function() {
      root.refreshBackground()
      root.refreshFingerprintStatus()
      root.refreshFaceStatus()
      root.refreshFido2Status()
      root.refreshKeyboardLayout()
      root.refreshSessionLockXray()
      root.rescanUserDesigns()
      // The frame is ready before the unlock needs it.
      if (root.designHasClip) root.prepareClipWallpaper(root.designClipPath)
      else if (root.stingPath.length > 0) root.prepareClipWallpaper(root.stingPath)
    })

    return true
  }

  function finishUnlock() {
    if (!root.locked && !lockRequested) return
    if (unlocking || clipUnlocking) return

    var away = awayReport ? awayFailures(Date.now()) : []
    pendingAwayReport = away.length > 0 ? away : null
    lockRequested = false
    pendingSessionLock = false
    sessionLockStabilizeTimer.stop()
    pendingSessionLockTimer.stop()
    resetAuthenticationState()
    idleBlankTimer.stop()
    runWake()

    // The surface has to stay up while it animates away -- dropping the lock
    // first takes the screen with it. The timer also releases the lock if the
    // animation never runs, so nothing can leave the session stuck behind it.
    // A clip design keeps the surface and plays its video as the unlock. The
    // design says when it is done; the failsafe does not care what it thinks.
    // Without qt6-multimedia a clip design has already fallen back to
    // Classic, so unlock instantly instead of waiting on the clip failsafe.
    // Reduce motion means no moving unlock either: no clip, no animation.
    if (designHasClip && multimediaAvailable && !motionReduced && (sessionLock.locked || sessionLock.secure)) {
      clipUnlocking = true
      unlockPlayback = true
      clipFailsafe.restart()
      // Second chance for designs picked while already locked.
      if (preparedClipWallpaper.length === 0) prepareClipWallpaper(designClipPath)
      logEvent("unlocking=clip")
      return
    }

    if (unlockAnimated && !motionReduced && (sessionLock.locked || sessionLock.secure)) {
      unlocking = true
      logEvent("unlocking=" + unlockAnimation)
      unlockTimer.restart()
      return
    }

    releaseLock()
  }

  function releaseLock() {
    unlockTimer.stop()
    clipFailsafe.stop()
    var hadClip = clipUnlocking
    clipUnlocking = false
    unlockPlayback = false
    unlocking = false
    sessionLock.locked = false
    logEvent("unlocked")
    if (pendingAwayReport) sendAwayReport(pendingAwayReport)
    pendingAwayReport = null
    // The clip was the whole show, no second video on top of it; and none at
    // all while motion is reduced.
    if (hadClip) commitClipWallpaper()
    else if (!motionReduced) playSting()
  }

  function cancelUnlockAnimation() {
    if (!unlocking && !clipUnlocking) return
    unlockTimer.stop()
    clipFailsafe.stop()
    unlocking = false
    clipUnlocking = false
    unlockPlayback = false
    logEvent("unlock-cancelled")
  }

  function armBlankTimer() {
    idleBlankTimer.armedAt = Date.now()
    idleBlankTimer.restart()
  }

  function runWake() {
    var wasBlanked = screenBlanked
    screenBlanked = false
    // A panel coming back is the moment to look: the lid just opened, or
    // somebody touched the machine. Locking with the screen already on is
    // not, unless the setting says otherwise.
    if (lockRequested && sessionLock.secure && faceStart !== "off") {
      var now = Date.now()
      if (wasBlanked
          || (faceStart === "wake" && now - lockedAt > faceWakeQuiet && now - lastFaceRound > faceRoundGap))
        Qt.callLater(retryFace)
    }
    if (wasBlanked && lockRequested && sessionLock.secure) Qt.callLater(retryFido2)
    // Failsafe: a wake that never exits must not leave the field inert.
    if (inputBlocked && !inputUnblockTimer.running) {
      inputUnblockTimer.interval = 3000
      inputUnblockTimer.restart()
    }
    if (!wakeProcess.running) wakeProcess.running = true
    if (lockRequested) armBlankTimer()
  }

  function runBlank() {
    if (keepDisplayOn) return
    screenBlanked = !displayBlankingSuppressed
    inputBlocked = screenBlanked
    inputUnblockTimer.stop()
    // Nothing to authenticate to while the panel is dark: drop the scan and
    // let go of the camera until it comes back.
    if (screenBlanked) stopFace()
    if (!blankProcess.running) blankProcess.running = true
  }

  function submitPassword(value) {
    var password = String(value || "")
    // A password submitted while on the key (emergency field, custom design)
    // is a password: leave key mode first so it never meets fido2Pam.
    if (password.length > 0 && fido2Active) setAuthMode("password")
    if (!lockRequested || authenticatingPassword || password.length === 0) {
      if (password.length === 0 && faceConfigured) root.retryFace()
      return
    }

    runWake()
    pendingPassword = password
    failureMessage = ""
    authenticatingPassword = true

    if (!passwordPam.start()) {
      handlePasswordFailure()
      return
    }

    Qt.callLater(respondToPasswordPrompt)
  }

  function respondToPasswordPrompt() {
    if (!authenticatingPassword || !passwordPam.active || !passwordPam.responseRequired) return
    passwordPam.respond(pendingPassword)
  }

  function handlePasswordFailure() {
    if (!lockRequested) return

    authenticatingPassword = false
    enteredPassword = ""
    pendingPassword = ""
    failedAttempts += 1
    failureTimes = failureTimes.concat([Date.now()])
    failureMessage = t("Authentication failed (%1)").arg(failedAttempts)
    runWake()
  }

  function startFingerprint() {
    if (!lockRequested || !sessionLock.secure || !fingerprintConfigured) return
    if (fingerprintPam.active || fingerprintAuthenticating) return

    fingerprintAuthenticating = true
    if (!fingerprintPam.start()) {
      fingerprintAuthenticating = false
    }
  }

  function handleFingerprintFinished(result) {
    fingerprintAuthenticating = false

    if (!lockRequested) return
    if (result === PamResult.Success) {
      finishUnlock()
    } else if (fingerprintConfigured) {
      fingerprintRetryTimer.restart()
    }
  }

  // The camera runs only behind a lock screen someone can actually see: a
  // dark panel means nobody is in front of it, and a scan there is a camera
  // on for no one. Blanking stops the round; the wake starts a fresh one.
  function startFace() {
    if (!lockRequested || !sessionLock.secure || !faceConfigured) return
    // "off" stops the automatic rounds, not the face button or Enter on an
    // empty field, which come through retryFace.
    if (screenBlanked) return
    if (facePam.active || faceAuthenticating) return

    faceAuthenticating = true
    lastFaceRound = Date.now()
    if (!facePam.start()) faceAuthenticating = false
  }

  // Wake and retry ask the probe rather than trusting the last answer: a key
  // that left while the session slept is otherwise still "present", and the
  // first round after wake is charged for it. The probe starts the round.
  function retryFido2() {
    fido2TouchMisses = 0
    refreshFido2Status()
  }

  function retryFace() {
    faceMisses = 0
    startFace()
  }

  function stopFace() {
    faceRetryTimer.stop()
    faceMisses = 0
    if (facePam.active) facePam.abort()
    faceAuthenticating = false
  }

  function handleFaceFinished(result) {
    faceAuthenticating = false

    if (!lockRequested) return
    // A result from a round the blanking cut short says nothing about who is
    // in front of the screen now.
    if (screenBlanked) return
    if (result === PamResult.Success) {
      finishUnlock()
    } else {
      faceMissed()
    }
  }

  function faceMissed() {
    if (!lockRequested || !faceConfigured || screenBlanked) return
    faceMisses += 1
    if (faceMisses < faceRetryLimit) faceRetryTimer.restart()
    else logEvent("face-paused after " + faceMisses + " misses")
  }

  // Key mode when a key is enrolled and plugged in at lock time, password
  // otherwise. Runs from the probe, not beginLock(): the answer is a
  // subprocess away when the lock is requested.
  function settleAuthMode() {
    if (authModeSettled || !lockRequested) return
    if (!fido2Configured || !fido2TokenPresent || fido2Exhausted) return
    if (authenticatingPassword || enteredPassword.length > 0) return
    setAuthMode("fido2")
  }

  function setAuthMode(mode) {
    if (mode !== "password" && mode !== "fido2") return
    // Never yank the field while a password check is in flight.
    if (authenticatingPassword) return
    var switching = authMode !== mode && !(mode === "fido2" && !fido2Configured)
    if (switching) {
      if (authMode === "fido2") abortFido2()
      authMode = mode
      failureMessage = ""
      enteredPassword = ""
      pendingPassword = ""
      logEvent("auth-mode=" + mode)
    }
    // A request for a mode that cannot be entered still settles, so a later
    // probe does not override what the user asked for. A key plugged in
    // afterwards is still offered to an empty field; see fido2CheckProc.
    authModeSettled = true
  }

  // Glyph click, Tab from the password, Enter on the inert field: switch to
  // the key if not there yet, then look for it again and start. The probe's
  // onExited does the starting.
  function requestFido2() {
    if (!lockRequested || !fido2Configured) return
    if (fido2Exhausted) {
      failureMessage = t("Use your password")
      return
    }
    if (!fido2Active) setAuthMode("fido2")
    if (!fido2Active || fido2Authenticating) return
    failureMessage = ""
    fido2Status = t("Looking for your key…")
    refreshFido2Status()
  }

  // Same reasoning as startFace: a dark panel means nobody is in front of it,
  // and a key blinking there is asking for a finger that is not coming.
  // Blanking ends the round; the wake starts a fresh one.
  function startFido2() {
    // Same gate as startFingerprint: a success before the surface is secure
    // would unlock a lock that never took.
    if (!lockRequested || !sessionLock.secure) return
    if (!fido2Active || !fido2Configured || fido2Exhausted) return
    if (fido2Pam.active || fido2Authenticating) return
    if (screenBlanked) return
    if (!fido2TokenPresent) {
      fido2Status = t("No security key found")
      return
    }

    // Anything typed before the key was found would be read-only in the field
    // from here on and end up in front of the PIN, costing a retry for nothing.
    enteredPassword = ""
    fido2NeedsPin = false
    fido2PinSubmitted = false
    fido2Cue = ""
    fido2Status = t("Waiting for your key…")
    fido2Authenticating = true
    fido2RoundStarted = Date.now()
    if (!fido2Pam.start()) {
      fido2Authenticating = false
      fido2Status = t("Could not start the key")
    }
  }

  function abortFido2() {
    // Cleared before abort(): whatever completed/error the abort emits is
    // then ignored by handleFido2Finished instead of counted as a failure.
    fido2Authenticating = false
    fido2NeedsPin = false
    fido2Status = ""
    fido2Cue = ""
    if (fido2Pam.active) fido2Pam.abort()
  }

  // pam_u2f asks for the PIN with a prompt that wants a response and announces
  // the touch with one that does not. The kind decides, never the wording.
  // It says nothing after a PIN is accepted, even though it then waits for a
  // touch, so the cue it did send is kept and put back at that point.
  function handleFido2Message() {
    if (!fido2Authenticating) return
    // Only the PIN prompt is asking the user for something. Waking on the
    // touch cue instead re-arms the blank timer once per round, so a lock with
    // a key plugged in would never go dark.
    if (fido2Pam.responseRequired) runWake()

    if (fido2Pam.responseRequired) {
      fido2NeedsPin = true
      fido2Status = t("Enter the PIN for your key")
      return
    }

    fido2NeedsPin = false
    var text = pamMessageText(fido2Pam.message)
    if (text.length > 0) {
      fido2Cue = text
      fido2Status = text
    }
  }

  function submitFido2Pin(pin) {
    var value = String(pin || "")
    if (!fido2Active || !fido2Authenticating || value.length === 0) return
    if (!fido2Pam.active || !fido2Pam.responseRequired) return

    fido2Pam.respond(value)
    fido2NeedsPin = false
    fido2PinSubmitted = true
    enteredPassword = ""
    // Not "Checking…": the key is lit and waiting for a finger, and the only
    // other sign of that is the light on the key itself.
    fido2Status = fido2Cue.length > 0 ? fido2Cue : "Touch your security key"
  }

  function handleFido2Finished(result) {
    if (!fido2Authenticating) return

    fido2Authenticating = false
    fido2NeedsPin = false
    enteredPassword = ""

    var elapsed = fido2RoundStarted ? Date.now() - fido2RoundStarted : 0
    fido2RoundStarted = 0

    if (!lockRequested) return
    // A touch is unambiguous even in the dark, so a success still unlocks.
    if (result === PamResult.Success) {
      finishUnlock()
      return
    }

    // A result from a round the blanking cut short says nothing about who is
    // in front of the screen now, and waking the panel to report it would
    // light the lock up for no one.
    if (screenBlanked) {
      fido2Status = ""
      logEvent("fido2-round dropped, screen dark")
      return
    }

    // Nobody touched the key: the module waited its whole time and gave up.
    // Nothing was spent and nobody tried, so it is not held against the user
    // and the round simply starts again -- otherwise a lock left alone for
    // longer than that wait looks like it is still on the key while nothing
    // is listening, and Tab is the only way back.
    if (!fido2PinSubmitted && elapsed >= fido2NoTouchMs) {
      fido2Status = ""
      logEvent("fido2-round again after " + elapsed + "ms")
      fido2RetryTimer.restart()
      return
    }

    // A key pulled out mid-round fails it at once, and so does every retry
    // after it: counted as misses, three of those arrive within a second and
    // a half, park the lock on the password, stop the hotplug watcher, and
    // report three failed attempts when nobody tried anything. A round with
    // no PIN in it asks the probe first; see fido2FailureChecked.
    // PAM can see the USB loss before udev removes the node, so a probe sent
    // at once can still find the key and charge a miss for an unplug. Give
    // it the same settle the hotplug path uses before asking.
    if (!fido2PinSubmitted) {
      fido2FailurePending = true
      fido2FailureSettle.restart()
      return
    }
    countFido2Failure()
  }

  // The probe answered for a round that failed without a PIN. Gone: say so,
  // stay on the key, and let the hotplug watcher (which runs while the key is
  // absent in key mode) start the next round when it is back. Still there:
  // it was a real miss.
  function fido2FailureChecked() {
    fido2FailurePending = false
    if (!lockRequested) return
    if (!fido2TokenPresent) {
      fido2Status = t("No security key found")
      failureMessage = ""
      logEvent("fido2-round ended, key removed")
      runWake()
      return
    }
    countFido2Failure()
  }

  function countFido2Failure() {
    // A PIN that went to the key is still the user's to spend again.
    var pinWasSubmitted = fido2PinSubmitted
    failedAttempts += 1
    failureTimes = failureTimes.concat([Date.now()])
    if (fido2PinSubmitted) fido2PinAttempts += 1
    fido2PinSubmitted = false
    fido2Status = ""
    if (fido2Exhausted) {
      // Three PINs went to the key in this lock. Whether they were wrong or a
      // bystander was guessing, the key is at its own limit and the rest of
      // its retries are not the lock screen's to spend. Back to the password;
      // setAuthMode clears failureMessage, so the message goes after it.
      setAuthMode("password")
      failureMessage = t("Use your password")
      logEvent("fido2-exhausted")
    } else {
      failureMessage = t("Security key failed (%1)").arg(failedAttempts)
      if (!pinWasSubmitted && fido2Active && fido2TokenPresent) {
        fido2TouchMisses += 1
        if (fido2TouchMisses < fido2TouchRetryLimit) fido2RetryTimer.restart()
        else {
          setAuthMode("password")
          // Short: the field elides, and the switch to the password is what
          // says where to go next.
          failureMessage = t("Too many tries")
          logEvent("fido2-paused after " + fido2TouchMisses + " misses")
        }
      }
    }
    runWake()
  }

  WlSessionLock {
    id: sessionLock

    locked: false

    onSecureStateChanged: {
      root.logEvent("secure=" + secure)
      if (secure) {
        root.pendingSessionLock = false
        sessionLockStabilizeTimer.stop()
        pendingSessionLockTimer.stop()
        root.startFingerprint()
        if (root.faceStart === "always") root.startFace()
        root.startFido2()
      }
    }

    onLockStateChanged: {
      root.logEvent("session-locked=" + locked)

      if (locked) {
        root.pendingSessionLock = false
        sessionLockStabilizeTimer.stop()
        pendingSessionLockTimer.stop()
      }

      if (!locked && root.lockRequested) {
        root.lockRequested = false
        root.pendingSessionLock = false
        sessionLockStabilizeTimer.stop()
        pendingSessionLockTimer.stop()
        root.resetAuthenticationState()
        root.runWake()
      }
    }

    WlSessionLockSurface {
      id: lockSurface
      color: Color.background

      UnlockLayer {
        anchors.fill: parent
        animation: root.unlockAnimation
        duration: root.unlockDuration
        active: root.unlocking
        backgroundUrl: root.locked && !root.sessionLockXray ? root.backgroundUrl : ""

        LockHost {
          id: lockView
          anchors.fill: parent
          fadeIn: true
          designId: root.showsInput(lockSurface.screen) ? root.designId : "companion"
          revision: root.designsRevision
          backgroundPath: root.backgroundPath
          backgroundVersion: root.backgroundVersion
          avatarPath: root.avatarPath
          avatarVersion: root.avatarVersion
          fingerprintConfigured: root.fingerprintConfigured
          keyboardLayout: root.keyboardLayout
          keyboardLayoutCount: root.keyboardLayoutCount
          batteryLow: root.batteryLow
          batteryPercent: root.batteryPercent
          onLayoutSwitchRequested: root.switchKeyboardLayout()
          capsLock: root.capsLock
          onCapsProbeRequested: root.probeCapsLock()
          powerActions: root.powerActions
          onPowerActionRequested: function(action) { root.runPowerAction(action) }
          faceConfigured: root.faceConfigured
          fido2Configured: root.fido2Configured
          fido2Active: root.fido2Active
          fido2Authenticating: root.fido2Authenticating
          fido2NeedsPin: root.fido2NeedsPin
          fido2Status: root.fido2Status
          fingerprintStatus: root.fingerprintStatus
          fingerprintStatusIsError: root.fingerprintStatusIsError
          authenticatingPassword: root.authenticatingPassword
          failureMessage: root.failureMessage
          failedAttempts: root.failedAttempts
          inputEnabled: root.lockRequested
          inputBlocked: root.inputBlocked
          loadBackground: root.locked
          passwordText: root.enteredPassword
          videoPath: root.videoPath
          videoPlaying: root.locked && !root.screenBlanked
          screenAwake: !root.screenBlanked
          unlockPlayback: root.unlockPlayback && root.showsInput(lockSurface.screen)
          clipSpeed: root.clipSpeed
          twelveHour: root.twelveHour
          wallpaperBlur: root.wallpaperBlurValue
          wallpaperDim: root.wallpaperDimShift
          uiScale: root.uiScale
          holdStill: root.motionReduced
          language: root.language
          fullName: root.accountName
          showLayoutBadge: root.showLayoutBadge
          showCapsBadge: root.showCapsBadge
          allowPasswordToggle: root.allowPasswordToggle
          showAuthIcons: root.showAuthIcons
          onUnlockFinished: root.releaseLock()
          onPasswordTextEdited: function(password) { root.enteredPassword = password }
          onSubmitPassword: function(password) { root.submitPassword(password) }
          onClearFailureRequested: root.failureMessage = ""
          onWakeRequested: root.runWake()
          onFaceRequested: root.retryFace()
          onFido2Requested: root.requestFido2()
          onPasswordRequested: root.setAuthMode("password")
          onSubmitFido2Pin: function(pin) { root.submitFido2Pin(pin) }
        }
      }
    }
  }

  PanelWindow {
    id: previewWindow
    visible: root.previewVisible
    anchors { top: true; bottom: true; left: true; right: true }
    color: "transparent"
    WlrLayershell.namespace: "omarchy-lock-explorer-preview"
    WlrLayershell.layer: WlrLayer.Overlay
    WlrLayershell.keyboardFocus: WlrKeyboardFocus.Exclusive
    exclusionMode: ExclusionMode.Ignore

    UnlockLayer {
      anchors.fill: parent
      animation: root.unlockAnimation
      duration: root.unlockDuration
      active: root.previewUnlocking

      LockHost {
        anchors.fill: parent
        designId: root.previewDesignId.length > 0 ? root.previewDesignId : root.designId
        revision: root.designsRevision
        backgroundPath: root.backgroundPath
        backgroundVersion: root.backgroundVersion
        avatarPath: root.avatarPath
        avatarVersion: root.avatarVersion
        fingerprintConfigured: root.fingerprintConfigured
        authenticatingPassword: false
        failureMessage: root.previewFailure
        failedAttempts: root.previewFailure.length > 0 ? 1 : 0
        inputEnabled: root.previewVisible && !root.previewUnlocking
        loadBackground: root.previewVisible
        passwordText: root.previewTyped
        videoPath: root.videoPath
        videoPlaying: root.previewVisible
        faceConfigured: root.faceConfigured
        fido2Configured: root.fido2Configured
        unlockPlayback: root.previewClipPlaying
        clipSpeed: root.clipSpeed
        twelveHour: root.twelveHour
        wallpaperBlur: root.wallpaperBlurValue
        wallpaperDim: root.wallpaperDimShift
        uiScale: root.uiScale
        holdStill: root.motionReduced
        language: root.language
        fullName: root.accountName
        showLayoutBadge: root.showLayoutBadge
        showCapsBadge: root.showCapsBadge
        allowPasswordToggle: root.allowPasswordToggle
        showAuthIcons: root.showAuthIcons
        batteryLow: root.batteryLow
        batteryPercent: root.batteryPercent
        // Hold the clip's last frame in the preview instead of snapping back
        // to the start; Esc (hidePreview) resets it.
        onUnlockFinished: {}
        onPasswordTextEdited: function(password) { root.previewTyped = password }
        onFaceRequested: root.retryFace()
      }
    }

    MouseArea {
      anchors.fill: parent
      acceptedButtons: Qt.LeftButton | Qt.RightButton
      onClicked: { root.previewVisible = false; root.previewDesignId = "" }
    }
  }

  // The unlock clip window (see StingWindow.qml). It is the only part of the
  // service that touches QtMultimedia, so it loads through this Loader:
  // without qt6-multimedia the load fails, the video features switch off and
  // the rest of the service — the lock screen and the `lock` IPC target —
  // carries on. Importing QtMultimedia at the top of this file instead would
  // take the whole service down with a bare "Target not found".
  readonly property bool multimediaAvailable: stingLoader.status === Loader.Ready

  Loader {
    id: stingLoader
    source: Qt.resolvedUrl("StingWindow.qml")
    onLoaded: item.lock = root
    onStatusChanged: {
      if (status === Loader.Error) {
        console.warn("lock-explorer: qt6-multimedia is not installed; video designs and unlock clips are disabled."
          + " Install it with `sudo pacman -S qt6-multimedia`, then run `omarchy restart shell`.")
      }
    }
  }

  PamContext {
    id: passwordPam
    config: "omarchy-lock-password"
    user: root.userName

    onResponseRequiredChanged: root.respondToPasswordPrompt()
    onPamMessage: root.respondToPasswordPrompt()

    onCompleted: function(result) {
      root.authenticatingPassword = false
      root.pendingPassword = ""

      if (!root.lockRequested) return
      if (result === PamResult.Success) root.finishUnlock()
      else root.handlePasswordFailure()
    }

    onError: function(error) {
      root.handlePasswordFailure()
    }
  }

  PamContext {
    id: fingerprintPam
    config: "omarchy-lock-fingerprint"
    user: root.userName

    onPamMessage: root.handleFingerprintMessage()

    onCompleted: function(result) {
      root.handleFingerprintFinished(result)
    }

    onError: function(error) {
      root.fingerprintAuthenticating = false
      if (root.lockRequested && root.fingerprintConfigured) fingerprintRetryTimer.restart()
    }
  }

  PamContext {
    id: facePam
    config: "omarchy-lock-face"
    user: root.userName

    onCompleted: function(result) {
      root.handleFaceFinished(result)
    }

    onError: function(error) {
      root.faceAuthenticating = false
      root.faceMissed()
    }
  }

  PamContext {
    id: fido2Pam
    config: "omarchy-lock-fido2"
    user: root.userName

    onResponseRequiredChanged: root.handleFido2Message()
    onPamMessage: root.handleFido2Message()

    onCompleted: function(result) {
      root.handleFido2Finished(result)
    }

    onError: function(error) {
      root.handleFido2Finished(PamResult.Error)
    }
  }

  Timer {
    id: unlockTimer
    interval: Math.max(1, root.unlockDuration + 80)
    repeat: false
    onTriggered: root.releaseLock()
  }

  // However long the clip claims to be, the screen comes back.
  Timer {
    id: clipFailsafe
    interval: 15000
    repeat: false
    onTriggered: root.releaseLock()
  }

  Timer {
    id: fingerprintRetryTimer
    interval: 250
    repeat: false
    onTriggered: root.startFingerprint()
  }

  Timer {
    id: fingerprintErrorHold
    interval: 2500
    onTriggered: {
      if (root.fingerprintPendingStatus.length > 0) {
        root.fingerprintStatus = root.fingerprintPendingStatus
        root.fingerprintStatusIsError = false
        root.fingerprintPendingStatus = ""
      } else if (root.fingerprintStatusIsError) {
        root.fingerprintStatus = ""
        root.fingerprintStatusIsError = false
      }
    }
  }

  // Longer than faceRetryTimer: a round that ends the instant it starts would
  // otherwise spin, and nothing here is racing a camera frame.
  Timer {
    id: fido2RetryTimer
    interval: 500
    repeat: false
    onTriggered: root.refreshFido2Status()
  }

  // See handleFido2Finished: the probe for a failed round without a PIN.
  Timer {
    id: fido2FailureSettle
    interval: 400
    repeat: false
    onTriggered: root.refreshFido2Status()
  }

  Timer {
    id: faceRetryTimer
    interval: 250
    repeat: false
    onTriggered: root.startFace()
  }

  // A key plugged in or pulled out while locked has to be noticed, and polling
  // for it would mean spawning a probe every couple of seconds for as long as
  // the screen is locked. This sleeps on the udev netlink socket instead and
  // wakes only when a hidraw device comes or goes. It runs for the whole lock,
  // a round in flight included: watching only while no key was attached left
  // a key pulled mid-round or during sleep cached as present. The probe it
  // asks for never interrupts a running round or half-typed input; see
  // startFido2 and fido2CheckProc. With wakeOnKeyInsert on, an add while the
  // screen is dark goes through keyInsertSettle instead, which wakes the
  // display only when the probe finds the key.
  Process {
    id: fido2HotplugWatch
    running: root.lockRequested && root.fido2Configured
      && (!root.fido2Exhausted || root.wakeOnKeyInsert)
    command: ["udevadm", "monitor", "--udev", "--subsystem-match=hidraw"]
    stdout: SplitParser {
      // "UDEV  [123.4] add  /devices/.../hidraw/hidraw0 (hidraw)"
      onRead: function(line) {
        var text = String(line)
        var added = text.indexOf(" add ") >= 0
        if (!added && text.indexOf(" remove ") < 0) return
        if (added && root.wakeOnKeyInsert && root.screenBlanked) keyInsertSettle.restart()
        else fido2HotplugSettle.restart()
      }
    }
  }

  // udev announces the device before its permissions are in place, so give the
  // node a moment before asking whether libfido2 can open it. Also collapses
  // the burst of events one plug produces into a single probe.
  Timer {
    id: fido2HotplugSettle
    interval: 400
    repeat: false
    onTriggered: root.refreshFido2Status()
  }

  // Lock-on-removal, while unlocked. Wake-on-insert rides on
  // fido2HotplugWatch, which already runs for the whole lock, so the two never
  // run side by side. Any hidraw device comes and goes here -- a mouse
  // receiver, a game pad -- so a removal is only acted on once the probe says
  // the key itself is gone.
  property bool keyEventProbe: false
  property bool keyInsertProbe: false
  Process {
    id: keyEventWatch
    running: root.fido2Configured && root.lockOnKeyRemoval && !root.lockRequested
    command: ["udevadm", "monitor", "--udev", "--subsystem-match=hidraw"]
    // Lock-on-removal compares against the last answer, so that answer has
    // to be current from the moment the watch starts -- after an unlock the
    // key may have come or gone while the lock was up.
    onRunningChanged: if (running && !root.lockRequested) root.refreshFido2Status()
    stdout: SplitParser {
      onRead: function(line) {
        var text = String(line)
        var added = text.indexOf(" add ") >= 0
        var removed = text.indexOf(" remove ") >= 0
        // Unlocked, both directions keep the presence current: a key plugged
        // in after a password unlock has to be known before it can be missed.
        if ((added || removed) && !root.lockRequested) keyEventSettle.restart()
      }
    }
  }

  // Same settle as fido2HotplugSettle: collapses the burst of events one plug
  // produces, and gives the node time to get its permissions.
  Timer {
    id: keyEventSettle
    interval: 400
    repeat: false
    onTriggered: {
      root.keyEventProbe = true
      root.refreshFido2Status()
    }
  }

  // Any HID device can be what went in, so the probe decides: the display
  // wakes only when the key is there (see fido2CheckProc), and the same
  // answer starts the round.
  Timer {
    id: keyInsertSettle
    interval: 400
    repeat: false
    onTriggered: {
      if (!root.lockRequested || !root.screenBlanked) return
      root.keyInsertProbe = true
      root.refreshFido2Status()
    }
  }

  Process {
    id: userDesignsProc
    // Files built on ClipDesign are tagged (with their clip file when it is
    // named inline) so they keep their animation flag and their video across
    // rescans.
    command: ["bash", "-c", "for f in \"$0\"/*.qml; do [ -e \"$f\" ] || continue; c=$(grep -o 'clipName: \"[^\"]*\"' \"$f\" 2>/dev/null | head -1 | cut -d'\"' -f2); if [ -n \"$c\" ]; then printf '%s\\tclip\\t%s\\n' \"$f\" \"$c\"; elif grep -q ClipDesign \"$f\" 2>/dev/null; then printf '%s\\tclip\\n' \"$f\"; elif grep -q '// designer:1:' \"$f\" 2>/dev/null; then printf '%s\\tdesigner\\n' \"$f\"; else printf '%s\\n' \"$f\"; fi; done", root.userDesignsDir]
    stdout: StdioCollector {
      waitForEnd: true
      onStreamFinished: {
        var lines = String(text || "").split("\n").filter(function(l) { return l.trim().length > 0 })
        var list = lines.map(function(l) {
          var parts = l.split("\t")
          var d = Designs.fromUserFile(parts[0].trim())
          if (parts.length > 1 && parts[1].trim() === "clip") { d.anim = true; d.clip = true }
          // Made in the designer: E opens it there instead of in the code editor.
          if (parts.length > 1 && parts[1].trim() === "designer") {
            d.designer = true
            d.description = "Made in the designer"
          }
          if (parts.length > 2 && parts[2].trim().length > 0) d.clipFile = parts[2].trim()
          return d
        })
        var before = JSON.stringify(Designs.USER)
        Designs.setUser(list)
        if (JSON.stringify(list) !== before) root.designsRevision += 1
      }
    }
  }

  Process {
    id: readlinkProc
    command: ["readlink", "-f", root.currentBackgroundLink]
    stdout: StdioCollector {
      waitForEnd: true
      onStreamFinished: {
        var next = String(text || "").trim()
        if (next !== root.backgroundPath) {
          root.backgroundPath = next
          root.backgroundVersion += 1
        }
      }
    }
  }

  // The background is a symlink retarget with no file content to watch, so
  // poll it the way the stock background plugin does. Keeps backgroundPath
  // live for the boot-screen background resync.
  Timer {
    interval: 5000
    running: true
    repeat: true
    onTriggered: root.refreshBackground()
  }

  // A theme switch changes the colors at once and points the link at the new
  // theme's wallpaper with them: look straight away, and once more in case the
  // link moved just after, instead of showing the old wallpaper under the new
  // colors until the next poll -- or missing a theme picked within it.
  readonly property color themeColorProbe: Color.background
  onThemeColorProbeChanged: themeBackgroundTimer.restart()
  Timer {
    id: themeBackgroundTimer
    interval: 150
    onTriggered: { root.refreshBackground(); themeBackgroundLateTimer.restart() }
  }
  Timer {
    id: themeBackgroundLateTimer
    interval: 900
    onTriggered: root.refreshBackground()
  }

  // The active layout of the keyboard being typed on. `layout` is the list
  // from the config ("us,dk") and `active_layout_index` picks from it, which
  // gives a short code without a table to look it up in.
  Process {
    id: keyboardLayoutProc
    command: ["hyprctl", "-j", "devices"]
    stdout: StdioCollector { id: keyboardLayoutStdout; waitForEnd: true }
    onExited: function(exitCode) {
      if (exitCode !== 0) { root.keyboardLayout = ""; return }
      var listed = []
      try {
        listed = JSON.parse(String(keyboardLayoutStdout.text || "{}")).keyboards || []
      } catch (e) {
        root.keyboardLayout = ""
        return
      }
      var kb = null
      for (var i = 0; i < listed.length; i++) {
        if (!listed[i] || !listed[i].active_keymap) continue
        if (listed[i].main === true) { kb = listed[i]; break }
        if (!kb) kb = listed[i]
      }
      if (!kb) { root.keyboardLayout = ""; return }
      var codes = String(kb.layout === undefined ? "" : kb.layout).split(",")
      var at = Number(kb.active_layout_index || 0)
      var code = codes.length > at ? codes[at] : codes[0]
      // Hyprland reports the configured layout verbatim, and a custom XKB
      // layout is a free-form name. The badge bounds what it draws; this
      // bounds what is kept.
      root.keyboardLayout = String(code || "").trim().toUpperCase().substring(0, 24)
      root.keyboardLayoutCount = codes.filter(function(c) { return String(c).trim().length > 0 }).length
      root.keyboardDevice = String(kb.name || "")
      // Older Hyprland does not report it; then it stays off rather than lying.
      root.capsLock = kb.capsLock === true
    }
  }

  // Hyprland announces a layout switch on its event socket, so the code stays
  // right when the layout is toggled with the screen already locked.
  Socket {
    id: hyprEvents
    path: (Quickshell.env("XDG_RUNTIME_DIR") || "/run/user/1000") + "/hypr/"
      + (Quickshell.env("HYPRLAND_INSTANCE_SIGNATURE") || "") + "/.socket2.sock"
    connected: root.locked && (Quickshell.env("HYPRLAND_INSTANCE_SIGNATURE") || "").length > 0
    parser: SplitParser {
      onRead: function(line) {
        if (String(line).indexOf("activelayout") === 0) root.refreshKeyboardLayout()
      }
    }
  }

  Process {
    id: fingerprintCheckProc
    command: ["bash", "-c", "if [[ -f /etc/pam.d/omarchy-lock-fingerprint ]] && command -v fprintd-list >/dev/null 2>&1 && fprintd-list \"$USER\" 2>/dev/null | grep -qi finger; then echo yes; else echo no; fi"]
    stdout: StdioCollector { id: fingerprintCheckStdout; waitForEnd: true }
    onExited: {
      root.fingerprintConfigured = String(fingerprintCheckStdout.text || "").trim() === "yes"
      if (root.lockRequested && root.fingerprintConfigured) root.startFingerprint()
      else if (!root.fingerprintConfigured && fingerprintPam.active) fingerprintPam.abort()
    }
  }

  Process {
    id: faceCheckProc
    command: [root.checkFaceAuthPath, "--yes"]
    stdout: StdioCollector { id: faceCheckStdout; waitForEnd: true }
    onExited: {
      root.faceConfigured = String(faceCheckStdout.text || "").trim() === "yes"
      if (root.lockRequested && root.faceConfigured && root.faceStart === "always") root.startFace()
      else if (!root.faceConfigured && facePam.active) facePam.abort()
    }
  }

  Process {
    id: fido2CheckProc
    command: [root.checkFido2AuthPath]
    stdout: StdioCollector { id: fido2CheckStdout; waitForEnd: true }
    onExited: {
      // A request that arrived while this probe ran may be about a change
      // this probe started too early to see -- a key pulled after it had
      // already listed the devices. Its answer is not acted on; the next one is.
      if (root.fido2ProbeQueued && root.fido2ProbeReruns < root.fido2ProbeRerunLimit) {
        root.fido2ProbeQueued = false
        root.fido2ProbeReruns += 1
        Qt.callLater(function() { fido2CheckProc.running = true })
        return
      }
      root.fido2ProbeQueued = false
      root.fido2ProbeReruns = 0

      var answer = String(fido2CheckStdout.text || "").trim().split(/\s+/)
      var wasPresent = root.fido2TokenPresent
      root.fido2Installed = answer[0] === "yes"
      root.fido2TokenPresent = answer[1] === "present"
      var keyEvent = root.keyEventProbe
      var keyInsert = root.keyInsertProbe
      root.keyEventProbe = false
      root.keyInsertProbe = false

      // Not configured any more wins over a pending failure: the round is
      // moot, and the lock goes back to the password rather than waiting on
      // a key it will not use.
      if (!root.fido2Configured) {
        root.fido2FailurePending = false
        if (root.fido2Active) root.setAuthMode("password")
        return
      }

      // Only a probe a hidraw event asked for can lock: a settings refresh
      // that happens to find no key is not somebody walking away with it.
      if (keyEvent && !root.lockRequested && root.lockOnKeyRemoval
          && wasPresent && !root.fido2TokenPresent) {
        if (root.passwordPamConfigured && !root.locked) {
          root.logEvent("lock-on-key-removal")
          root.beginLock()
        }
        return
      }

      // The device that went in while the screen was dark was the key: it was
      // not there before and is now. With the key left in, a mouse or headset
      // reconnecting would otherwise light the lock for nobody. The watcher
      // sees removals while dark too, so a key that left is known as gone.
      // runWake clears screenBlanked, so the round below can start.
      if (keyInsert && root.lockRequested && root.screenBlanked
          && !wasPresent && root.fido2TokenPresent) {
        root.logEvent("wake-on-key-insert")
        root.runWake()
      }

      if (root.fido2FailurePending) {
        // A probe that finished inside the failure's settle window (one the
        // hotplug watcher asked for, say) may predate the node going away.
        // The one fido2FailureSettle sends decides.
        if (fido2FailureSettle.running) return
        root.fido2FailureChecked()
        return
      }

      if (!root.lockRequested) return
      // A key plugged back in is offered again, even after the user went to
      // the password, but only to an empty field: typed input, a check in
      // flight and a key at its PIN limit are left alone.
      if (!wasPresent && root.fido2TokenPresent && !root.fido2Active && !root.fido2Exhausted
          && !root.authenticatingPassword && root.enteredPassword.length === 0) {
        root.fido2TouchMisses = 0
        root.setAuthMode("fido2")
      }
      if (!root.fido2Active) root.settleAuthMode()
      if (root.fido2Active) root.startFido2()
    }
  }

  Process {
    id: sessionLockXrayProc
    command: ["hyprctl", "getoption", "misc:session_lock_xray", "-j"]
    stdout: StdioCollector {
      id: sessionLockXrayOut
      waitForEnd: true
      onStreamFinished: {
        try {
          root.sessionLockXray = JSON.parse(String(sessionLockXrayOut.text || "{}")).bool === true
        } catch (e) {
          root.sessionLockXray = false
        }
      }
    }
  }

  Process {
    id: strandedLockCheckProc
    // 0 locked and nobody holds it, 1 not locked, 2 no answer yet,
    // 3 locked and another copy of this service still holds it.
    command: ["bash", "-c",
      "omarchy-hyprland-session-locked || exit $?; " +
      "[[ -s $1 ]] || exit 0; " +
      "[[ $(head -n1 -- \"$1\") == \"$2\" ]] && exit 0; " +
      "age=$(( $(date +%s) - $(stat -c %Y -- \"$1\") )); " +
      "(( age <= 2 )) && exit 3; exit 0",
      "bash", root.lockClaimPath, root.instanceToken]
    onExited: function(exitCode) {
      // No output to read the lock off yet.
      if (exitCode === 2) return

      if (exitCode === 3) {
        if (root.lastEvent !== "lock-held-elsewhere: waiting") root.logEvent("lock-held-elsewhere: waiting")
        strandedDeferTimer.restart()
        return
      }

      root.strandedLockResolved = true

      // A lock taken while this was in flight is this shell's own.
      root.strandedLock = exitCode === 0 && !root.locked && !root.lockRequested
      root.recoverStrandedLock()
    }
  }

  Process {
    id: wakeProcess
    command: ["bash", "-c", "rm -f \"$1/display-off\"; omarchy-system-wake", "bash", root.blankMarkerDir]
    onExited: {
      if (!root.inputBlocked || root.screenBlanked) return
      inputUnblockTimer.interval = root.wakeInputGrace
      inputUnblockTimer.restart()
    }
  }

  Timer {
    id: inputUnblockTimer
    repeat: false
    onTriggered: if (!root.screenBlanked) root.inputBlocked = false
  }

  Process {
    id: blankProcess
    // The marker goes down before the display does: the shell can be gone
    // within two seconds of the output dropping.
    command: ["bash", "-c", root.displayBlankingSuppressed
      ? "omarchy-brightness-keyboard off"
      : "mkdir -p \"$1\" && : > \"$1/display-off\"; omarchy-brightness-keyboard off; omarchy-brightness-display off",
      "bash", root.blankMarkerDir]
  }

  // Runs once at startup. A display-off marker still there means the last
  // shell never reached a wake; it is kept as blank-crashed so every later
  // relaunch in this login sees it too (the runtime dir goes with the login).
  Process {
    id: blankCrashCheckProc
    command: ["bash", "-c",
      "[[ -e $1/display-off ]] && mv -f \"$1/display-off\" \"$1/blank-crashed\"; [[ -e $1/blank-crashed ]]",
      "bash", root.blankMarkerDir]
    onExited: function(exitCode) {
      if (exitCode !== 0) return
      root.blankCrashed = true
      root.logEvent("blank-crashed: keeping displays on for this login")
    }
  }

  Timer {
    id: idleBlankTimer
    interval: root.blankDelay
    repeat: false
    property double armedAt: 0
    onTriggered: {
      // A countdown frozen by suspend fires right after resume, which would
      // blank the freshly woken unlock screen under the user. Wall-clock time
      // exposes the gap: take a fresh run-up instead of blanking.
      if (Date.now() - armedAt > interval + 2000) {
        root.armBlankTimer()
        return
      }
      // Only a password check in flight should hold the display up. The
      // fingerprint PAM stays armed for the whole lock, so gating on
      // `authenticating` here would keep the panel lit until unlock.
      if (root.lockRequested && !root.authenticatingPassword) root.runBlank()
    }
  }

  Timer {
    id: sessionLockStabilizeTimer
    interval: 500
    repeat: false
    onTriggered: root.requestSessionLock()
  }

  Timer {
    id: pendingSessionLockTimer
    interval: 100
    repeat: true
    onTriggered: root.requestSessionLock()
  }

  Timer {
    id: strandedLockRetryTimer
    interval: 500
    repeat: true
    // Covers the compositor settling; screens coming back re-arm it.
    readonly property int budget: 20
    property int remaining: 20
    running: !root.strandedLockResolved && remaining > 0

    function rearm() {
      if (!root.strandedLockResolved) remaining = budget
    }

    onTriggered: {
      remaining -= 1
      root.checkStrandedLock()
    }
  }

  Connections {
    target: Quickshell
    function onScreensChanged() {
      root.requestSessionLock()

      // A monitor still coming up has no workspace, so cannot answer yet.
      strandedLockRetryTimer.rearm()
      root.checkStrandedLock()
    }
  }

  onAuthenticatingPasswordChanged: {
    if (!lockRequested) return
    if (authenticatingPassword) idleBlankTimer.stop()
    else armBlankTimer()
  }

  FileView {
    path: "/etc/pam.d/omarchy-lock-password"
    watchChanges: true
    printErrors: false
    onLoaded: root.passwordPamConfigured = true
    onLoadFailed: root.passwordPamConfigured = false
    onFileChanged: reload()
  }

  // No lock before PAM is known good. An answer from before then may be stale --
  // the failsafe can be cleared from a TTY -- so re-ask rather than act on it.
  onPasswordPamConfiguredChanged: {
    if (!passwordPamConfigured) return

    strandedLock = false
    strandedLockResolved = false
    strandedLockRetryTimer.rearm()
    checkStrandedLock()
  }

  // ------------------------------------------------- explorer facade
  // What the explorer, editor and designer get to see of this service on
  // Omarchy 4.0.3+, where the host keeps authentication services private
  // and hands the overlay `service = null` (issue #16). Published through
  // Bridge.js; it has no QObject parent and no reference back to this
  // object, so nothing here leads to the PAM contexts or the typed
  // password. extras/test-service-api.py keeps it in step with the UI.
  property var explorerApi: null

  Component {
    id: explorerApiComponent
    QtObject {
      readonly property string designId: root.designId
      readonly property int designsRevision: root.designsRevision
      readonly property string backgroundPath: root.backgroundPath
      readonly property int backgroundVersion: root.backgroundVersion
      readonly property string avatarPath: root.avatarPath
      readonly property int avatarVersion: root.avatarVersion
      readonly property string avatarUrl: root.avatarUrl
      readonly property string videoPath: root.videoPath
      readonly property string stingPath: root.stingPath
      readonly property int stingVolume: root.stingVolume
      readonly property real clipSpeed: root.clipSpeed
      readonly property bool clipWallpaper: root.clipWallpaper
      readonly property bool twelveHour: root.twelveHour
      readonly property string inputMonitor: root.inputMonitor
      readonly property string unlockAnimation: root.unlockAnimation
      readonly property int unlockDuration: root.unlockDuration
      readonly property var unlockAnimations: root.unlockAnimations
      readonly property int defaultUnlockDuration: root.defaultUnlockDuration
      readonly property int blankDelay: root.blankDelay
      readonly property int defaultBlankDelay: root.defaultBlankDelay
      readonly property int wakeGrace: root.wakeInputGrace
      readonly property int defaultWakeGrace: root.defaultWakeGrace
      readonly property bool powerActions: root.powerActions
      readonly property bool awayReport: root.awayReport
      readonly property bool lockOnKeyRemoval: root.lockOnKeyRemoval
      readonly property bool wakeOnKeyInsert: root.wakeOnKeyInsert
      readonly property var favorites: root.favorites
      readonly property bool showLayoutBadge: root.showLayoutBadge
      readonly property string accountName: root.accountName
      readonly property bool showCapsBadge: root.showCapsBadge
      readonly property bool allowPasswordToggle: root.allowPasswordToggle
      readonly property bool showAuthIcons: root.showAuthIcons
      readonly property var shadowingDirs: root.shadowingDirs
      readonly property var rivalLockPlugins: root.rivalLockPlugins
      readonly property string doctorPath: root.doctorPath
      readonly property string wallpaperBlur: root.wallpaperBlur
      readonly property string wallpaperDim: root.wallpaperDim
      readonly property real wallpaperBlurValue: root.wallpaperBlurValue
      readonly property real wallpaperDimShift: root.wallpaperDimShift
      readonly property string reduceMotion: root.reduceMotion
      readonly property bool motionReduced: root.motionReduced
      readonly property real uiScale: root.uiScale
      readonly property var languages: root.languages
      readonly property string language: root.language
      readonly property string languageSetting: root.languageSetting
      readonly property string systemLanguage: root.systemLanguage
      readonly property bool keepDisplayOn: root.keepDisplayOn
      readonly property bool displayBlankingSuppressed: root.displayBlankingSuppressed
      readonly property bool fingerprintConfigured: root.fingerprintConfigured
      readonly property bool faceConfigured: root.faceConfigured
      readonly property string faceStart: root.faceStart
      readonly property bool fido2Configured: root.fido2Configured
      readonly property bool fido2Installed: root.fido2Installed
      readonly property bool fido2Enabled: root.fido2Enabled
      readonly property bool multimediaAvailable: root.multimediaAvailable
      readonly property bool menuEntryInstalled: root.menuEntryInstalled
      readonly property var components: root.components
      readonly property bool locked: root.locked
      readonly property bool previewVisible: root.previewVisible
      readonly property bool stingPlaying: root.stingPlaying
      readonly property string bootSetting: root.bootSetting
      readonly property bool bootApplying: root.bootApplying
      readonly property string bootApplied: root.bootApplied
      readonly property int bootAppliedVersion: root.bootAppliedVersion
      readonly property string bootAppliedTheme: root.bootAppliedTheme
      readonly property string bootCurrentTheme: root.bootCurrentTheme
      readonly property bool bootResync: root.bootResync
      readonly property int bootPreviewsVersion: root.bootPreviewsVersion
      readonly property bool bootPreviewsRunning: root.bootPreviewsRunning
      readonly property bool bootPreviewsPending: root.bootPreviewsPending
      readonly property var bootVideos: root.bootVideos
      readonly property var bootCustomDesigns: root.bootCustomDesigns
      readonly property int bootClipSeconds: root.bootClipSeconds
      readonly property var bootRotation: root.bootRotation

      signal designCustomized(string id, string path)
      signal designerDesignCreated(string id, string path)
      signal imagePicked(string path)
      signal clipDesignAdded(string id)
      signal bootResnapshotRequested(string designId, bool persist)
      signal exploreTabRequested(string tab)
      signal bootDesignLoaded(string name, string content)

      function setDesign(id) { return root.setDesign(id) }
      function customizeDesign(id) { return root.customizeDesign(id) }
      function createDesignerDesign(content) { return root.createDesignerDesign(content) }
      function deleteDesign(id) { return root.deleteDesign(id) }
      function rescanUserDesigns() { return root.rescanUserDesigns() }
      function reloadDesigns() { return root.reloadDesigns() }
      function rescanComponents() { return root.rescanComponents() }
      function saveComponent(slug, json) { return root.saveComponent(slug, json) }
      function deleteComponent(slug) { return root.deleteComponent(slug) }
      function pickAvatar(reopenExplorer) { return root.pickAvatar(reopenExplorer) }
      function setAvatar(path) { return root.setAvatar(path) }
      function clearAvatar() { return root.clearAvatar() }
      function resetAvatar() { return root.resetAvatar() }
      function pickImage(reopenExplorer) { return root.pickImage(reopenExplorer) }
      function pickVideo(reopenExplorer, target) { return root.pickVideo(reopenExplorer, target) }
      function setVideo(path) { return root.setVideo(path) }
      function clearVideo() { return root.clearVideo() }
      function setSting(path) { return root.setSting(path) }
      function clearSting() { return root.clearSting() }
      function setStingVolume(value) { return root.setStingVolume(value) }
      function playSting() { return root.playSting() }
      function endSting() { return root.endSting() }
      function createClipDesign(path) { return root.createClipDesign(path) }
      function setClipSpeed(v) { return root.setClipSpeed(v) }
      function setClipWallpaper(on) { return root.setClipWallpaper(on) }
      function setTwelveHour(v) { return root.setTwelveHour(v) }
      function setInputMonitor(name) { return root.setInputMonitor(name) }
      function setUnlockAnimation(name) { return root.setUnlockAnimation(name) }
      function setUnlockDuration(ms) { return root.setUnlockDuration(ms) }
      function setBlankDelay(ms) { return root.setBlankDelay(ms) }
      function setWakeGrace(ms) { return root.setWakeGrace(ms) }
      function setFaceStart(value) { return root.setFaceStart(value) }
      function setPowerActions(value) { return root.setPowerActions(value) }
      function setAwayReport(value) { return root.setAwayReport(value) }
      function setLockOnKeyRemoval(value) { return root.setLockOnKeyRemoval(value) }
      function setWakeOnKeyInsert(value) { return root.setWakeOnKeyInsert(value) }
      function toggleFavorite(id) { return root.toggleFavorite(id) }
      function setFieldItem(name, show) { return root.setFieldItem(name, show) }
      function installPackages(names) { return root.installPackages(names) }
      function runDoctor() { return root.runDoctor() }
      function moveCopies() { return root.moveCopies() }
      readonly property bool movingCopies: root.movingCopies
      function setWallpaperBlur(value) { return root.setWallpaperBlur(value) }
      function setWallpaperDim(value) { return root.setWallpaperDim(value) }
      function setReduceMotion(value) { return root.setReduceMotion(value) }
      function setUiScale(value) { return root.setUiScale(value) }
      function setLanguage(value) { return root.setLanguage(value) }
      function runPowerAction(action) { return root.runPowerAction(action) }
      function setKeepDisplayOn(on) { return root.setKeepDisplayOn(on) }
      function refreshBackground() { return root.refreshBackground() }
      function refreshFingerprintStatus() { return root.refreshFingerprintStatus() }
      function refreshFaceStatus() { return root.refreshFaceStatus() }
      function refreshFido2Status() { return root.refreshFido2Status() }
      function setFido2Enabled(v) { return root.setFido2Enabled(v) }
      function refreshMenuEntry() { return root.refreshMenuEntry() }
      function setMenuEntry(v) { return root.setMenuEntry(v) }
      function logEvent(event) { return root.logEvent(event) }
      function setBoot(value) { return root.setBoot(value) }
      function applyBoot(force, explicitTarget) { return root.applyBoot(force, explicitTarget) }
      function applyBootSnapshot(id, persist, entryRect) { return root.applyBootSnapshot(id, persist, entryRect) }
      function setBootResync(on) { return root.setBootResync(on) }
      function refreshBootPreviews() { return root.refreshBootPreviews() }
      function setBootClipSeconds(n) { return root.setBootClipSeconds(n) }
      function loadBootDesign(name) { return root.loadBootDesign(name) }
      function saveBootDesign(name, content) { return root.saveBootDesign(name, content) }
      function createBootDesign() { return root.createBootDesign() }
      function deleteBootItem(id) { return root.deleteBootItem(id) }
      function toggleBootRotation(id) { return root.toggleBootRotation(id) }
      function enableBootRotation() { return root.enableBootRotation() }
    }
  }

  function publishExplorerApi() {
    if (explorerApi) return
    var api = explorerApiComponent.createObject(null)
    if (!api) return
    root.designCustomized.connect(api.designCustomized)
    root.designerDesignCreated.connect(api.designerDesignCreated)
    root.imagePicked.connect(api.imagePicked)
    root.clipDesignAdded.connect(api.clipDesignAdded)
    root.bootResnapshotRequested.connect(api.bootResnapshotRequested)
    root.exploreTabRequested.connect(api.exploreTabRequested)
    root.bootDesignLoaded.connect(api.bootDesignLoaded)
    explorerApi = api
    Bridge.publish(api)
  }

  function retireExplorerApi() {
    if (!explorerApi) return
    var api = explorerApi
    explorerApi = null
    Bridge.unpublish(api)
    api.destroy()
  }

  Component.onCompleted: {
    publishExplorerApi()
    refreshMenuEntry()
    refreshBackground()
    refreshFingerprintStatus()
    refreshFaceStatus()
    refreshFido2Status()
    refreshSessionLockXray()
    rescanUserDesigns()
    detectAvatar()
    blankCrashCheckProc.running = true
    duplicatePluginProc.running = true
    rivalLockCheckTimer.start()
    checkStrandedLock()
    settingsRestoreTimer.start()
  }

  Component.onDestruction: retireExplorerApi()

  // Opened from the app launcher, the shell's app library shows a
  // "Launching …" OSD 2s after the launch unless a new toplevel window appears
  // by then. The explorer is layer-shell, so none does, and the OSD would
  // otherwise stay up until the launcher's 15s timeout. The explorer's own
  // close on open runs before the OSD exists, so watch for it for a few
  // seconds after `explore` and close it 2s after it shows, long enough to
  // read.
  function watchLaunchOsd() {
    launchOsdWatch.ticks = 0
    launchOsdWatch.restart()
  }

  Timer {
    id: launchOsdWatch
    property int ticks: 0
    interval: 150
    repeat: true
    onTriggered: {
      // About 3.5s: the app library's 2s delay plus a slow summon.
      if (++ticks > 24) { stop(); return }
      if (!launchOsdStateProc.running) launchOsdStateProc.running = true
    }
  }

  Process {
    id: launchOsdStateProc
    command: ["omarchy-shell", "osd", "state"]
    stdout: StdioCollector { id: launchOsdStateOut; waitForEnd: true }
    onExited: function(code) {
      if (String(launchOsdStateOut.text || "").trim() !== "open") return
      launchOsdWatch.stop()
      launchOsdClose.restart()
    }
  }

  Timer {
    id: launchOsdClose
    interval: 2000
    onTriggered: Quickshell.execDetached(["omarchy-shell", "osd", "close"])
  }

  IpcHandler {
    target: "lock"

    function lock(): string {
      if (!root.passwordPamConfigured) return "missing-pam"
      if (!root.locked && !root.beginLock()) return "failed"
      return "ok"
    }

    function isLocked(): string {
      return root.locked ? "true" : "false"
    }

    function status(): string {
      return JSON.stringify({
        locked: root.locked,
        requested: root.lockRequested,
        pending: root.pendingSessionLock,
        sessionLocked: sessionLock.locked,
        secure: sessionLock.secure,
        realScreens: root.realScreenCount(),
        passwordPam: root.passwordPamConfigured,
        multimedia: root.multimediaAvailable,
        fingerprint: root.fingerprintConfigured,
        fingerprintConfigured: root.fingerprintConfigured,
        faceConfigured: root.faceConfigured,
        faceAuthenticating: root.faceAuthenticating,
        fido2Configured: root.fido2Configured,
        fido2Installed: root.fido2Installed,
        fido2Enabled: root.fido2Enabled,
        fido2Token: root.fido2TokenPresent,
        fido2Authenticating: root.fido2Authenticating,
        fido2PinAttempts: root.fido2PinAttempts,
        authMode: root.authMode,
        authenticating: root.authenticating,
        lastEvent: root.lastEvent,
        lastEventAt: root.lastEventAt,
        design: root.designId,
        boot: root.bootSetting,
        bootApplied: root.bootApplied,
        bootApplying: root.bootApplying,
        unlock: root.unlockAnimation,
        unlockMs: root.unlockDuration,
        unlockAnimated: root.unlockAnimated,
        blankMs: root.blankDelay,
        inputBlocked: root.inputBlocked,
        keyboardLayout: root.keyboardLayout,
        capsLock: root.capsLock,
        fingerprintStatus: root.fingerprintStatus,
        shadowedBy: root.shadowingDirs,
        rivalLockPlugins: root.rivalLockPlugins,
        wakeGraceMs: root.wakeInputGrace,
        faceStart: root.faceStart,
        powerActions: root.powerActions,
        awayReport: root.awayReport,
        wallpaperBlur: root.wallpaperBlur,
        wallpaperDim: root.wallpaperDim,
        reduceMotion: root.reduceMotion,
        motionReduced: root.motionReduced,
        onBattery: root.onBattery,
        batteryPercent: root.batteryPercent,
        batteryLow: root.batteryLow,
        uiScale: root.uiScale,
        language: root.language,
        fieldItems: { layout: root.showLayoutBadge, caps: root.showCapsBadge, reveal: root.allowPasswordToggle, icons: root.showAuthIcons },
        languageSetting: root.languageSetting,
        keepDisplayOn: root.keepDisplayOn,
        displayBlankingSuppressed: root.displayBlankingSuppressed,
        unlocking: root.unlocking,
        clipDesign: root.designHasClip,
        clipUnlocking: root.clipUnlocking,
        video: root.videoPath,
        sting: root.stingPath,
        stingPlaying: root.stingPlaying,
        previewTyped: root.previewTyped.length
      })
    }

    function preview(): string {
      root.previewUnlocking = false
      root.previewClipPlaying = false
      root.refreshBackground()
      root.refreshFingerprintStatus()
      root.previewVisible = true
      return "ok"
    }

    function hidePreview(): string {
      previewUnlockTimer.stop()
      root.previewUnlocking = false
      root.previewClipPlaying = false
      root.previewVisible = false
      root.previewDesignId = ""
      root.previewTyped = ""
      return "ok"
    }

    function design(): string {
      return root.designId
    }

    function designs(): string {
      return JSON.stringify(Designs.all().map(function(d) {
        return { id: d.id, name: d.name, description: d.description, active: d.id === root.designId }
      }))
    }

    function setDesign(id: string): string {
      return root.setDesign(id) ? "ok" : "unknown-design"
    }

    function setKeepDisplayOn(value: string): string {
      return root.setKeepDisplayOn(value) ? "ok" : "invalid-value"
    }

    function setBlankDelay(value: string): string {
      return root.setBlankDelay(value) ? "ok" : "invalid-value"
    }

    function powerActions(): string {
      return root.powerActions ? "on" : "off"
    }

    function setPowerActions(value: string): string {
      return root.setPowerActions(value) ? "ok" : "invalid-value"
    }

    function awayReport(): string {
      return root.awayReport ? "on" : "off"
    }

    function setAwayReport(value: string): string {
      return root.setAwayReport(value) ? "ok" : "invalid-value"
    }

    function lockOnKeyRemoval(): string {
      return root.lockOnKeyRemoval ? "on" : "off"
    }

    function setLockOnKeyRemoval(value: string): string {
      return root.setLockOnKeyRemoval(value) ? "ok" : "invalid-value"
    }

    function wakeOnKeyInsert(): string {
      return root.wakeOnKeyInsert ? "on" : "off"
    }

    function setWakeOnKeyInsert(value: string): string {
      return root.setWakeOnKeyInsert(value) ? "ok" : "invalid-value"
    }

    function favorites(): string {
      return root.favorites.join("\n")
    }

    function toggleFavorite(id: string): string {
      return root.toggleFavorite(id) ? (root.favorites.indexOf(id) !== -1 ? "on" : "off") : "unknown-design"
    }

    function wallpaperBlur(): string {
      return root.wallpaperBlur
    }

    function setWallpaperBlur(value: string): string {
      return root.setWallpaperBlur(value) ? "ok" : "invalid-value"
    }

    function reduceMotion(): string {
      return root.reduceMotion
    }

    function setReduceMotion(value: string): string {
      return root.setReduceMotion(value) ? "ok" : "invalid-value"
    }

    function fieldItems(): string {
      return "layout=" + (root.showLayoutBadge ? "show" : "hide") + " caps=" + (root.showCapsBadge ? "show" : "hide")
        + " reveal=" + (root.allowPasswordToggle ? "show" : "hide") + " icons=" + (root.showAuthIcons ? "show" : "hide")
    }

    function setFieldItem(name: string, value: string): string {
      if (["show", "hide", "on", "off"].indexOf(value) === -1) return "invalid-value"
      return root.setFieldItem(name, value === "show" || value === "on") ? "ok" : "invalid-item"
    }

    function language(): string {
      return root.languageSetting === "auto" ? "auto (" + root.language + ")" : root.language
    }

    function setLanguage(value: string): string {
      return root.setLanguage(value) ? "ok" : "invalid-value"
    }

    function size(): string {
      return Math.round(root.uiScale * 100) + "%"
    }

    function setSize(value: string): string {
      return root.setUiScale(value) ? "ok" : "invalid-value"
    }

    function wallpaperDim(): string {
      return root.wallpaperDim
    }

    function setWallpaperDim(value: string): string {
      return root.setWallpaperDim(value) ? "ok" : "invalid-value"
    }

    function wakeGrace(): string {
      return String(root.wakeInputGrace)
    }

    function setWakeGrace(value: string): string {
      return root.setWakeGrace(value) ? "ok" : "invalid-value"
    }

    function faceStart(): string {
      return root.faceStart
    }

    function setFaceStart(value: string): string {
      return root.setFaceStart(value) ? "ok" : "invalid-value (always, wake or off)"
    }

    function boot(): string {
      var applied = root.bootApplied.length > 0 ? root.bootApplied : "stock"
      return root.bootSetting + " (applied: " + applied + (root.bootApplying ? ", rebuilding" : "") + ")"
    }

    function setBoot(value: string): string {
      if (root.bootApplying) return "busy"
      return root.setBoot(value) ? "ok" : "unknown-boot"
    }

    function setBootResync(value: string): string {
      return root.setBootResync(value === "on" || value === "true") ? "ok" : "failed"
    }

    function bootRotation(): string {
      return (root.bootRotation || []).join(",")
    }

    function toggleBootRotation(id: string): string {
      return root.toggleBootRotation(id) ? "ok" : "failed"
    }

    function enableBootRotation(): string {
      root.enableBootRotation()
      return "ok"
    }

    function setBootClipSeconds(value: string): string {
      return root.setBootClipSeconds(value) ? "ok" : "failed"
    }

    function previewDesign(id: string): string {
      root.rescanUserDesigns()
      if (!Designs.byId(String(id || ""))) return "unknown-design"
      root.previewDesignId = String(id)
      root.previewUnlocking = false
      root.refreshBackground()
      root.refreshFingerprintStatus()
      root.previewVisible = true
      return "ok"
    }

    function monitors(): string {
      var screens = Quickshell.screens || []
      return JSON.stringify(screens.map(function(s) { return { name: s.name, width: s.width, height: s.height, input: root.showsInput(s) } }))
    }

    function inputMonitor(): string {
      return root.inputMonitor
    }

    function setInputMonitor(name: string): string {
      return root.setInputMonitor(name) ? "ok" : "failed"
    }

    function unlockAnimation(): string {
      return root.unlockAnimated ? root.unlockAnimation + " " + root.unlockDuration + "ms" : "none"
    }

    function setUnlockAnimation(name: string): string {
      return root.setUnlockAnimation(name) ? "ok" : "unknown-animation"
    }

    function setUnlockDuration(ms: string): string {
      return root.setUnlockDuration(ms) ? "ok" : "out-of-range"
    }

    function previewUnlock(): string {
      if (!root.previewVisible) return "no-preview"
      var pd = Designs.byId(root.previewDesignId.length > 0 ? root.previewDesignId : root.designId)
      if (pd && pd.clip) {
        root.previewClipPlaying = true
        return "ok"
      }
      if (!root.unlockAnimated) {
        root.previewVisible = false
        root.previewDesignId = ""
        root.previewTyped = ""
        return "ok"
      }
      root.previewUnlocking = true
      previewUnlockTimer.restart()
      return "ok"
    }

    // Feeds the preview's password field, so a demo can type without hands.
    function previewType(text: string): string {
      if (!root.previewVisible) return "no-preview"
      root.previewTyped = String(text || "")
      return "ok"
    }

    function previewFail(): string {
      root.previewFailure = ""
      root.previewFailure = "Authentication failed (1)"
      previewFailureTimer.restart()
      return "ok"
    }

    function customize(id: string): string {
      return root.customizeDesign(id) ? "ok" : "unknown-design"
    }

    function editDesign(id: string): string {
      var d = Designs.byId(String(id || ""))
      if (!d || !d.path) return "not-a-custom-design"
      Quickshell.execDetached(["omarchy-launch-editor", decodeURIComponent(d.path.replace(/^file:\/\//, ""))])
      return "ok"
    }

    function reloadDesigns(): string {
      root.reloadDesigns()
      return "ok"
    }

    function rescanDesigns(): string {
      root.rescanUserDesigns()
      return "ok"
    }

    function rescanComponents(): string {
      root.rescanComponents()
      return "ok"
    }

    function components(): string {
      var names = []
      for (var i = 0; i < root.components.length; i++) names.push(root.components[i].comp.name)
      return names.length > 0 ? names.join("\n") : "none"
    }

    function avatar(): string {
      return root.avatarPath
    }

    function setAvatar(path: string): string {
      return root.setAvatar(path) ? "ok" : "failed"
    }

    function clearAvatar(): string {
      return root.clearAvatar() ? "ok" : "failed"
    }

    function resetAvatar(): string {
      return root.resetAvatar() ? "ok" : "failed"
    }

    function pickAvatar(): string {
      return root.pickAvatar(false) ? "ok" : "busy"
    }

    function video(): string {
      return root.videoPath.length > 0 ? root.videoPath : "none"
    }

    function setVideo(path: string): string {
      return root.setVideo(path) ? "ok" : "failed"
    }

    function clearVideo(): string {
      return root.clearVideo() ? "ok" : "failed"
    }

    function pickVideo(): string {
      return root.pickVideo(false, "video") ? "ok" : "busy"
    }

    function sting(): string {
      return root.stingPath.length > 0 ? root.stingPath : "none"
    }

    function setSting(path: string): string {
      return root.setSting(path) ? "ok" : "failed"
    }

    function clearSting(): string {
      return root.clearSting() ? "ok" : "failed"
    }

    function pickSting(): string {
      return root.pickVideo(false, "sting") ? "ok" : "busy"
    }

    function newClipDesign(): string {
      return root.pickVideo(false, "clip") ? "ok" : "busy"
    }

    function clipWallpaper(): string {
      return root.clipWallpaper ? "on" : "off"
    }

    function setClipWallpaper(on: string): string {
      return root.setClipWallpaper(on) ? "ok" : "failed"
    }

    function clipSpeed(): string {
      return String(root.clipSpeed)
    }

    function setClipSpeed(v: string): string {
      return root.setClipSpeed(v) ? "ok" : "failed"
    }

    function menuEntry(): string {
      return root.menuEntryInstalled ? "on" : "off"
    }

    function setMenuEntry(v: string): string {
      return root.setMenuEntry(v === "on" || v === "true" || v === "1") ? "ok" : "failed"
    }

    function clockFormat(): string {
      return root.twelveHour ? "12" : "24"
    }

    function setClockFormat(v: string): string {
      return root.setTwelveHour(v === "12" || v === "12h" || v === "true" || v === "on") ? "ok" : "failed"
    }

    function createClipDesign(path: string): string {
      return root.createClipDesign(path) ? "ok" : "failed"
    }

    function deleteDesign(id: string): string {
      return root.deleteDesign(id) ? "ok" : "failed"
    }

    function deleteBootItem(id: string): string {
      return root.deleteBootItem(id) ? "ok" : "failed"
    }

    function stingVolume(): string {
      return String(root.stingVolume)
    }

    function setStingVolume(value: string): string {
      return root.setStingVolume(value) ? "ok" : "failed"
    }

    function previewSting(): string {
      if (root.stingPath.length === 0) return "no-clip"
      return root.playSting() ? "ok" : "busy"
    }

    function explore(): string {
      root.rescanUserDesigns()
      root.watchLaunchOsd()
      if (root.shell && typeof root.shell.summon === "function")
        return root.shell.summon(root.pluginId, "{}") ? "ok" : "failed"
      return "no-shell"
    }

    // Open the built-in editor on a custom boot layout.
    function editBootLayout(name: string): string {
      root.loadBootDesign(String(name || ""))
      if (root.shell && typeof root.shell.summon === "function")
        return root.shell.summon(root.pluginId, "{}") ? "ok" : "failed"
      return "no-shell"
    }

    // Open the explorer on a specific tab: styling, animation, boot or
    // settings. Also handy for scripting and screenshots.
    function exploreTab(tab: string): string {
      root.rescanUserDesigns()
      root.exploreTabRequested(String(tab || "styling"))
      if (root.shell && typeof root.shell.summon === "function")
        return root.shell.summon(root.pluginId, "{}") ? "ok" : "failed"
      return "no-shell"
    }
  }
}
