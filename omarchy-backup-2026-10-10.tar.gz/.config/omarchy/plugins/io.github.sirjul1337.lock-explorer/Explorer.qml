import QtQuick
import Quickshell
import Quickshell.Io
import Quickshell.Wayland
import qs.Commons
import qs.Ui
import "designs"
import "Designs.js" as Designs
import "Designer.js" as Layout
import "Bridge.js" as Bridge
import "ExplorerStrings.js" as UiText

Item {
  id: root

  property string omarchyPath: Quickshell.env("OMARCHY_PATH")
  property var shell: null
  property var manifest: null
  property var service: null

  // Omarchy 4.0.3 hands this overlay `service = null`: the service is an
  // authentication service (a clone of omarchy.lock) and the host keeps those
  // private (issue #16). The service publishes a facade of itself through
  // Bridge.js instead; adopt it whenever the injected one is missing, and
  // again whenever the service is reloaded. Older hosts still inject the
  // service directly and nothing here gets in their way.
  function adoptService() {
    if (root.service) return
    var api = Bridge.current()
    if (api) root.service = api
  }
  onServiceChanged: if (!service) Qt.callLater(root.adoptService)
  property var bridgeUnsubscribe: null
  Component.onCompleted: {
    root.bridgeUnsubscribe = Bridge.subscribe(function() { Qt.callLater(root.adoptService) })
    root.adoptService()
  }
  Component.onDestruction: if (root.bridgeUnsubscribe) root.bridgeUnsubscribe()

  LocalSettings { id: localSettings; pluginId: root.pluginId }
  property string selectionError: ""

  property bool opened: false
  // A resync that arrived while this window was never yet shown cannot grab a
  // frame (no scene graph); it parks here and runs on the next open.
  property var pendingResnapshot: null

  // Stock Omarchy ships Qt without a WebP decoder (issue #6): designs then
  // render the theme color instead of the wallpaper. Probe the current
  // wallpaper so the header can say so instead of leaving users guessing.
  readonly property string wallpaperProbePath: root.service ? String(root.service.backgroundPath || "") : ""
  readonly property bool wallpaperIsWebp: wallpaperProbePath.toLowerCase().indexOf(".webp") !== -1
  readonly property bool wallpaperBroken: wallpaperProbe.status === Image.Error
  Image {
    id: wallpaperProbe
    visible: false
    width: 1; height: 1
    sourceSize.width: 8; sourceSize.height: 8
    asynchronous: true
    source: root.opened && root.wallpaperProbePath.length > 0
      ? "file://" + root.wallpaperProbePath.split("/").map(encodeURIComponent).join("/") : ""
  }
  // The shell's app library shows a "Launching …" OSD until a new toplevel
  // window appears. This overlay is layer-shell, so no toplevel ever comes —
  // dismiss the OSD ourselves the moment the explorer is up (15s timeout
  // otherwise).
  onOpenedChanged: {
    if (!opened) return
    thumbSlots = 0
    Quickshell.execDetached(["omarchy-shell", "osd", "close"])
    // The entries can be added or removed outside the explorer too.
    if (root.service && typeof root.service.refreshMenuEntry === "function") root.service.refreshMenuEntry()
    if (pendingResnapshot) {
      var p = pendingResnapshot
      pendingResnapshot = null
      Qt.callLater(function() { root.snapshotAndApply(p.id, p.persist) })
    }
  }
  property int selectedIndex: 0
  property bool fullPreview: false
  // The ? sheet: every key the explorer takes, over whatever page is open.
  property bool showingKeys: false
  // Widest row of key caps, so every description starts on one line.
  property real keyCapsWidth: 0
  readonly property var keySections: [
    { title: "Browse", rows: [
      { keys: ["←", "→", "↑", "↓"], text: "Move between designs" },
      { keys: ["H", "J", "K", "L"], text: "The same, Vim style" },
      { keys: ["Home", "End"], text: "First and last design" },
      { keys: ["PgUp", "PgDn"], text: "Scroll a page" },
      { keys: ["Space", "P"], text: "Full-size preview" },
      { keys: ["Enter"], text: "Use the selected design" },
      { keys: ["/", "Ctrl+F"], text: "Search every design" },
      { keys: ["F"], text: "Star it, or unstar it, for Favorites" }
    ] },
    { title: "Your designs", rows: [
      { keys: ["D"], text: "Designer: new, or this one if made there" },
      { keys: ["C"], text: "Copy to Custom and edit the code" },
      { keys: ["E"], text: "Edit a design of your own" },
      { keys: ["N"], text: "New design from the template" },
      { keys: ["X", "Del"], text: "Delete your own design (press twice)" }
    ] },
    { title: "Pictures and video", rows: [
      { keys: ["A", "Shift+A"], text: "Pick or clear the profile picture" },
      { keys: ["V", "Shift+V"], text: "Pick or clear the Motion video" },
      { keys: ["S", "Shift+S"], text: "Pick or clear the unlock clip" }
    ] },
    { title: "Pages", rows: [
      { keys: ["Tab", "Shift+Tab"], text: "Styling, Animation, Favorites" },
      { keys: ["U"], text: "Settings" },
      { keys: ["B"], text: "Boot screen" },
      { keys: ["?"], text: "This list" },
      { keys: ["Esc"], text: "Back, or close the explorer" }
    ] }
  ]
  property bool editing: false
  property var editingDesign: null
  // The visual designer, which takes over the card the same way the code
  // editor does. `designerPaused` holds the session open across the file
  // dialog, which needs the explorer to step aside.
  property bool designing: false
  property var designingDesign: null
  property bool designerPaused: false
  property string category: "all"
  // Type-to-filter over every design, from the field in the header (/ or
  // Ctrl+F). While it is non-empty the grid shows matches from all of them,
  // whichever sidebar entry is picked.
  property string searchText: ""
  property bool searching: false
  onSearchTextChanged: { selectedIndex = 0; reveal(GridView.Beginning) }
  readonly property var favoriteIds: service && service.favorites ? service.favorites : []
  function isFavorite(id) { return root.favoriteIds.indexOf(id) !== -1 }
  function favoriteDesigns() {
    return Designs.all().filter(function(d) { return root.favoriteIds.indexOf(d.id) !== -1 })
  }
  function matchesSearch(d, words) {
    var hay = [d.name, d.id, d.description || ""].concat(d.tags || []).join(" ").toLowerCase()
    for (var i = 0; i < words.length; i++) if (hay.indexOf(words[i]) === -1) return false
    return true
  }
  // Things that stop part of the plugin working here, each with the way out.
  // Shown at the top of Settings, and only when there is something to say.
  readonly property bool multimediaMissing: !!service && service.multimediaAvailable === false
  readonly property var healthIssues: {
    var list = []
    if (root.multimediaMissing)
      list.push({ text: root.tr("Video designs, clip designs and the unlock clip need qt6-multimedia, which Omarchy does not install."),
                  packages: ["qt6-multimedia"] })
    if (root.wallpaperBroken && root.wallpaperIsWebp)
      list.push({ text: root.tr("Your wallpaper is WebP, which the shell can only read with qt6-imageformats."),
                  packages: ["qt6-imageformats"] })
    var dirs = service && service.shadowingDirs ? service.shadowingDirs : []
    if (dirs.length > 0)
      list.push({ text: root.tr("Another copy of this plugin may load instead of this one: %1. Move it out of ~/.config/omarchy/plugins/ (to ~/.local/share/omarchy/lock-explorer-backups) and restart the shell.").arg(dirs.join(", ")),
                  packages: [], fix: "copies" })
    var rivals = service && service.rivalLockPlugins ? service.rivalLockPlugins : []
    if (rivals.length > 0)
      list.push({ text: root.tr("Another lock screen plugin is enabled too: %1. Only one of them gets omarchy-shell lock. Keep one: omarchy plugin disable %2 && omarchy restart shell").arg(rivals.join(", ")).arg(rivals[0]),
                  packages: [] })
    return list
  }

  function installPackages(names) {
    if (!root.service || typeof root.service.installPackages !== "function") return
    root.dismiss()
    root.service.installPackages(names)
  }

  readonly property bool movingCopies: !!service && service.movingCopies === true
  function moveCopies() {
    if (!root.service || typeof root.service.moveCopies !== "function" || root.movingCopies) return
    root.service.moveCopies()
  }

  function runDoctor() {
    if (!root.service || typeof root.service.runDoctor !== "function") return
    root.dismiss()
    root.service.runDoctor()
  }

  readonly property bool gridTab: mainTab === "styling" || mainTab === "animation" || mainTab === "favorites"

  readonly property var categories: Designs.categories()

  // A picture of each grid preview, taken once it has settled. A card that
  // comes back -- a search, another tab -- shows it at once while its live
  // design builds again on top, instead of an empty frame. Everything a
  // preview draws from is in the key, and a change to any of it starts over.
  property var thumbCache: ({})
  readonly property string thumbStateKey: [
    service ? service.designsRevision : 0,
    service ? service.backgroundPath : "", service ? service.backgroundVersion : 0,
    service ? service.avatarPath : "", service ? service.avatarVersion : 0,
    lockLanguage, accountName, twelveHour, wallpaperBlurValue, wallpaperDimShift, uiScale, motionReduced,
    showLayoutBadge, showCapsBadge, allowPasswordToggle, showAuthIcons,
    String(Color.lock.text), String(Color.lock.background), String(Color.background), thumbWidth
  ].join("|")
  onThumbStateKeyChanged: thumbCache = ({})
  function thumbFor(id) {
    var entry = thumbCache[id]
    return entry ? String(entry.url) : ""
  }
  function keepThumb(id, key, result) {
    if (key !== thumbStateKey) return
    var next = {}
    for (var k in thumbCache) next[k] = thumbCache[k]
    next[id] = result
    thumbCache = next
  }

  // Live previews start one after another, from the top-left of what is on
  // screen, rather than all at once and finishing in whatever order.
  property int thumbSlots: 0
  readonly property int gridTopRow: grid.cellHeight > 0 ? Math.floor(grid.contentY / grid.cellHeight) : 0
  onGridTopRowChanged: thumbSlots = 0
  Timer {
    interval: 40
    repeat: true
    running: root.opened && root.gridTab && root.thumbSlots < root.columns * 5
    onTriggered: root.thumbSlots += 1
  }
  readonly property var designs: {
    var r = service ? service.designsRevision : 0
    var words = searchText.trim().toLowerCase().split(/\s+/).filter(function(w) { return w.length > 0 })
    if (words.length > 0) return Designs.all().filter(function(d) { return root.matchesSearch(d, words) })
    if (mainTab === "animation") return Designs.animations()
    if (mainTab === "favorites") return favoriteDesigns()
    return Designs.stylings()
  }
  readonly property string pluginId: manifest && manifest.id ? String(manifest.id) : "io.github.sirjul1337.lock-explorer"
  readonly property string activeDesignId: service ? service.designId
    : String(localSettings.entry.design || Designs.DEFAULT_ID)
  readonly property var selectedDesign: designs.length > 0 ? designs[Math.max(0, Math.min(selectedIndex, designs.length - 1))] : null
  readonly property string avatarUrl: service ? service.avatarUrl : ""

  // Quick setting for the unlock animation, the same one `omarchy-shell lock
  // setUnlockAnimation` writes. Off by default.
  readonly property var unlockOptions: [
    { id: "none", name: "Off", hint: "The lock screen disappears at once" },
    { id: "fade", name: "Fade", hint: "It fades into the wallpaper" },
    { id: "zoom", name: "Zoom", hint: "It fades and pushes in a little" },
    { id: "rise", name: "Rise", hint: "It fades upwards off the screen" }
  ]
  readonly property var unlockDurations: [200, 300, 400, 600, 800]
  readonly property string unlockAnimation: service ? service.unlockAnimation : "none"
  readonly property int unlockDuration: service ? service.unlockDuration : 400
  readonly property bool keepDisplayOn: service ? service.keepDisplayOn : false
  readonly property int blankDelay: service ? service.blankDelay : 5000
  readonly property var blankPresets: [5000, 15000, 30000, 60000, 300000]
  readonly property int wakeGrace: service && service.wakeGrace !== undefined ? service.wakeGrace : 1000
  readonly property bool powerActions: service && service.powerActions === true
  readonly property bool awayReport: !service || service.awayReport !== false
  readonly property bool lockOnKeyRemoval: service && service.lockOnKeyRemoval === true
  readonly property bool wakeOnKeyInsert: service && service.wakeOnKeyInsert === true
  readonly property string wallpaperBlur: service && service.wallpaperBlur !== undefined ? String(service.wallpaperBlur) : "design"
  readonly property string wallpaperDim: service && service.wallpaperDim !== undefined ? String(service.wallpaperDim) : "design"
  readonly property real wallpaperBlurValue: service && service.wallpaperBlurValue !== undefined ? service.wallpaperBlurValue : -1
  readonly property real wallpaperDimShift: service && service.wallpaperDimShift !== undefined ? service.wallpaperDimShift : 0
  readonly property string reduceMotion: service && service.reduceMotion !== undefined ? String(service.reduceMotion) : "off"
  readonly property bool motionReduced: !!service && service.motionReduced === true
  readonly property real uiScale: service && service.uiScale !== undefined ? service.uiScale : 1
  readonly property string accountName: service && service.accountName !== undefined ? String(service.accountName) : ""
  readonly property string lockLanguage: service && service.language !== undefined ? String(service.language) : "en"
  // The explorer speaks the lock screen's language (ExplorerStrings.js).
  function tr(text) { return UiText.tr(root.lockLanguage, text) }
  readonly property string languageSetting: service && service.languageSetting !== undefined ? String(service.languageSetting) : "auto"
  readonly property var languageChoices: {
    var list = service && service.languages ? service.languages : []
    var system = service && service.systemLanguage ? String(service.systemLanguage) : "en"
    var sysName = "English"
    for (var i = 0; i < list.length; i++) if (list[i].id === system) sysName = list[i].name
    return [{ id: "auto", name: root.tr("System (%1)").arg(sysName) }].concat(list.map(function(l) { return { id: l.id, name: l.name } }))
  }
  readonly property var reduceMotionChoices: [
    { id: "off", name: root.tr("Off") }, { id: "on", name: root.tr("On") }, { id: "battery", name: root.tr("On battery") }
  ]
  readonly property var uiScaleChoices: [
    { id: 1, name: "100%" }, { id: 1.25, name: "125%" }, { id: 1.5, name: "150%" }
  ]
  readonly property var wallpaperBlurChoices: [
    { id: "design", name: root.tr("As designed") }, { id: "sharp", name: root.tr("Sharp") },
    { id: "soft", name: root.tr("Soft") }, { id: "heavy", name: root.tr("Heavy") }
  ]
  readonly property var wallpaperDimChoices: [
    { id: "lighter", name: root.tr("Lighter") }, { id: "design", name: root.tr("As designed") }, { id: "darker", name: root.tr("Darker") }
  ]
  readonly property bool faceConfigured: service && service.faceConfigured === true
  readonly property string faceStart: service && service.faceStart !== undefined ? String(service.faceStart) : "wake"
  readonly property var onOffOptions: [{ id: "on", name: root.tr("On") }, { id: "off", name: root.tr("Off") }]
  readonly property var shownHiddenOptions: [{ id: "show", name: root.tr("Show") }, { id: "hide", name: root.tr("Hide") }]
  // What the password field shows beside the text (Settings > Password field).
  readonly property bool showLayoutBadge: !service || service.showLayoutBadge !== false
  readonly property bool showCapsBadge: !service || service.showCapsBadge !== false
  readonly property bool allowPasswordToggle: !service || service.allowPasswordToggle !== false
  readonly property bool showAuthIcons: !service || service.showAuthIcons !== false
  function setFieldItem(name, show) {
    if (!root.service || typeof root.service.setFieldItem !== "function") return
    root.service.setFieldItem(name, show)
  }
  property bool customDelayEditing: false
  property string customDelayText: ""
  readonly property bool blankDelayIsCustom: !root.keepDisplayOn && root.blankPresets.indexOf(root.blankDelay) === -1
  readonly property string unlockLabel: {
    for (var i = 0; i < unlockOptions.length; i++)
      if (unlockOptions[i].id === unlockAnimation) return root.tr(unlockOptions[i].name)
    return root.tr("Off")
  }
  // Top level view: the design grid, or one of the settings pages.
  property string mainTab: "styling"
  onMainTabChanged: {
    if ((mainTab === "boot" || mainTab === "editor") && service && typeof service.refreshBootPreviews === "function") service.refreshBootPreviews()
    if (mainTab !== "editor") bootEditing = ""
    refocus()
  }

  function toggleSettings(tab) {
    mainTab = mainTab === tab ? "styling" : tab
  }

  function handleEscape() {
    if (showingKeys) { showingKeys = false; return }
    if (searchText.length > 0 && gridTab) { searchText = ""; return }
    if (confirmingDelete.length > 0) { confirmingDelete = ""; return }
    if (designing) { designerView.requestClose(); return }
    if (editing) { closeEditor(); return }
    if (bootEditing.length > 0) { closeBootEditor(); return }
    if (fullPreview) { fullPreview = false; return }
    if (mainTab !== "styling") { mainTab = "styling"; refocus(); return }
    dismiss()
  }

  // Deleting a user design is a two-step: first X arms the button, second
  // confirms. Esc or moving the selection disarms.
  property string confirmingDelete: ""
  onSelectedIndexChanged: confirmingDelete = ""
  onDesignsChanged: {
    if (selectedIndex >= designs.length) selectedIndex = Math.max(0, designs.length - 1)
    thumbSlots = 0
  }

  function deleteSelected() {
    var d = root.selectedDesign
    if (!d || !d.path || !root.service) return
    if (root.confirmingDelete !== d.id) { root.confirmingDelete = d.id; return }
    root.confirmingDelete = ""
    root.service.deleteDesign(d.id)
  }

  // Boot cards use the same two-step confirm; only your own videos and
  // layouts get the button.
  function deleteBootCard(id) {
    if (root.confirmingDelete !== id) { root.confirmingDelete = id; return }
    root.confirmingDelete = ""
    if (root.service && typeof root.service.deleteBootItem === "function") root.service.deleteBootItem(id)
  }

  function refocus() { Qt.callLater(function() { keyCatcher.forceActiveFocus() }) }

  function focusSearch() {
    root.searching = true
    Qt.callLater(function() { searchInput.forceActiveFocus(); searchInput.selectAll() })
  }

  function leaveSearch() {
    root.searching = false
    refocus()
  }

  // Quick setting for the boot (LUKS decrypt) screen, applied through
  // `omarchy-shell lock setBoot`. Only designs with a Plymouth twin under
  // plymouth/ can style it; "follow" tracks the lock design when it has one.
  readonly property string followHint: {
    var d = Designs.byId(activeDesignId)
    var name = d ? d.name : root.tr("your lock screen")
    if (d && d.boot === true) return root.tr("Boot matches %1 with its animated twin").arg(name)
    return root.tr("Boot matches %1 as a still — same styling for both").arg(name)
  }
  // What the boot layout form's dropdowns show for each value.
  readonly property var bootOptionNames: ({
    theme: root.tr("Theme"), wallpaper: root.tr("Wallpaper"), none: root.tr("None"),
    pill: root.tr("Pill"), line: root.tr("Line")
  })
  function bootKindLabel(d) {
    if (!d || !d.bootKind) return root.tr("theme styling")
    if (d.bootKind === "clip") return root.tr("clip") + " \u00b7 " + root.tr("plays on unlock")
    if (d.bootKind === "reactive") return root.tr("reacts to typing")
    if (d.bootKind === "animated") return root.tr("animated")
    return root.tr("theme styling")
  }
  readonly property var bootTwins: {
    var twins = Designs.bootCapable()
    var rows = []
    for (var i = 0; i < twins.length; i++)
      rows.push({ id: twins[i].id, name: twins[i].name, hint: twins[i].description, kind: bootKindLabel(twins[i]) })
    return rows
  }
  readonly property string bootApplied: service ? service.bootApplied : ""
  readonly property string bootAppliedTheme: service ? service.bootAppliedTheme : ""
  readonly property string bootNowName: {
    if (bootApplied.length === 0) return root.tr("Stock Omarchy")
    if (bootApplied === "theme") return root.tr("Theme colors")
    if (bootApplied.indexOf("snapshot:") === 0) {
      var sd = Designs.byId(bootApplied.substring(9))
      return root.tr("%1 (snapshot)").arg(sd ? sd.name : bootApplied.substring(9))
    }
    if (bootApplied.indexOf("custom:") === 0) return bootApplied.substring(7)
    if (bootApplied.indexOf("video:") === 0) return bootApplied.substring(6).replace(/\.[^.]+$/, "")
    var d = Designs.byId(bootApplied)
    return d ? d.name : bootApplied
  }
  readonly property var bootVideos: service && service.bootVideos !== undefined ? service.bootVideos : []
  readonly property var bootCustomDesigns: service && service.bootCustomDesigns !== undefined ? service.bootCustomDesigns : []
  readonly property int bootClipSeconds: service && service.bootClipSeconds !== undefined ? service.bootClipSeconds : 0
  readonly property var bootCards: {
    var cards = [
      { id: "stock", name: root.tr("Untouched"), kind: root.tr("stock Omarchy splash") },
      { id: "theme", name: root.tr("Theme colors"), kind: root.tr("stock layout, your theme") }
    ]
    var claimed = {}
    var twins = Designs.bootCapable()
    for (var i = 0; i < twins.length; i++) {
      cards.push({ id: twins[i].id, name: twins[i].name, kind: bootKindLabel(twins[i]) + (twins[i].credit ? " \u00b7 " + root.tr("by %1").arg(twins[i].credit) : "") })
      if (twins[i].clipFile) claimed[twins[i].clipFile] = true
    }
    for (var v = 0; v < bootVideos.length; v++) {
      if (claimed[bootVideos[v]]) continue
      cards.push({ id: "video:" + bootVideos[v], name: bootVideos[v].replace(/\.[^.]+$/, ""), kind: root.tr("your clip") + " \u00b7 " + root.tr("plays on unlock") })
    }
    for (var c = 0; c < bootCustomDesigns.length; c++)
      cards.push({ id: "custom:" + bootCustomDesigns[c], name: bootCustomDesigns[c], kind: root.tr("your layout") })
    return cards
  }
  readonly property string bootFollowTarget: {
    if (bootSetting !== "follow") return ""
    var d = Designs.byId(activeDesignId)
    return d && d.boot === true ? d.id : ""
  }
  readonly property int bootPreviewsVersion: service && service.bootPreviewsVersion !== undefined ? service.bootPreviewsVersion : 0
  readonly property string bootCurrentTheme: service && service.bootCurrentTheme !== undefined ? service.bootCurrentTheme : ""

  function bootCardPreview(id) {
    var fileId = String(id).split(":").join("-")
    return "file://" + Quickshell.env("HOME") + "/.local/state/omarchy/lock-explorer-boot-previews/" + fileId + "-" + bootCurrentTheme + ".png?v=" + bootPreviewsVersion
  }

  property string bootEditing: ""
  property string bootEditorText: ""

  function openBootEditor(name) {
    root.mainTab = "editor"
    if (root.service && typeof root.service.loadBootDesign === "function") root.service.loadBootDesign(name)
  }

  // The unified layout editor works on a parsed key=value map; the form
  // controls edit known keys and serialize the whole map back, so keys the
  // form does not surface survive.
  property var bootFormMap: ({})
  property int bootFormRev: 0

  function bootFormGet(k, def) {
    var v = bootFormMap[k]
    return v === undefined ? def : v
  }
  // True from an edit until the previews caught up; drives the re-render
  // badge on the editor previews.
  property bool bootEditBusy: false

  function bootFormSet(k, v) {
    // A fresh object, or the var property emits no change signal and every
    // control bound through bootFormGet stays visually frozen.
    var m = Object.assign({}, bootFormMap)
    m[k] = String(v)
    bootFormMap = m
    bootFormRev++
    bootEditBusy = true
    bootFormSaveTimer.restart()
  }
  function bootFormParse(content) {
    var m = {}
    var lines = String(content).split("\n")
    for (var i = 0; i < lines.length; i++) {
      var line = lines[i]
      if (/^\s*#/.test(line)) continue
      var eq = line.indexOf("=")
      if (eq === -1) continue
      var key = line.substring(0, eq).trim()
      if (key.length === 0) continue
      m[key] = line.substring(eq + 1).trim()
    }
    bootFormMap = m
    bootFormRev++
  }
  function bootFormSerialize() {
    var order = ["background", "scanlines", "logo", "logo_y", "logo_height",
                 "title", "title_y", "title_size", "title_color",
                 "subtitle", "subtitle_y", "subtitle_size", "subtitle_color",
                 "clock", "entry", "entry_y", "entry_width", "hint"]
    var out = "# Layout for a matching lock screen and boot screen.\n"
    var seen = {}
    for (var i = 0; i < order.length; i++) {
      var k = order[i]
      if (bootFormMap[k] !== undefined) { out += k + " = " + bootFormMap[k] + "\n"; seen[k] = true }
    }
    for (var k2 in bootFormMap)
      if (!seen[k2]) out += k2 + " = " + bootFormMap[k2] + "\n"
    return out
  }
  function saveBootForm() {
    if (bootEditing.length === 0) return
    if (service && typeof service.saveBootDesign === "function")
      service.saveBootDesign(bootEditing, bootFormSerialize())
  }

  Timer {
    id: bootFormSaveTimer
    interval: 400
    onTriggered: root.saveBootForm()
  }

  function closeBootEditor() {
    root.bootEditing = ""
    refocus()
  }

  // Escape is handled by the keyCatcher (the Omarchy layer-shell idiom); the
  // editor's text fields forward it via BootField.escaped().

  function saveBootDesignEdits() {
    if (root.bootEditing.length === 0) return
    if (root.service && typeof root.service.saveBootDesign === "function")
      root.service.saveBootDesign(root.bootEditing, bootEditorArea.text)
  }

  function newBootDesign() {
    root.mainTab = "editor"
    if (root.service && typeof root.service.createBootDesign === "function") root.service.createBootDesign()
  }

  readonly property var bootRotation: service && service.bootRotation !== undefined ? service.bootRotation : []
  readonly property bool bootRotating: bootSetting === "rotate"

  function toggleRotationMode() {
    if (root.bootApplying) return
    if (root.bootRotating) { root.setBoot(root.bootApplied.length > 0 ? root.bootApplied : "stock"); return }
    if (root.service && typeof root.service.enableBootRotation === "function") root.service.enableBootRotation()
  }

  function toggleInRotation(id) {
    if (root.service && typeof root.service.toggleBootRotation === "function") root.service.toggleBootRotation(id)
  }

  function inRotation(id) {
    return root.bootRotation.indexOf(id) !== -1
  }

  // Grab a full-resolution render of the active lock design and apply it as
  // a static boot background. The hidden host below does the rendering.
  // Whether the snapshot, once taken, is saved as the boot setting (a pinned
  // snapshot) or just applied as the artifact under a "follow" setting.
  property bool snapshotPersist: true

  function snapshotActiveDesign() { snapshotAndApply(root.activeDesignId, true) }

  // True while an off-screen snapshot is in flight; keeps the snapshot host's
  // wallpaper loaded even when the explorer is closed (theme-change resyncs
  // arrive with the panel down).
  property bool snapshotBusy: false
  property string snapshotRect: ""

  // Boot snapshots are captured at the display's own geometry, not at a fixed
  // 1920x1080. Plymouth scales the capture to the framebuffer, so a 16:9 grab
  // on an ultrawide came out stretched; and a responsive design laid out for
  // 1920 wide is the wrong composition at 3440 even before any stretch.
  // The window that renders the snapshot decides its geometry. A headless
  // snapshot can run before the explorer has ever been mapped, when
  // panel.screen may still be empty and the grab would fall to 1920x1080.
  readonly property var snapshotScreen: snapshotWindow.screen || panel.screen || (Quickshell.screens.length > 0 ? Quickshell.screens[0] : null)
  readonly property int snapshotWidth: snapshotScreen && snapshotScreen.width > 0 ? snapshotScreen.width : 1920
  readonly property int snapshotHeight: snapshotScreen && snapshotScreen.height > 0 ? snapshotScreen.height : 1080
  // grabToImage wants device pixels; the item is sized in logical ones, so a
  // scaled display still writes a capture at its true framebuffer resolution.
  readonly property real snapshotScale: snapshotScreen && snapshotScreen.devicePixelRatio > 0 ? snapshotScreen.devicePixelRatio : 1
  readonly property int snapshotPixelWidth: Math.round(snapshotWidth * snapshotScale)
  readonly property int snapshotPixelHeight: Math.round(snapshotHeight * snapshotScale)

  function snapshotAndApply(id, persist) {
    if (root.bootApplying) return
    root.snapshotBusy = true
    snapshotHost.designId = id
    // Flip snapshot mode before the render delay so any layout it causes has
    // settled long before the geometry is measured and the frame grabbed.
    if (snapshotHost.item && snapshotHost.item.snapshotMode !== undefined)
      snapshotHost.item.snapshotMode = true
    root.snapshotPersist = persist === undefined ? true : persist
    snapshotMkdirProc.running = true
  }

  Process {
    id: snapshotMkdirProc
    command: ["mkdir", "-p", Quickshell.env("HOME") + "/.local/state/omarchy/lock-explorer-snapshots"]
    onExited: function(code) {
      snapshotRenderTimer.restart()
    }
  }

  // Give the design a beat to load its wallpaper and lay out before grabbing.
  Timer {
    id: snapshotRenderTimer
    interval: 1100
    onTriggered: {
      var id = snapshotHost.designId
      var path = Quickshell.env("HOME") + "/.local/state/omarchy/lock-explorer-snapshots/" + id + ".png"
      // The design keeps its input box but empties it (see snapshotMode); the
      // boot theme puts its bullets inside that box, so the boot screen uses
      // the design's own field instead of a generic pill.
      var it = snapshotHost.item
      if (it && it.snapshotMode !== undefined) it.snapshotMode = true
      var rect = ""
      var n = it && it.inputItem ? it.inputItem : null
      while (n && n !== it && n.placeholder === undefined) n = n.parent
      if (n && n !== it && n.placeholder !== undefined && n.visible) {
        // Measure the input text area (inputItem sits between the lock glyph
        // and the eye), and carry the field's alignment so the bullets start
        // where the lock screen's dots would.
        var ia = it.inputItem
        var p = ia.mapToItem(snapshotSource, 0, 0)
        var align = n.textAlignment === TextInput.AlignLeft ? "left"
                  : n.textAlignment === TextInput.AlignRight ? "right" : "center"
        var sw = root.snapshotWidth, sh = root.snapshotHeight
        rect = (100 * (p.x + ia.width / 2) / sw).toFixed(2) + "," + (100 * (p.y + ia.height / 2) / sh).toFixed(2)
             + "," + (100 * ia.width / sw).toFixed(2) + "," + (100 * ia.height / sh).toFixed(2)
             + "," + align
      }
      var grabOk = snapshotSource.grabToImage(function(result) {
        var saved = result && result.saveToFile(path)
        if (root.service) root.service.logEvent("snapshot-grab " + id + (saved ? " ok rect=" + rect : " save-failed"))
        if (!saved) { root.snapshotBusy = false; return }
        root.snapshotRect = rect
        // Second, box-free grab: apply.sh picks it up as the background for
        // reboot/shutdown and promptless stretches of boot, so the splash
        // never shows a dead entry box (see snapshotBare in DesignBase).
        if (it && it.snapshotBare !== undefined) {
          it.snapshotBare = true
          snapshotBareTimer.restart()
        } else {
          root.snapshotFinish()
        }
      }, Qt.size(root.snapshotPixelWidth, root.snapshotPixelHeight))
      if (!grabOk) {
        root.snapshotBusy = false
        if (root.service) root.service.logEvent("snapshot-grab-deferred " + id)
        // Never-shown window: park the request for the next open and say so.
        if (!root.pendingResnapshot) {
          root.pendingResnapshot = { id: id, persist: root.snapshotPersist }
          Quickshell.execDetached(["notify-send", "-a", "Lock Screen Explorer",
            root.tr("Boot screen is out of date"),
            root.tr("The background changed. Open the lock screen explorer once and it refreshes itself.")])
        }
      }
    }
  }

  // Wraps up a snapshot flow: resets the bare flag and hands the grabbed
  // frame(s) to the service. Split out because the box-free second grab
  // arrives asynchronously.
  function snapshotFinish() {
    root.snapshotBusy = false
    var it = snapshotHost.item
    if (it && it.snapshotBare !== undefined) it.snapshotBare = false
    if (root.service && typeof root.service.applyBootSnapshot === "function")
      root.service.applyBootSnapshot(snapshotHost.designId, root.snapshotPersist, root.snapshotRect)
  }

  // One frame is not reliably enough for the opacity change to land in the
  // next grab; a short settle keeps the box-free capture honest. If this grab
  // fails, snapshotFinish still applies: apply.sh only trusts a plain capture
  // newer than the snapshot, so a stale or missing file falls back cleanly.
  Timer {
    id: snapshotBareTimer
    interval: 150
    onTriggered: {
      var id = snapshotHost.designId
      var ppath = Quickshell.env("HOME") + "/.local/state/omarchy/lock-explorer-snapshots/" + id + "-plain.png"
      var ok = snapshotSource.grabToImage(function(result) {
        var saved = result && result.saveToFile(ppath)
        if (root.service) root.service.logEvent("snapshot-grab-plain " + id + (saved ? " ok" : " save-failed"))
        root.snapshotFinish()
      }, Qt.size(root.snapshotPixelWidth, root.snapshotPixelHeight))
      if (!ok) root.snapshotFinish()
    }
  }

  // Apply a lock styling as the boot screen: its hand-written Plymouth twin if
  // it has one, otherwise a full-screen snapshot. This is what makes every
  // styling available for the boot screen too. persist=false keeps the boot
  // setting on "follow".
  function bootUseStyling(id, persist) {
    if (root.bootApplying) return
    var d = Designs.byId(id)
    if (d && d.boot === true) root.setBoot(id)
    else root.snapshotAndApply(id, persist === undefined ? true : persist)
  }

  function toggleFollow() {
    if (root.bootApplying) return
    // Just sets the desired choice; Apply builds it.
    if (root.bootSetting === "follow") root.setBoot("stock")
    else root.setBoot("follow")
  }

  // While following, re-match the boot screen when the lock styling changes.
  // Changing the lock styling under follow marks the boot screen dirty (via
  // bootWouldApply); it rebuilds only when Apply is pressed.

  readonly property string bootSetting: service ? service.bootSetting : "stock"
  readonly property bool bootApplying: service ? service.bootApplying : false
  readonly property string bootLabel: {
    if (bootApplying) return "applying..."
    if (bootSetting === "stock") return "Untouched"
    if (bootSetting === "theme") return "Theme colors"
    if (bootSetting === "follow") {
      var d = Designs.byId(activeDesignId)
      return d && d.boot === true ? "Match lock (" + d.name + ")" : "Match lock (no twin)"
    }
    var picked = Designs.byId(bootSetting)
    return picked ? picked.name : bootSetting
  }
  readonly property bool bootResync: service && service.bootResync !== undefined ? service.bootResync : true

  function setBoot(id) {
    if (root.bootApplying) return
    if (root.service && typeof root.service.setBoot === "function") root.service.setBoot(id)
  }

  function toggleBootResync() {
    if (root.service && typeof root.service.setBootResync === "function") root.service.setBootResync(!root.bootResync)
  }

  readonly property bool clipWallpaper: service && service.clipWallpaper !== undefined ? service.clipWallpaper : false

  function toggleClipWallpaper() {
    if (root.service && typeof root.service.setClipWallpaper === "function") root.service.setClipWallpaper(!root.clipWallpaper)
  }

  readonly property real clipSpeed: service && service.clipSpeed !== undefined ? service.clipSpeed : 1
  readonly property var clipSpeeds: [0.5, 0.75, 1, 1.25, 1.5, 2]

  function setClipSpeed(v) {
    if (root.service && typeof root.service.setClipSpeed === "function") root.service.setClipSpeed(v)
  }

  readonly property bool twelveHour: service && service.twelveHour !== undefined ? service.twelveHour : false
  readonly property var clockFormats: [{ id: "24", name: "24h" }, { id: "12", name: "12h AM/PM" }]

  function setTwelveHour(on) {
    if (root.service && typeof root.service.setTwelveHour === "function") root.service.setTwelveHour(on)
  }

  // The launcher and Omarchy menu entries, see extras/install.sh.
  readonly property bool menuEntryInstalled: service && service.menuEntryInstalled === true
  readonly property var menuEntryOptions: [{ id: "on", name: root.tr("Added") }, { id: "off", name: root.tr("Not added") }]

  function setMenuEntry(on) {
    if (root.service && typeof root.service.setMenuEntry === "function") root.service.setMenuEntry(on)
  }

  // Security-key unlock. The row only appears once the PAM side is in place
  // (extras/setup-fido2.sh); the toggle decides whether the lock screen uses
  // it, and never touches PAM itself.
  readonly property bool fido2Installed: service && service.fido2Installed === true
  readonly property bool fido2Enabled: service && service.fido2Enabled !== undefined ? service.fido2Enabled : true
  readonly property var fido2Options: [{ id: "on", name: root.tr("On") }, { id: "off", name: root.tr("Off") }]

  function setFido2Enabled(on) {
    if (root.service && typeof root.service.setFido2Enabled === "function") root.service.setFido2Enabled(on)
  }

  readonly property bool hasAvatar: avatarUrl.length > 0
  readonly property string userInitial: {
    var name = Quickshell.env("USER") || Quickshell.env("LOGNAME") || "user"
    return name.length > 0 ? name.charAt(0).toUpperCase() : "?"
  }

  readonly property color background: Color.menu.background
  readonly property color foreground: Color.menu.text
  readonly property color muted: Qt.rgba(foreground.r, foreground.g, foreground.b, 0.6)
  readonly property color accent: Color.accent
  readonly property color scrim: Color.menu.scrim
  // Errors and the delete confirm take the theme's urgent color. Badges and
  // dimmers over thumbnails are the theme background at an alpha, so their
  // foreground text stays readable on light themes too.
  readonly property color danger: Color.urgent
  function shade(alpha) { return Qt.rgba(Color.background.r, Color.background.g, Color.background.b, alpha) }
  readonly property var borderSpec: Border.surfaceSpec("menu", "border", Color.menu.border, Math.max(1, Style.space(2)))
  // Redesign visual language: sharp corners, everforest-style typography.
  // Colors still follow the Omarchy theme.
  readonly property int cornerRadius: 0
  readonly property string fontFamily: Style.font.menuFamily
  readonly property int sidebarW: Style.space(172)
  readonly property int rightPanelW: Style.space(348)
  readonly property string bootAppliedId: bootApplied.length > 0 ? bootApplied : "stock"

  // What the current boot choice WOULD install, and whether that differs from
  // what is on disk — the Apply button and banner key off this. Nothing is
  // rebuilt until Apply is pressed.
  readonly property string bootWouldApply: {
    if (bootSetting === "stock") return "stock"
    if (bootSetting === "theme") return "theme"
    if (bootSetting.indexOf("snapshot:") === 0) return bootSetting
    if (bootSetting.indexOf("custom:") === 0 || bootSetting.indexOf("video:") === 0) return bootSetting
    if (bootSetting === "follow") {
      var d = Designs.byId(activeDesignId)
      return d && d.boot === true ? d.id : "snapshot:" + activeDesignId
    }
    return bootSetting
  }
  readonly property bool bootDirty: !bootApplying && bootWouldApply !== bootAppliedId
  readonly property string bootDesiredName: {
    var w = bootWouldApply
    if (w === "stock") return root.tr("Untouched")
    if (w === "theme") return root.tr("Theme colors")
    if (w.indexOf("snapshot:") === 0) {
      var sd = Designs.byId(w.substring(9))
      return root.tr("%1 (snapshot)").arg(sd ? sd.name : w.substring(9))
    }
    if (w.indexOf("custom:") === 0) return w.substring(7)
    if (w.indexOf("video:") === 0) return w.substring(6).replace(/\.[^.]+$/, "")
    var d = Designs.byId(w)
    return d ? d.name : w
  }

  function applyPendingBoot() {
    if (root.bootApplying) return
    var w = root.bootWouldApply
    if (w.indexOf("snapshot:") === 0) {
      // follow-without-twin keeps the "follow" setting; a pinned snapshot persists.
      root.snapshotAndApply(w.substring(9), root.bootSetting !== "follow")
      return
    }
    if (root.service && typeof root.service.applyBoot === "function") root.service.applyBoot(true, w)
  }
  readonly property string currentThemeName: service && service.bootCurrentTheme !== undefined && service.bootCurrentTheme.length > 0 ? service.bootCurrentTheme : "your theme"

  readonly property int columns: 3
  readonly property int contentMargin: Style.spacing.panelPadding + Style.space(8)
  readonly property int gap: Style.space(20)
  readonly property int captionHeight: Style.space(58)
  readonly property int headerHeight: Style.space(96)
  readonly property int footerHeight: Style.space(40)
  readonly property int borderWidth: Math.max(1, Style.space(2))
  readonly property int cardWidth: Math.min(Style.space(1560), panel.width - Style.gapsOut * 4)
  readonly property int cardHeight: panel.height - Style.gapsOut * 2
  readonly property int cellWidth: Math.floor(grid.width / columns)
  readonly property int thumbWidth: cellWidth - gap
  readonly property int thumbHeight: Math.round(thumbWidth * 9 / 16)

  // Tab asked for via `omarchy-shell lock exploreTab <tab>`; open() resets to
  // styling otherwise, so the request has to survive the summon.
  property string requestedTab: ""

  function open(payloadJson) {
    root.opened = true
    root.fullPreview = false
    // Back from the file dialog: drop straight into the design that was open.
    if (root.designerPaused) {
      root.designerPaused = false
      root.requestedTab = ""
      if (root.service && typeof root.service.rescanUserDesigns === "function") root.service.rescanUserDesigns()
      Qt.callLater(function() { designerView.focusCanvas() })
      return
    }
    root.mainTab = root.requestedTab.length > 0 ? root.requestedTab : "styling"
    root.requestedTab = ""
    root.category = "all"
    var idx = Designs.indexOf(root.activeDesignId)
    root.selectedIndex = idx >= 0 ? idx : 0
    if (root.service) {
      if (typeof root.service.rescanUserDesigns === "function") root.service.rescanUserDesigns()
      if (typeof root.service.refreshBackground === "function") root.service.refreshBackground()
      if (typeof root.service.refreshFingerprintStatus === "function") root.service.refreshFingerprintStatus()
      if (typeof root.service.refreshFido2Status === "function") root.service.refreshFido2Status()
    }
    Qt.callLater(function() { keyCatcher.forceActiveFocus() })
    revealTimer.restart()
  }

  Timer {
    id: revealTimer
    interval: 80
    onTriggered: {
      root.reveal(GridView.Center)
      keyCatcher.forceActiveFocus()
    }
  }

  function close() { root.opened = false }

  function dismiss() {
    root.opened = false
    root.fullPreview = false
    root.showingKeys = false
    root.searchText = ""
    root.searching = false
    if (root.designerPaused) {
      if (root.shell && typeof root.shell.hide === "function") root.shell.hide(root.pluginId)
      return
    }
    root.mainTab = "styling"
    root.editing = false
    root.editingDesign = null
    root.designing = false
    root.designingDesign = null
    if (root.shell && typeof root.shell.hide === "function") root.shell.hide(root.pluginId)
  }

  function toggle() {
    if (root.opened) root.dismiss()
    else root.open("{}")
  }

  function positionAtSelected(mode) {
    grid.positionViewAtIndex(root.selectedIndex, mode)
    var minY = grid.originY - grid.topMargin
    var maxY = Math.max(minY, grid.originY + grid.contentHeight - grid.height + grid.bottomMargin)
    if (grid.contentY < minY) grid.contentY = minY
    else if (grid.contentY > maxY) grid.contentY = maxY
  }

  function reveal(mode) {
    positionAtSelected(mode)
    Qt.callLater(function() { positionAtSelected(mode) })
  }

  function setCategory(id) {
    if (id === root.category) return
    var current = root.selectedDesign ? root.selectedDesign.id : ""
    root.category = id
    var list = Designs.inCategory(id)
    var keep = -1
    for (var i = 0; i < list.length; i++) if (list[i].id === current) keep = i
    root.selectedIndex = keep >= 0 ? keep : 0
    reveal(GridView.Contain)
  }

  function move(delta) {
    var n = designs.length
    if (n === 0) return
    selectedIndex = (selectedIndex + delta + n) % n
    reveal(GridView.Contain)
  }

  function moveRow(delta) {
    var next = selectedIndex + delta * columns
    if (next < 0 || next >= designs.length) return
    selectedIndex = next
    reveal(GridView.Contain)
  }

  function selectById(id) {
    var list = root.designs
    for (var i = 0; i < list.length; i++) if (list[i].id === id) { root.selectedIndex = i; reveal(GridView.Contain); return true }
    return false
  }

  // The overlay owns the keyboard, so the file dialog needs it out of the way.
  // The service brings the explorer back when the dialog is answered.
  function pickAvatar() {
    if (!root.service) return
    root.dismiss()
    root.service.pickAvatar(true)
  }

  function clearAvatar() {
    if (root.service) root.service.clearAvatar()
  }

  // Same story as the avatar: the dialog needs the keyboard, so step aside.
  function pickVideo(target) {
    if (!root.service) return
    root.dismiss()
    root.service.pickVideo(true, target || "video")
  }

  // Your own video as an unlock clip: pick a file, the service writes the
  // one-line ClipDesign and it appears under Animation.
  function newClipDesign() {
    root.pickVideo("clip")
  }

  function clearVideo() {
    if (root.service) root.service.clearVideo()
  }

  function clearSting() {
    if (root.service) root.service.clearSting()
  }

  function previewSting() {
    if (!root.service || !root.service.stingPath) return
    root.dismiss()
    root.service.playSting()
  }

  function setUnlock(id) {
    if (root.service) root.service.setUnlockAnimation(id)
  }

  function setUnlockDuration(ms) {
    if (root.service) root.service.setUnlockDuration(ms)
  }

  function setBlankAfter(ms) {
    if (!root.service) return
    root.customDelayEditing = false
    if (ms === 0) {
      root.service.setKeepDisplayOn(true)
      return
    }
    root.service.setKeepDisplayOn(false)
    root.service.setBlankDelay(ms)
  }

  // How long the field stays inert after a key has woken the display, so the
  // keys that lit the panel stay out of the password.
  // Sleep, restart and shut down on the lock screen. Off by default: with it
  // on, anyone at the machine can restart it without the password.
  function setPowerActions(on) {
    if (!root.service || typeof root.service.setPowerActions !== "function") return
    root.service.setPowerActions(on)
  }

  function setWallpaperBlur(id) {
    if (!root.service || typeof root.service.setWallpaperBlur !== "function") return
    root.service.setWallpaperBlur(id)
  }

  function setReduceMotion(id) {
    if (!root.service || typeof root.service.setReduceMotion !== "function") return
    root.service.setReduceMotion(id)
  }

  function setLanguage(id) {
    if (!root.service || typeof root.service.setLanguage !== "function") return
    root.service.setLanguage(id)
  }

  function setUiScale(id) {
    if (!root.service || typeof root.service.setUiScale !== "function") return
    root.service.setUiScale(id)
  }

  function setWallpaperDim(id) {
    if (!root.service || typeof root.service.setWallpaperDim !== "function") return
    root.service.setWallpaperDim(id)
  }

  function setAwayReport(on) {
    if (!root.service || typeof root.service.setAwayReport !== "function") return
    root.service.setAwayReport(on)
  }

  function setLockOnKeyRemoval(on) {
    if (!root.service || typeof root.service.setLockOnKeyRemoval !== "function") return
    root.service.setLockOnKeyRemoval(on)
  }

  function setWakeOnKeyInsert(on) {
    if (!root.service || typeof root.service.setWakeOnKeyInsert !== "function") return
    root.service.setWakeOnKeyInsert(on)
  }

  function setWakeGrace(ms) {
    if (!root.service || typeof root.service.setWakeGrace !== "function") return
    root.service.setWakeGrace(ms)
  }

  function setFaceStart(value) {
    if (!root.service || typeof root.service.setFaceStart !== "function") return
    root.service.setFaceStart(value)
  }

  function beginCustomDelay() {
    root.customDelayText = root.keepDisplayOn ? "" : String(Math.max(1, Math.round(root.blankDelay / 60000)))
    root.customDelayEditing = true
    Qt.callLater(function() {
      customDelayInput.forceActiveFocus()
      customDelayInput.selectAll()
    })
  }

  function commitCustomDelay() {
    var minutes = Math.round(Number(root.customDelayText))
    if (!isFinite(minutes) || minutes < 1 || minutes > 60) return
    if (!root.service) return
    root.service.setKeepDisplayOn(false)
    root.service.setBlankDelay(minutes * 60000)
    root.customDelayEditing = false
    keyCatcher.forceActiveFocus()
  }

  function customizeSelected() {
    if (!root.selectedDesign || !root.service) return
    if (root.selectedDesign.path) { editSelected(); return }
    root.service.customizeDesign(root.selectedDesign.id)
  }

  // A design of your own opens where it was made: the designer for a layout,
  // the code editor for hand-written QML.
  function editSelected() {
    var d = root.selectedDesign
    if (!d || !d.path) return
    if (d.designer) root.openDesigner(d)
    else root.openEditor(d)
  }

  function newDesign() {
    if (root.service) root.service.customizeDesign("new")
  }

  // A new visual design: the service writes the starter layout, and the
  // designerDesignCreated signal below opens it.
  function newDesignerDesign() {
    if (!root.service) return
    root.service.createDesignerDesign(Layout.generate(Layout.starterDoc("My Layout"), root.pluginId))
  }

  function openDesigner(design) {
    if (!design || !design.path) return
    root.designingDesign = design
    root.designing = true
    root.editing = false
    root.fullPreview = false
    // Re-read it: the same design may have been edited as code in between.
    Qt.callLater(function() { designerView.load() })
    // And hand it the keyboard once the card is really up. Asking on the same
    // tick does not stick — the shortcuts then stay dead until the first click
    // lands inside the designer.
    designerFocusTimer.restart()
  }

  Timer {
    id: designerFocusTimer
    interval: 150
    repeat: false
    onTriggered: if (root.designing) designerView.focusCanvas()
  }

  function closeDesigner() {
    root.designing = false
    root.designingDesign = null
    if (root.service && typeof root.service.rescanUserDesigns === "function") root.service.rescanUserDesigns()
    Qt.callLater(function() { keyCatcher.forceActiveFocus() })
  }

  // The Image piece needs the file dialog, which needs the keyboard. Save
  // first, step aside, and come back into the same design.
  function pickDesignerImage() {
    if (!root.service) return
    designerView.save()
    root.designerPaused = true
    root.dismiss()
    root.service.pickImage(true)
  }

  function openEditor(design) {
    if (!design || !design.path) return
    root.editingDesign = design
    root.editing = true
    root.fullPreview = false
    Qt.callLater(function() { editorView.focusCode() })
  }

  function closeEditor() {
    root.editing = false
    root.editingDesign = null
    Qt.callLater(function() { keyCatcher.forceActiveFocus() })
  }

  function openExternal(path) {
    Quickshell.execDetached(["omarchy-launch-editor", path])
    root.dismiss()
  }

  Connections {
    target: root.service
    ignoreUnknownSignals: true
    function onBootDesignLoaded(name, content) {
      root.bootFormParse(content)
      root.bootEditing = name
      root.mainTab = "editor"
    }
    function onDesignCustomized(id, path) {
      if (!root.opened) return
      root.setCategory("custom")
      Qt.callLater(function() {
        root.selectById(id)
        var d = Designs.byId(id)
        if (d) root.openEditor(d)
      })
    }
    function onDesignerDesignCreated(id, path) {
      if (!root.opened) return
      Qt.callLater(function() {
        root.selectById(id)
        var d = Designs.byId(id)
        if (d) root.openDesigner(d)
      })
    }
    function onImagePicked(path) {
      designerView.fileFieldPicked(path)
    }
    function onClipDesignAdded(id) {
      root.mainTab = "animation"
      Qt.callLater(function() { root.selectById(id) })
    }
    function onBootPreviewsVersionChanged() {
      if (root.service && !root.service.bootPreviewsRunning && !root.service.bootPreviewsPending)
        root.bootEditBusy = false
    }
    function onExploreTabRequested(tab) {
      if (tab !== "styling" && tab !== "animation" && tab !== "favorites" && tab !== "boot" && tab !== "settings") return
      // summon() re-runs open() even when already open, and open() resets the
      // tab — stash the request so it survives either path.
      root.requestedTab = tab
      if (root.opened) root.mainTab = tab
    }
    // Theme changed under an applied snapshot: retake it under the new theme.
    function onBootResnapshotRequested(designId, persist) {
      if (root.service) root.service.logEvent("resnapshot-request " + designId)
      root.snapshotAndApply(designId, persist)
    }
  }

  function useDesign(id, dismissAfter) {
    if (!Designs.byId(String(id)) || selectDesignProc.running) return
    root.selectionError = ""
    if (root.service && typeof root.service.setDesign === "function") {
      if (root.service.setDesign(id)) {
        if (dismissAfter) root.dismiss()
      } else root.selectionError = "Could not select this lock design"
      return
    }
    // The authentication service is intentionally private in Omarchy 4.0.3.
    // Use its existing settings command, never expose the PAM service to UI.
    selectDesignProc.dismissAfter = dismissAfter
    selectDesignProc.command = ["omarchy-shell", "lock", "setDesign", String(id)]
    selectDesignProc.running = true
  }

  Process {
    id: selectDesignProc
    property bool dismissAfter: false
    stdout: StdioCollector { id: selectDesignOut; waitForEnd: true }
    onExited: function(code) {
      if (code === 0 && String(selectDesignOut.text || "").trim() === "ok") {
        localSettings.reload()
        if (dismissAfter) root.dismiss()
      } else root.selectionError = "Could not select this lock design; please try again"
    }
  }

  function apply() {
    if (selectedDesign) root.useDesign(selectedDesign.id, true)
  }

  // Dedicated render surface for background snapshots. grabToImage needs a
  // rendered frame, which the explorer panel only has while open — so a
  // theme/wallpaper change with a closed explorer always hit the deferred
  // path and the boot image went stale. This window exists only for the
  // duration of a snapshot flow and shows nothing: its content is parked
  // off-screen, it takes no focus, and it reserves no screen space.
  PanelWindow {
    id: snapshotWindow
    visible: root.snapshotBusy
    anchors { top: true; bottom: true; left: true; right: true }
    color: "transparent"
    WlrLayershell.namespace: "omarchy-lock-explorer-snapshot"
    WlrLayershell.layer: WlrLayer.Overlay
    WlrLayershell.keyboardFocus: WlrKeyboardFocus.None
    exclusionMode: ExclusionMode.Ignore
    // Click-through: it is mapped full-screen on the overlay layer for a second
    // or two per snapshot, and must not swallow clicks meant for the explorer.
    mask: Region {}

    // Off-screen full-resolution render used to snapshot a lock design into a
    // boot background. Parked far outside the window so it never shows.
    Item {
      id: snapshotSource
      // Parked relative to its own width: the item is as wide as the display
      // now, so a fixed offset would let a very wide one back onto the screen.
      x: -width - 200; y: -height - 200
      width: root.snapshotWidth; height: root.snapshotHeight
      LockHost {
        id: snapshotHost
        anchors.fill: parent
        designId: root.activeDesignId
        revision: root.service ? root.service.designsRevision : 0
        twelveHour: root.twelveHour
        wallpaperBlur: root.wallpaperBlurValue
        wallpaperDim: root.wallpaperDimShift
        uiScale: root.uiScale
        holdStill: root.motionReduced
        language: root.lockLanguage
        fullName: root.accountName
        showLayoutBadge: root.showLayoutBadge
        showCapsBadge: root.showCapsBadge
        allowPasswordToggle: root.allowPasswordToggle
        showAuthIcons: root.showAuthIcons
        backgroundPath: root.service ? root.service.backgroundPath : ""
        backgroundVersion: root.service ? root.service.backgroundVersion : 0
        avatarPath: root.service ? root.service.avatarPath : ""
        avatarVersion: root.service ? root.service.avatarVersion : 0
        inputEnabled: false
        loadBackground: root.opened || root.snapshotBusy
        passwordText: ""
        videoPath: root.service ? root.service.videoPath : ""
        videoPlaying: false
      }
    }
  }

  PanelWindow {
    id: panel
    visible: root.opened
    anchors { top: true; bottom: true; left: true; right: true }
    color: "transparent"
    WlrLayershell.namespace: "omarchy-lock-explorer"
    WlrLayershell.layer: WlrLayer.Overlay
    WlrLayershell.keyboardFocus: WlrKeyboardFocus.Exclusive
    exclusionMode: ExclusionMode.Ignore

    Rectangle { anchors.fill: parent; color: root.scrim }
    MouseArea { anchors.fill: parent; onClicked: root.dismiss() }

    Item {
      id: keyCatcher
      anchors.fill: parent
      focus: true
      Keys.priority: Keys.BeforeItem
      // Embedded lock previews can pull keyboard focus; reclaim it whenever
      // it drifts, except while a real editor field wants it.
      onActiveFocusChanged: {
        if (!activeFocus && root.opened && root.bootEditing.length === 0 && !root.editing
            && !root.designing && !root.customDelayEditing && !root.searching)
          Qt.callLater(function() {
            // Asked again: a click into the search field moves focus there
            // before the field has said it is searching.
            if (!root.searching && !keyCatcher.activeFocus) keyCatcher.forceActiveFocus()
          })
      }
      Keys.onPressed: function(event) {
        if (event.key === Qt.Key_Escape) { root.handleEscape(); event.accepted = true; return }
        if (root.designing) return
        if (root.editing) return
        if (root.bootEditing.length > 0) return
        if (root.customDelayEditing) return
        // event.text as well, since ? sits on a different key per layout.
        var question = event.key === Qt.Key_Question || event.text === "?"
        if (root.showingKeys) {
          if (question) root.showingKeys = false
          event.accepted = true
          return
        }
        if (question) { root.showingKeys = true; event.accepted = true; return }
        if (root.gridTab && (event.text === "/" || (event.key === Qt.Key_F && (event.modifiers & Qt.ControlModifier)))) {
          root.fullPreview = false
          root.focusSearch()
          event.accepted = true
          return
        }
        // The settings pages scroll from the keyboard as well as the wheel.
        if (!root.gridTab && root.mainTab === "settings") {
          var page = settingsFlick.height * 0.85
          var bottom = Math.max(0, settingsFlick.contentHeight - settingsFlick.height)
          var y = settingsFlick.contentY
          if (event.key === Qt.Key_Down || event.key === Qt.Key_J) y += Style.space(60)
          else if (event.key === Qt.Key_Up || event.key === Qt.Key_K) y -= Style.space(60)
          else if (event.key === Qt.Key_PageDown || event.key === Qt.Key_Space) y += page
          else if (event.key === Qt.Key_PageUp) y -= page
          else if (event.key === Qt.Key_Home) y = 0
          else if (event.key === Qt.Key_End) y = bottom
          else y = -1
          if (y !== -1) {
            settingsFlick.contentY = Math.max(0, Math.min(bottom, y))
            event.accepted = true
            return
          }
        }
        if (!root.gridTab) {
          if (event.key === Qt.Key_U) { root.toggleSettings("settings"); event.accepted = true }
          else if (event.key === Qt.Key_B) { root.toggleSettings("boot"); event.accepted = true }
          return
        }
        if (event.key === Qt.Key_Return || event.key === Qt.Key_Enter) {
          root.apply(); event.accepted = true
        } else if (event.key === Qt.Key_Space || event.key === Qt.Key_P) {
          root.fullPreview = !root.fullPreview; event.accepted = true
        } else if (event.key === Qt.Key_C) {
          root.customizeSelected(); event.accepted = true
        } else if (event.key === Qt.Key_E) {
          if (root.selectedDesign && root.selectedDesign.path) root.editSelected()
          else root.customizeSelected()
          event.accepted = true
        } else if (event.key === Qt.Key_D) {
          if (root.selectedDesign && root.selectedDesign.designer) root.openDesigner(root.selectedDesign)
          else root.newDesignerDesign()
          event.accepted = true
        } else if (event.key === Qt.Key_N) {
          root.newDesign(); event.accepted = true
        } else if (event.key === Qt.Key_X || event.key === Qt.Key_Delete) {
          root.deleteSelected(); event.accepted = true
        } else if (event.key === Qt.Key_A) {
          if (event.modifiers & Qt.ShiftModifier) root.clearAvatar()
          else root.pickAvatar()
          event.accepted = true
        } else if (event.key === Qt.Key_V) {
          if (event.modifiers & Qt.ShiftModifier) root.clearVideo()
          else root.pickVideo("video")
          event.accepted = true
        } else if (event.key === Qt.Key_S) {
          if (event.modifiers & Qt.ShiftModifier) root.clearSting()
          else root.pickVideo("sting")
          event.accepted = true
        } else if (event.key === Qt.Key_U) {
          root.toggleSettings("settings")
          event.accepted = true
        } else if (event.key === Qt.Key_B) {
          root.toggleSettings("boot")
          event.accepted = true
        } else if (event.key === Qt.Key_F) {
          if (root.selectedDesign && root.service && typeof root.service.toggleFavorite === "function")
            root.service.toggleFavorite(root.selectedDesign.id)
          event.accepted = true
        } else if (event.key === Qt.Key_Tab || event.key === Qt.Key_Backtab) {
          // Through the grid entries in the sidebar, as if clicking the next.
          var tabs = ["styling", "animation", "favorites"]
          var step = event.key === Qt.Key_Backtab ? tabs.length - 1 : 1
          root.mainTab = tabs[(Math.max(0, tabs.indexOf(root.mainTab)) + step) % tabs.length]
          event.accepted = true
        } else if (event.key === Qt.Key_Left || event.key === Qt.Key_H) {
          root.move(-1); event.accepted = true
        } else if (event.key === Qt.Key_Right || event.key === Qt.Key_L) {
          root.move(1); event.accepted = true
        } else if (event.key === Qt.Key_Up || event.key === Qt.Key_K) {
          if (root.fullPreview) root.move(-1); else root.moveRow(-1)
          event.accepted = true
        } else if (event.key === Qt.Key_Down || event.key === Qt.Key_J) {
          if (root.fullPreview) root.move(1); else root.moveRow(1)
          event.accepted = true
        } else if (event.key === Qt.Key_Home) {
          root.selectedIndex = 0; root.reveal(GridView.Beginning); event.accepted = true
        } else if (event.key === Qt.Key_End) {
          root.selectedIndex = Math.max(0, root.designs.length - 1); root.reveal(GridView.End); event.accepted = true
        } else if (event.key === Qt.Key_PageDown) {
          grid.contentY = Math.min(grid.contentHeight - grid.height, grid.contentY + grid.height); event.accepted = true
        } else if (event.key === Qt.Key_PageUp) {
          grid.contentY = Math.max(0, grid.contentY - grid.height); event.accepted = true
        }
      }
    }

    BorderSurface {
      id: card
      visible: !root.fullPreview && !root.editing
      width: root.cardWidth
      height: root.cardHeight
      radius: root.cornerRadius
      anchors.centerIn: parent
      color: root.background
      borderSpec: root.borderSpec
      padding: root.contentMargin

      MouseArea { anchors.fill: parent; onClicked: {} }

      Item {
        id: header
        z: 10
        anchors.top: parent.top
        anchors.left: parent.left
        anchors.right: parent.right
        anchors.topMargin: card.contentTopInset
        anchors.leftMargin: card.contentLeftInset
        anchors.rightMargin: card.contentRightInset
        height: root.headerHeight

        Column {
          anchors.left: parent.left
          anchors.top: parent.top
          spacing: 3
          Row {
            spacing: Style.space(8)
            Text {
              text: "::"
              color: root.accent
              font.family: root.fontFamily
              font.pixelSize: Style.font.display
              font.weight: Font.Bold
            }
            Text {
              text: root.tr("LOCK SCREEN EXPLORER")
              color: root.foreground
              font.family: root.fontFamily
              font.pixelSize: Style.font.display
              font.weight: Font.Bold
              font.letterSpacing: 2
            }
          }
          Text {
            text: {
              if (root.wallpaperBroken) return root.tr("Wallpaper failed to load")
                + (root.wallpaperIsWebp ? " — " + root.tr("WebP needs %1, then %2").arg("sudo pacman -S qt6-imageformats").arg("omarchy restart shell") : "")
              if (root.mainTab === "settings") return root.tr("How the lock screen looks, unlocks and looks after itself")
              if (root.mainTab === "boot") return root.tr("The disk-passphrase screen at first boot") + " · " + root.tr("A broken theme falls back to a plain text prompt")
              if (root.mainTab === "animation" && root.multimediaMissing)
                return root.tr("Video designs need qt6-multimedia") + " · " + root.tr("Settings (U) installs it")
              if (root.gridTab && root.searchText.trim().length > 0)
                return (root.designs.length === 1 ? root.tr("1 design matches “%1”").arg(root.searchText.trim())
                                                  : root.tr("%1 designs match “%2”").arg(root.designs.length).arg(root.searchText.trim()))
                  + " · " + root.tr("Esc clears")
              if (root.mainTab === "favorites") return root.tr("%1 starred with F").arg(root.designs.length)
              if (root.mainTab === "animation") return root.tr("%1 animated lock screens").arg(Designs.animations().length)
              if (root.mainTab === "editor") return root.bootEditing.length > 0 ? root.tr("Editing %1").arg(root.bootEditing) : root.tr("Make a matching lock screen and boot screen")
              return (root.mainTab === "styling" ? root.tr("%1 lock screen stylings").arg(Designs.stylings().length) + " · " : "") + root.currentThemeName + " · " + root.tr("Follows your theme")
            }
            textFormat: Text.PlainText
            color: root.wallpaperBroken ? root.danger : root.muted
            font.family: root.fontFamily
            font.pixelSize: Style.font.bodySmall
          }
        }

        Row {
          id: headerButtons
          anchors.right: parent.right
          anchors.top: parent.top
          spacing: Style.space(8)

          // Search over every design. The grid keys stay the grid's: the
          // field only takes the keyboard while it has focus (/ or a click),
          // and Enter, Down or Esc hands it back.
          Rectangle {
            id: searchBox
            visible: root.gridTab
            height: Style.space(28)
            width: Style.space(220)
            radius: root.cornerRadius
            color: Qt.rgba(root.foreground.r, root.foreground.g, root.foreground.b, root.searching ? 0.12 : 0.07)
            border.width: 1
            border.color: root.searching ? root.accent : Qt.rgba(root.foreground.r, root.foreground.g, root.foreground.b, 0.15)

            TextInput {
              id: searchInput
              anchors.left: parent.left
              anchors.right: searchHint.left
              anchors.leftMargin: Style.space(10)
              anchors.rightMargin: Style.space(6)
              anchors.verticalCenter: parent.verticalCenter
              clip: true
              text: root.searchText
              color: root.foreground
              selectionColor: root.accent
              selectedTextColor: Color.background
              font.family: root.fontFamily
              font.pixelSize: Style.font.bodySmall
              onTextEdited: root.searchText = text
              onActiveFocusChanged: root.searching = activeFocus
              Keys.onPressed: function(event) {
                if (event.key === Qt.Key_Escape) {
                  if (root.searchText.length > 0) root.searchText = ""
                  else root.leaveSearch()
                  event.accepted = true
                } else if (event.key === Qt.Key_Return || event.key === Qt.Key_Enter
                           || event.key === Qt.Key_Down || event.key === Qt.Key_Tab) {
                  root.leaveSearch()
                  event.accepted = true
                }
              }

              Text {
                anchors.verticalCenter: parent.verticalCenter
                visible: root.searchText.length === 0
                text: root.tr("Search designs")
                color: root.muted
                font: searchInput.font
              }
            }

            Text {
              id: searchHint
              anchors.right: parent.right
              anchors.rightMargin: Style.space(10)
              anchors.verticalCenter: parent.verticalCenter
              text: root.searchText.length > 0 ? "✕" : "/"
              color: searchClear.containsMouse ? root.foreground : root.muted
              font.family: root.fontFamily
              font.pixelSize: Style.font.bodySmall
              MouseArea {
                id: searchClear
                anchors.fill: parent
                anchors.margins: -Style.space(4)
                hoverEnabled: true
                onClicked: { if (root.searchText.length > 0) root.searchText = ""; else root.focusSearch() }
              }
            }

            MouseArea {
              anchors.fill: parent
              anchors.rightMargin: searchHint.width + Style.space(14)
              z: -1
              onClicked: root.focusSearch()
            }
          }

          // Avatar button: click to pick a picture with the normal file
          // dialog, the x clears it back to the user's initial.
          Rectangle {
            id: avatarButton
            height: Style.space(28)
            width: avatarRow.implicitWidth + Style.space(16)
            radius: root.cornerRadius
            color: Qt.rgba(root.foreground.r, root.foreground.g, root.foreground.b, avatarArea.containsMouse ? 0.14 : 0.07)
            border.width: 1
            border.color: Qt.rgba(root.foreground.r, root.foreground.g, root.foreground.b, 0.15)
            Behavior on color { ColorAnimation { duration: 100 } }

            Row {
              id: avatarRow
              anchors.centerIn: parent
              spacing: Style.space(8)

              Avatar {
                anchors.verticalCenter: parent.verticalCenter
                width: Style.space(20)
                source: root.avatarUrl
                initial: root.userInitial
                fontSize: Style.font.caption
                fillColor: root.accent
                textColor: Color.background
                shadow: false
              }

              Text {
                anchors.verticalCenter: parent.verticalCenter
                text: root.tr(root.hasAvatar ? "Avatar" : "Add avatar")
                color: root.foreground
                font.family: root.fontFamily
                font.pixelSize: Style.font.bodySmall
              }

              Text {
                anchors.verticalCenter: parent.verticalCenter
                visible: root.hasAvatar
                text: "✕"
                color: clearArea.containsMouse ? root.foreground : root.muted
                font.family: root.fontFamily
                font.pixelSize: Style.font.bodySmall
                MouseArea {
                  id: clearArea
                  anchors.fill: parent
                  anchors.margins: -Style.space(4)
                  hoverEnabled: true
                  onClicked: root.clearAvatar()
                }
              }
            }

            MouseArea {
              id: avatarArea
              anchors.fill: parent
              hoverEnabled: true
              z: -1
              onClicked: root.pickAvatar()
            }
          }

          Rectangle {
            anchors.verticalCenter: avatarButton.verticalCenter
            width: activeLabel.implicitWidth + Style.space(20); height: Style.space(28); radius: root.cornerRadius
            color: Qt.rgba(root.accent.r, root.accent.g, root.accent.b, 0.18)
            border.width: 1; border.color: Qt.rgba(root.accent.r, root.accent.g, root.accent.b, 0.5)
            Text {
              id: activeLabel
              anchors.centerIn: parent
              text: root.selectionError || root.tr("Active: %1").arg(Designs.byId(root.activeDesignId) ? Designs.byId(root.activeDesignId).name : root.activeDesignId)
              textFormat: Text.PlainText
              color: root.foreground
              font.family: root.fontFamily
              font.pixelSize: Style.font.bodySmall
            }
          }
        }

        // (tabs moved to the left sidebar)

        // Category chips removed in the redesign (the sidebar splits stylings
        // from animations instead).
        Row {
          visible: false
          anchors.right: parent.right
          anchors.bottom: parent.bottom
          anchors.bottomMargin: Style.space(10)
          spacing: Style.space(8)
          Repeater {
            model: root.categories
            Rectangle {
              id: chip
              required property var modelData
              readonly property bool current: modelData.id === root.category
              width: chipLabel.implicitWidth + Style.space(24)
              height: Style.space(30)
              radius: root.cornerRadius
              color: current ? root.accent : Qt.rgba(root.foreground.r, root.foreground.g, root.foreground.b, chipArea.containsMouse ? 0.12 : 0.06)
              border.width: 1
              border.color: current ? root.accent : Qt.rgba(root.foreground.r, root.foreground.g, root.foreground.b, 0.15)
              Behavior on color { ColorAnimation { duration: 100 } }
              Text {
                id: chipLabel
                anchors.centerIn: parent
                text: root.tr(chip.modelData.name)
                textFormat: Text.PlainText
                color: chip.current ? Color.background : root.foreground
                font.family: root.fontFamily
                font.pixelSize: Style.font.bodySmall
                font.weight: chip.current ? Font.DemiBold : Font.Normal
              }
              MouseArea {
                id: chipArea
                anchors.fill: parent
                hoverEnabled: true
                onClicked: root.setCategory(chip.modelData.id)
              }
            }
          }
        }

        // The two settings pages live where the grid otherwise is.
        Item {
          id: settingsPane
          visible: !root.gridTab
          anchors.top: parent.bottom
          anchors.topMargin: Style.space(6)
          anchors.left: parent.left
          anchors.leftMargin: root.sidebarW + Style.space(20)
          anchors.right: parent.right
          anchors.rightMargin: root.mainTab === "editor" ? Style.space(40) : root.rightPanelW + Style.space(40)
          // Sized against the card (footer is not a sibling, so no anchor),
          // clipped and scrollable so tall content never draws over the nav.
          height: card.height - root.headerHeight - root.footerHeight - Style.space(80)

          Flickable {
            id: settingsFlick
            anchors.fill: parent
            clip: true
            contentWidth: width
            contentHeight: settingsColumn.implicitHeight + Style.space(20)
            boundsBehavior: Flickable.StopAtBounds
            flickDeceleration: 4000

          Column {
            id: settingsColumn
            width: settingsPane.width
            spacing: Style.space(14)

            Column {
              width: Math.min(parent.width, Style.space(900))
              visible: root.mainTab === "settings"
              spacing: Style.space(18)

              // Health: only when something is missing, with the fix a click
              // away. The full check is extras/doctor.sh, under System.
              SettingSection {
                explorer: root
                visible: root.healthIssues.length > 0
                title: root.tr("Health")
                description: root.tr("Something here keeps part of the plugin from working.")

                Column {
                  width: parent.width
                  spacing: Style.space(8)

                  Repeater {
                    model: root.healthIssues
                    Rectangle {
                      id: issueRow
                      required property var modelData
                      width: parent.width
                      height: issueLine.implicitHeight + Style.space(22)
                      radius: root.cornerRadius
                      color: Qt.rgba(root.danger.r, root.danger.g, root.danger.b, 0.12)
                      border.width: 1
                      border.color: Qt.rgba(root.danger.r, root.danger.g, root.danger.b, 0.45)

                      Text {
                        id: issueLine
                        anchors.left: parent.left
                        anchors.right: installButton.visible ? installButton.left : parent.right
                        anchors.leftMargin: Style.space(14)
                        anchors.rightMargin: Style.space(14)
                        anchors.verticalCenter: parent.verticalCenter
                        text: issueRow.modelData.text
                        textFormat: Text.PlainText
                        wrapMode: Text.WordWrap
                        color: root.foreground
                        font.family: root.fontFamily
                        font.pixelSize: Style.font.bodySmall
                      }

                      Rectangle {
                        id: installButton
                        visible: issueRow.modelData.packages.length > 0 || !!issueRow.modelData.fix
                        anchors.right: parent.right
                        anchors.rightMargin: Style.space(10)
                        anchors.verticalCenter: parent.verticalCenter
                        width: installLabel.implicitWidth + Style.space(26)
                        height: Style.space(34)
                        radius: root.cornerRadius
                        color: installArea.containsMouse ? Qt.lighter(root.accent, 1.15) : root.accent
                        Text {
                          id: installLabel
                          anchors.centerIn: parent
                          text: issueRow.modelData.fix === "copies" ? root.tr(root.movingCopies ? "Moving…" : "Move it out") : root.tr("Install")
                          color: Color.background
                          font.family: root.fontFamily
                          font.pixelSize: Style.font.bodySmall
                          font.weight: Font.DemiBold
                        }
                        MouseArea {
                          id: installArea
                          anchors.fill: parent
                          hoverEnabled: true
                          cursorShape: Qt.PointingHandCursor
                          onClicked: {
                            if (issueRow.modelData.fix === "copies") root.moveCopies()
                            else root.installPackages(issueRow.modelData.packages)
                          }
                        }
                      }
                    }
                  }
                }
              }

              SettingSection {
                explorer: root
                title: root.tr("Unlock")
                description: root.tr("What happens once the password is right.")

                // The animation the lock screen leaves with.
                SettingRow {
                  explorer: root
                  label: root.tr("Animation")
                  help: root.motionReduced
                        ? root.tr("Reduce motion is on, so the lock screen leaves at once and no unlock clip plays.")
                        : (root.unlockAnimation === "none" ? "" : root.tr("The lock screen stays up while it plays."))

                  Column {
                    width: parent.width
                    spacing: Style.space(2)
                    Repeater {
                      model: root.unlockOptions
                      Rectangle {
                        id: unlockOptionRow
                        required property var modelData
                        readonly property bool current: modelData.id === root.unlockAnimation
                        width: Math.min(parent.width, Style.space(460))
                        height: Style.space(50)
                        radius: root.cornerRadius
                        color: current ? Qt.rgba(root.accent.r, root.accent.g, root.accent.b, 0.14)
                                       : Qt.rgba(root.foreground.r, root.foreground.g, root.foreground.b, unlockOptionArea.containsMouse ? 0.07 : 0.0)
                        Behavior on color { ColorAnimation { duration: 100 } }

                        Rectangle {
                          id: unlockOptionRadio
                          anchors.verticalCenter: parent.verticalCenter
                          anchors.left: parent.left
                          anchors.leftMargin: Style.space(12)
                          width: Style.space(18)
                          height: Style.space(18)
                          radius: width / 2
                          color: "transparent"
                          border.width: Math.max(1, Style.space(2))
                          border.color: unlockOptionRow.current ? root.accent : Qt.rgba(root.foreground.r, root.foreground.g, root.foreground.b, 0.4)

                          Rectangle {
                            anchors.centerIn: parent
                            width: Style.space(9)
                            height: Style.space(9)
                            radius: width / 2
                            color: root.accent
                            visible: unlockOptionRow.current
                          }
                        }

                        Column {
                          anchors.verticalCenter: parent.verticalCenter
                          anchors.left: unlockOptionRadio.right
                          anchors.leftMargin: Style.space(12)
                          spacing: 2

                          Text {
                            text: root.tr(unlockOptionRow.modelData.name)
                            color: root.foreground
                            font.family: root.fontFamily
                            font.pixelSize: Style.font.body
                            font.weight: unlockOptionRow.current ? Font.DemiBold : Font.Normal
                          }

                          Text {
                            text: root.tr(unlockOptionRow.modelData.hint)
                            color: root.muted
                            font.family: root.fontFamily
                            font.pixelSize: Style.font.bodySmall
                          }
                        }

                        MouseArea {
                          id: unlockOptionArea
                          anchors.fill: parent
                          hoverEnabled: true
                          cursorShape: Qt.PointingHandCursor
                          onClicked: root.setUnlock(unlockOptionRow.modelData.id)
                        }
                      }
                    }
                  }
                }

                SettingRow {
                  explorer: root
                  visible: root.unlockAnimation !== "none"
                  label: root.tr("Length")
                  options: root.unlockDurations.map(function(ms) { return { id: ms, name: (ms / 1000).toFixed(1) + "s" } })
                  current: root.unlockDuration
                  onPicked: function(id) { root.setUnlockDuration(id) }
                }

                SettingRow {
                  explorer: root
                  label: root.tr("Clip speed")
                  help: root.tr("How fast the clip designs and the unlock clip play.")
                  options: root.clipSpeeds.map(function(v) { return { id: v, name: v + "x" } })
                  current: {
                    for (var i = 0; i < root.clipSpeeds.length; i++)
                      if (Math.abs(root.clipSpeeds[i] - root.clipSpeed) < 0.01) return root.clipSpeeds[i]
                    return undefined
                  }
                  onPicked: function(id) { root.setClipSpeed(id) }
                }

                SettingRow {
                  explorer: root
                  label: root.tr("Video ends as wallpaper")
                  help: root.clipWallpaper
                        ? root.tr("The desktop opens on the frame the clip stopped on, set with omarchy-theme-bg-set.")
                        : root.tr("The desktop keeps its own wallpaper after a clip.")
                  options: root.onOffOptions
                  current: root.clipWallpaper ? "on" : "off"
                  onPicked: function(id) { if ((id === "on") !== root.clipWallpaper) root.toggleClipWallpaper() }
                }
              }

              SettingSection {
                explorer: root
                title: root.tr("Look")
                description: root.tr("How every design is drawn. The preview on the right follows along.")

                SettingRow {
                  explorer: root
                  label: root.tr("Clock")
                  options: root.clockFormats
                  current: root.twelveHour ? "12" : "24"
                  onPicked: function(id) { root.setTwelveHour(id === "12") }
                }

                SettingRow {
                  explorer: root
                  label: root.tr("Language")
                  help: root.tr("The language of the lock screen and of this explorer.")
                  options: root.languageChoices
                  current: root.languageSetting
                  onPicked: function(id) { root.setLanguage(id) }
                }

                SettingRow {
                  explorer: root
                  label: root.tr("Wallpaper blur")
                  options: root.wallpaperBlurChoices
                  current: root.wallpaperBlur
                  onPicked: function(id) { root.setWallpaperBlur(id) }
                }

                SettingRow {
                  explorer: root
                  label: root.tr("Wallpaper dim")
                  help: root.wallpaperBlur === "design" && root.wallpaperDim === "design"
                        ? root.tr("Each design blurs and darkens the wallpaper its own way.")
                        : root.tr("Designs drawn over a solid color or their own art are not affected.")
                  options: root.wallpaperDimChoices
                  current: root.wallpaperDim
                  onPicked: function(id) { root.setWallpaperDim(id) }
                }

                SettingRow {
                  explorer: root
                  label: root.tr("Size")
                  help: root.tr("Draws the whole lock screen larger, so text, field and avatar grow together.")
                  options: root.uiScaleChoices
                  current: root.uiScale
                  onPicked: function(id) { root.setUiScale(id) }
                }

                SettingRow {
                  explorer: root
                  label: root.tr("Reduce motion")
                  help: root.reduceMotion === "off"
                        ? root.tr("Animated designs move as they were made to.")
                        : root.tr("Designs hold still, changing only for what you type, a wrong password or the minute.")
                          + (root.reduceMotion === "battery" ? " " + root.tr(root.motionReduced ? root.tr("On battery now.") : root.tr("Moving now: on mains power.")) : "")
                  options: root.reduceMotionChoices
                  current: root.reduceMotion
                  onPicked: function(id) { root.setReduceMotion(id) }
                }
              }

              SettingSection {
                explorer: root
                title: root.tr("Password field")
                description: root.tr("What the field shows next to what you type, in the designs that use it.")

                SettingRow {
                  explorer: root
                  label: root.tr("Keyboard layout")
                  help: root.tr("The layout code, such as DK or DE, shown when it is not US or when you have more than one. Click it to switch.")
                  options: root.shownHiddenOptions
                  current: root.showLayoutBadge ? "show" : "hide"
                  onPicked: function(id) { root.setFieldItem("layout", id === "show") }
                }

                SettingRow {
                  explorer: root
                  label: root.tr("Caps lock warning")
                  help: root.tr("A CAPS badge while caps lock is on.")
                  options: root.shownHiddenOptions
                  current: root.showCapsBadge ? "show" : "hide"
                  onPicked: function(id) { root.setFieldItem("caps", id === "show") }
                }

                SettingRow {
                  explorer: root
                  label: root.tr("Show password button")
                  help: root.tr("The eye that shows what you typed. Ctrl+E does the same either way.")
                  options: root.shownHiddenOptions
                  current: root.allowPasswordToggle ? "show" : "hide"
                  onPicked: function(id) { root.setFieldItem("reveal", id === "show") }
                }

                SettingRow {
                  explorer: root
                  label: root.tr("Sign-in icons")
                  help: root.tr("The fingerprint, face and security key icons. Without them Tab still switches to the key and Enter on an empty field still starts face unlock.")
                  options: root.shownHiddenOptions
                  current: root.showAuthIcons ? "show" : "hide"
                  onPicked: function(id) { root.setFieldItem("icons", id === "show") }
                }
              }

              SettingSection {
                explorer: root
                title: root.tr("Screen and power")
                description: root.tr("How long the lock screen stays lit, and what it can do besides take a password.")

                // Never keeps it powered for the whole lock: video designs keep
                // playing and slow monitors are never re-blanked mid-wake.
                SettingRow {
                  explorer: root
                  label: root.tr("Blank the display after")
                  help: root.keepDisplayOn
                        ? root.tr("The lock screen stays lit for the whole lock: video designs keep playing.")
                        : root.tr("The lock screen stays lit, then the display powers down.")
                  options: [
                    { id: 5000, name: "5s" }, { id: 15000, name: "15s" }, { id: 30000, name: "30s" },
                    { id: 60000, name: "1m" }, { id: 300000, name: "5m" },
                    { id: -1, name: root.blankDelayIsCustom ? root.tr("Custom (%1m)").arg(Math.round(root.blankDelay / 60000)) : root.tr("Custom") },
                    { id: 0, name: root.tr("Never") }
                  ]
                  current: root.keepDisplayOn ? 0 : (root.blankDelayIsCustom ? -1 : root.blankDelay)
                  onPicked: function(id) {
                    if (id === -1) root.beginCustomDelay()
                    else root.setBlankAfter(id)
                  }

                  Rectangle {
                    visible: root.customDelayEditing
                    width: Style.space(150)
                    height: visible ? Style.space(34) : 0
                    radius: root.cornerRadius
                    color: Qt.rgba(root.foreground.r, root.foreground.g, root.foreground.b, 0.06)
                    border.width: Math.max(1, Style.space(2))
                    border.color: root.accent

                    // The unit hint lives inside the box, right-aligned, and the
                    // input reserves its width so typed digits never run under it.
                    Text {
                      anchors.verticalCenter: parent.verticalCenter
                      anchors.right: parent.right
                      anchors.rightMargin: Style.space(10)
                      text: root.tr("min, Enter")
                      color: root.muted
                      font.family: root.fontFamily
                      font.pixelSize: Style.font.bodySmall
                    }

                    TextInput {
                      id: customDelayInput
                      anchors.fill: parent
                      anchors.leftMargin: Style.space(10)
                      anchors.rightMargin: Style.space(80)
                      verticalAlignment: TextInput.AlignVCenter
                      color: root.foreground
                      font.family: root.fontFamily
                      font.pixelSize: Style.font.bodySmall
                      text: root.customDelayText
                      onTextEdited: root.customDelayText = text
                      focus: root.customDelayEditing
                      validator: IntValidator { bottom: 1; top: 60 }

                      Keys.onEscapePressed: {
                        root.customDelayEditing = false
                        keyCatcher.forceActiveFocus()
                      }
                      Keys.onReturnPressed: root.commitCustomDelay()
                    }
                  }
                }

                // A key pressed into a blanked screen only wakes it. Nothing
                // says when a panel is lit again, so this is how long the field
                // keeps ignoring keys after the wake has run.
                SettingRow {
                  explorer: root
                  visible: !root.keepDisplayOn
                  label: root.tr("Ignore keys after waking")
                  help: root.wakeGrace === 0
                        ? root.tr("Only the keys pressed before the screen wakes are dropped.")
                        : root.tr("Keys keep waking the screen without typing until the panel has had %1 to light up.")
                            .arg(root.wakeGrace % 1000 === 0 ? root.wakeGrace / 1000 + "s" : root.wakeGrace + "ms")
                  options: [{ id: 0, name: root.tr("Off") }, { id: 500, name: "0.5s" }, { id: 1000, name: "1s" }, { id: 2000, name: "2s" }]
                  current: root.wakeGrace
                  onPicked: function(id) { root.setWakeGrace(id) }
                }

                // Off by default: with it on, anyone at the machine can restart
                // it without knowing the password.
                SettingRow {
                  explorer: root
                  label: root.tr("Power buttons")
                  help: root.powerActions
                        ? root.tr("Sleep, restart and shut down sit in the corner. Each asks once more before it happens.")
                        : root.tr("The lock screen takes a password and nothing else.")
                  options: root.onOffOptions
                  current: root.powerActions ? "on" : "off"
                  onPicked: function(id) { root.setPowerActions(id === "on") }
                }
              }

              SettingSection {
                explorer: root
                title: root.tr("Sign-in and security")

                // Face unlock can look the moment the lock comes up, which
                // recognises whoever locked the screen and lets them straight
                // back in. Only shown when a face is enrolled.
                SettingRow {
                  explorer: root
                  visible: root.faceConfigured
                  label: root.tr("Face unlock starts")
                  help: root.faceStart === "always"
                        ? root.tr("The camera looks as soon as the screen locks. Locking while you sit in front of it can unlock it again.")
                        : root.faceStart === "off"
                          ? root.tr("The camera only looks when you press Enter on an empty field or click the face button.")
                          : root.tr("The camera looks when the display wakes, or when you come back to a screen that stayed lit, and on Enter or the face button. It never looks at a blanked screen.")
                  options: [{ id: "wake", name: root.tr("On wake") }, { id: "always", name: root.tr("Always") }, { id: "off", name: root.tr("On request") }]
                  current: root.faceStart
                  onPicked: function(id) { root.setFaceStart(id) }
                }

                // Only once /etc/pam.d/omarchy-lock-fido2 is in place; off sends
                // the lock screen back to the password without touching PAM, so
                // the key still works everywhere else.
                SettingRow {
                  explorer: root
                  visible: root.fido2Installed
                  label: root.tr("Security key")
                  help: root.tr("Off sends the lock screen back to the password; the key still works for sudo and the rest.")
                  options: root.fido2Options
                  current: root.fido2Enabled ? "on" : "off"
                  onPicked: function(id) { root.setFido2Enabled(id === "on") }
                }

                // Both off by default, and only with the key turned on above:
                // they follow the key, so without it they have nothing to do.
                SettingRow {
                  explorer: root
                  visible: root.fido2Installed && root.fido2Enabled
                  label: root.tr("Lock when the key is removed")
                  help: root.tr("Removing the security key locks the screen.")
                  options: root.onOffOptions
                  current: root.lockOnKeyRemoval ? "on" : "off"
                  onPicked: function(id) { root.setLockOnKeyRemoval(id === "on") }
                }

                SettingRow {
                  explorer: root
                  visible: root.fido2Installed && root.fido2Enabled
                  label: root.tr("Wake when the key is inserted")
                  help: root.tr("Inserting the security key lights a dark lock screen, ready for a touch.")
                  options: root.onOffOptions
                  current: root.wakeOnKeyInsert ? "on" : "off"
                  onPicked: function(id) { root.setWakeOnKeyInsert(id === "on") }
                }

                // Mistakes on your own way in are left out.
                SettingRow {
                  explorer: root
                  label: root.tr("Report failed attempts")
                  help: root.awayReport
                        ? root.tr("After you unlock, a notification says if somebody got it wrong while you were away.")
                        : root.tr("Failed attempts are not reported.")
                  options: root.onOffOptions
                  current: root.awayReport ? "on" : "off"
                  onPicked: function(id) { root.setAwayReport(id === "on") }
                }
              }

              SettingSection {
                explorer: root
                title: root.tr("System")

                // An entry in the app launcher and under Style in the Omarchy
                // menu. A plugin cannot add those on install, so it is a choice.
                SettingRow {
                  explorer: root
                  label: root.tr("Omarchy menu")
                  help: root.tr("An entry in the app launcher and under Style in the Omarchy menu.")
                  options: root.menuEntryOptions
                  current: root.menuEntryInstalled ? "on" : "off"
                  onPicked: function(id) { root.setMenuEntry(id === "on") }
                }

                SettingRow {
                  explorer: root
                  label: root.tr("Check this install")
                  help: root.healthIssues.length === 0
                        ? root.tr("Nothing missing that the explorer can see. The full check opens in a terminal, with a fix for anything it finds.")
                        : root.tr("Opens a terminal with every check and its fix.")

                  Rectangle {
                    width: doctorLabel.implicitWidth + Style.space(26)
                    height: Style.space(34)
                    radius: root.cornerRadius
                    color: Qt.rgba(root.foreground.r, root.foreground.g, root.foreground.b, doctorArea.containsMouse ? 0.13 : 0.06)
                    border.width: 1
                    border.color: Qt.rgba(root.foreground.r, root.foreground.g, root.foreground.b, 0.10)
                    Text {
                      id: doctorLabel
                      anchors.centerIn: parent
                      text: root.tr("Run the check")
                      color: root.foreground
                      font.family: root.fontFamily
                      font.pixelSize: Style.font.bodySmall
                    }
                    MouseArea {
                      id: doctorArea
                      anchors.fill: parent
                      hoverEnabled: true
                      cursorShape: Qt.PointingHandCursor
                      onClicked: root.runDoctor()
                    }
                  }
                }
              }
            }

            Column {
              // Sized to the pane, not to the widest child: children bind to
              // parent.width, so an unset width here balloons to the longest
              // unwrapped text and pushes the Apply button under the preview.
              width: parent.width
              visible: root.mainTab === "boot" || root.mainTab === "editor"
              spacing: Style.space(14)

              Text {
                visible: root.mainTab === "boot"
                width: parent.width
                wrapMode: Text.WordWrap
                text: root.tr("Now: %1").arg(root.bootNowName) + (root.bootAppliedTheme.length > 0 ? " \u00b7 " + root.tr("Baked from %1").arg(root.bootAppliedTheme) : "")
                textFormat: Text.PlainText
                color: root.muted
                font.family: root.fontFamily
                font.pixelSize: Style.font.bodySmall
              }

              // Apply banner: nothing is built until you press Apply.
              Rectangle {
                visible: root.mainTab === "boot" && (root.bootDirty || root.bootApplying)
                width: parent.width
                height: applyBannerRow.implicitHeight + Style.space(20)
                color: Qt.rgba(root.accent.r, root.accent.g, root.accent.b, 0.10)
                border.width: 1
                border.color: Qt.rgba(root.accent.r, root.accent.g, root.accent.b, 0.4)

                Row {
                  id: applyBannerRow
                  anchors.left: parent.left
                  anchors.right: parent.right
                  anchors.verticalCenter: parent.verticalCenter
                  anchors.leftMargin: Style.space(14)
                  anchors.rightMargin: Style.space(14)
                  spacing: Style.space(14)

                  Rectangle {
                    anchors.verticalCenter: parent.verticalCenter
                    width: Style.space(8); height: Style.space(8); radius: width / 2
                    color: root.accent
                  }

                  Text {
                    anchors.verticalCenter: parent.verticalCenter
                    width: parent.width - applyBtn.width - Style.space(50)
                    wrapMode: Text.WordWrap
                    text: root.bootApplying
                      ? root.tr("Applying the boot theme\u2026")
                      : root.tr("Set to %1. Applying writes the boot theme to the EFI partition and asks for your password.").arg(root.bootDesiredName)
                    textFormat: Text.PlainText
                    color: Color.menu.text
                    font.family: root.fontFamily
                    font.pixelSize: Style.font.caption
                  }

                  Rectangle {
                    id: applyBtn
                    anchors.verticalCenter: parent.verticalCenter
                    width: applyBtnLabel.implicitWidth + Style.space(24)
                    height: Style.space(30)
                    radius: root.cornerRadius
                    opacity: root.bootApplying ? 0.5 : 1
                    color: root.accent
                    Text {
                      id: applyBtnLabel
                      anchors.centerIn: parent
                      text: root.bootApplying ? root.tr("Building\u2026") : root.tr("Apply")
                      color: Color.background
                      font.family: root.fontFamily
                      font.pixelSize: Style.font.bodySmall
                      font.weight: Font.DemiBold
                    }
                    MouseArea {
                      anchors.fill: parent
                      enabled: !root.bootApplying
                      onClicked: root.applyPendingBoot()
                    }
                  }
                }
              }

              Row {
                visible: root.mainTab === "boot"
                spacing: Style.space(20)

                Rectangle {
                  width: followRow.implicitWidth + Style.space(8)
                  height: Style.space(30)
                  color: "transparent"

                  Row {
                    id: followRow
                    anchors.verticalCenter: parent.verticalCenter
                    spacing: Style.space(8)

                    Rectangle {
                      anchors.verticalCenter: parent.verticalCenter
                      width: Style.space(18)
                      height: Style.space(18)
                      radius: root.cornerRadius
                      color: root.bootSetting === "follow" ? root.accent : "transparent"
                      border.width: Math.max(1, Style.space(2))
                      border.color: root.bootSetting === "follow" ? root.accent : Qt.rgba(root.foreground.r, root.foreground.g, root.foreground.b, 0.4)

                      Text {
                        anchors.centerIn: parent
                        visible: root.bootSetting === "follow"
                        text: "\u2713"
                        color: Color.background
                        font.pixelSize: Style.font.caption
                        font.weight: Font.Bold
                      }
                    }

                    Column {
                      anchors.verticalCenter: parent.verticalCenter
                      spacing: 0

                      Text {
                        text: root.tr("Follow my lock screen")
                        color: root.foreground
                        font.family: root.fontFamily
                        font.pixelSize: Style.font.caption
                      }

                      Text {
                        text: root.followHint
                        textFormat: Text.PlainText
                        color: root.muted
                        font.family: root.fontFamily
                        font.pixelSize: Style.font.caption
                      }
                    }
                  }

                  MouseArea {
                    anchors.fill: parent
                    anchors.margins: -Style.space(4)
                    onClicked: root.toggleFollow()
                  }
                }

                Rectangle {
                  width: resyncRow.implicitWidth + Style.space(8)
                  height: Style.space(30)
                  color: "transparent"

                  Row {
                    id: resyncRow
                    anchors.verticalCenter: parent.verticalCenter
                    spacing: Style.space(8)

                    Rectangle {
                      anchors.verticalCenter: parent.verticalCenter
                      width: Style.space(18)
                      height: Style.space(18)
                      radius: root.cornerRadius
                      color: root.bootResync ? root.accent : "transparent"
                      border.width: Math.max(1, Style.space(2))
                      border.color: root.bootResync ? root.accent : Qt.rgba(root.foreground.r, root.foreground.g, root.foreground.b, 0.4)

                      Text {
                        anchors.centerIn: parent
                        visible: root.bootResync
                        text: "\u2713"
                        color: Color.background
                        font.pixelSize: Style.font.caption
                        font.weight: Font.Bold
                      }
                    }

                    Text {
                      anchors.verticalCenter: parent.verticalCenter
                      text: root.tr("Re-apply when the Omarchy theme changes")
                      color: root.foreground
                      font.family: root.fontFamily
                      font.pixelSize: Style.font.caption
                    }
                  }

                  MouseArea {
                    anchors.fill: parent
                    anchors.margins: -Style.space(4)
                    onClicked: root.toggleBootResync()
                  }
                }

                Rectangle {
                  // Rotation ships hidden in 1.5.0: enabling it installs a
                  // passwordless-root helper (rotate-setup.sh) that has not
                  // been tested end to end. Flip visible when that lands.
                  visible: false
                  width: rotateRow.implicitWidth + Style.space(8)
                  height: Style.space(30)
                  color: "transparent"

                  Row {
                    id: rotateRow
                    anchors.verticalCenter: parent.verticalCenter
                    spacing: Style.space(8)

                    Rectangle {
                      anchors.verticalCenter: parent.verticalCenter
                      width: Style.space(18)
                      height: Style.space(18)
                      radius: root.cornerRadius
                      color: root.bootRotating ? root.accent : "transparent"
                      border.width: Math.max(1, Style.space(2))
                      border.color: root.bootRotating ? root.accent : Qt.rgba(root.foreground.r, root.foreground.g, root.foreground.b, 0.4)

                      Text {
                        anchors.centerIn: parent
                        visible: root.bootRotating
                        text: "\u2713"
                        color: Color.background
                        font.pixelSize: Style.font.caption
                        font.weight: Font.Bold
                      }
                    }

                    Column {
                      anchors.verticalCenter: parent.verticalCenter
                      spacing: 0

                      Text {
                        text: root.tr("Rotate boot screens")
                        color: root.foreground
                        font.family: root.fontFamily
                        font.pixelSize: Style.font.caption
                      }

                      Text {
                        // The toggles row can meet the preview panel; give in
                        // gracefully instead of drawing under it.
                        width: Math.min(implicitWidth, Style.space(230))
                        elide: Text.ElideRight
                        text: root.bootRotating
                          ? root.tr("Tick the cards below") + " \u00b7 " + root.tr("advances one per boot (%1 picked)").arg(root.bootRotation.length)
                          : root.tr("A different one each boot, set up once")
                        color: root.muted
                        font.family: root.fontFamily
                        font.pixelSize: Style.font.caption
                      }
                    }
                  }

                  MouseArea {
                    anchors.fill: parent
                    anchors.margins: -Style.space(4)
                    onClicked: root.toggleRotationMode()
                  }
                }
              }

              Row {
                visible: root.mainTab === "boot"
                spacing: Style.space(6)

                  Text {
                    anchors.verticalCenter: parent.verticalCenter
                    text: root.tr("Clip length")
                    color: root.muted
                    font.family: root.fontFamily
                    font.pixelSize: Style.font.caption
                  }

                  Repeater {
                    model: [0, 2, 4, 6]
                    Rectangle {
                      id: clipLen
                      required property int modelData
                      readonly property bool current: modelData === root.bootClipSeconds
                      width: clipLenLabel.implicitWidth + Style.space(16)
                      height: Style.space(24)
                      radius: root.cornerRadius
                      color: current ? root.accent : Qt.rgba(root.foreground.r, root.foreground.g, root.foreground.b, clipLenArea.containsMouse ? 0.12 : 0.06)
                      Behavior on color { ColorAnimation { duration: 100 } }

                      Text {
                        id: clipLenLabel
                        anchors.centerIn: parent
                        text: clipLen.modelData === 0 ? root.tr("Full") : clipLen.modelData + "s"
                        color: clipLen.current ? Color.background : root.foreground
                        font.family: root.fontFamily
                        font.pixelSize: Style.font.caption
                        font.weight: clipLen.current ? Font.DemiBold : Font.Normal
                      }

                      MouseArea {
                        id: clipLenArea
                        anchors.fill: parent
                        hoverEnabled: true
                        onClicked: root.setBootClipSeconds(clipLen.modelData)
                      }
                    }
                  }
                }

              Flow {
                visible: root.mainTab === "boot"
                width: card.width - root.sidebarW - root.rightPanelW - Style.space(120)
                spacing: Style.space(14)

                Repeater {
                  model: root.bootCards
                  Column {
                    id: bootCard
                    required property var modelData
                    readonly property bool picked: root.bootSetting === modelData.id || root.bootFollowTarget === modelData.id
                    readonly property bool onDisk: root.bootApplied === modelData.id || (modelData.id === "stock" && root.bootApplied.length === 0)
                    readonly property bool editable: modelData.id.indexOf("custom:") === 0
                    spacing: Style.space(6)
                    opacity: root.bootApplying ? 0.55 : 1

                    Rectangle {
                      width: Style.space(252)
                      height: Style.space(142)
                      radius: root.cornerRadius
                      color: root.shade(0.3)
                      border.width: bootCard.picked ? Math.max(2, Style.space(3)) : 1
                      border.color: bootCard.picked ? root.accent
                                  : Qt.rgba(root.foreground.r, root.foreground.g, root.foreground.b, bootCardArea.containsMouse ? 0.4 : 0.15)
                      clip: true
                      Behavior on border.color { ColorAnimation { duration: 100 } }

                      Text {
                        anchors.centerIn: parent
                        text: root.tr("rendering preview...")
                        color: root.muted
                        font.family: root.fontFamily
                        font.pixelSize: Style.font.caption
                      }

                      Image {
                        anchors.fill: parent
                        anchors.margins: 1
                        source: root.bootCardPreview(bootCard.modelData.id)
                        fillMode: Image.PreserveAspectCrop
                        asynchronous: true
                        cache: false
                      }

                      Rectangle {
                        visible: bootCard.onDisk && !root.bootRotating
                        anchors.top: parent.top
                        anchors.right: parent.right
                        anchors.margins: Style.space(8)
                        width: onDiskLabel.implicitWidth + Style.space(14)
                        height: Style.space(24)
                        radius: root.cornerRadius
                        color: root.accent

                        Text {
                          id: onDiskLabel
                          anchors.centerIn: parent
                          text: "\u2713 " + root.tr("Applied")
                          color: Color.background
                          font.family: root.fontFamily
                          font.pixelSize: Style.font.caption
                          font.weight: Font.DemiBold
                        }
                      }

                      MouseArea {
                        id: bootCardArea
                        anchors.fill: parent
                        hoverEnabled: true
                        onClicked: root.bootRotating
                          ? (bootCard.modelData.id !== "stock" ? root.toggleInRotation(bootCard.modelData.id) : undefined)
                          : root.setBoot(bootCard.modelData.id)
                      }

                      // Rotation membership tick, shown while rotating.
                      Rectangle {
                        visible: root.bootRotating && bootCard.modelData.id !== "stock"
                        anchors.top: parent.top
                        anchors.left: parent.left
                        anchors.margins: Style.space(8)
                        width: Style.space(26)
                        height: Style.space(26)
                        radius: root.cornerRadius
                        color: root.inRotation(bootCard.modelData.id) ? root.accent : root.shade(0.55)
                        border.width: 1
                        border.color: root.inRotation(bootCard.modelData.id) ? root.accent : Qt.rgba(root.foreground.r, root.foreground.g, root.foreground.b, 0.4)

                        Text {
                          anchors.centerIn: parent
                          text: root.inRotation(bootCard.modelData.id) ? "\u2713" : "+"
                          color: root.inRotation(bootCard.modelData.id) ? Color.background : root.foreground
                          font.family: root.fontFamily
                          font.pixelSize: Style.font.bodySmall
                          font.weight: Font.Bold
                        }
                      }

                      Rectangle {
                        visible: bootCard.editable
                        anchors.bottom: parent.bottom
                        anchors.right: parent.right
                        anchors.margins: Style.space(8)
                        width: bootEditLabel.implicitWidth + Style.space(14)
                        height: Style.space(24)
                        radius: root.cornerRadius
                        color: root.shade(bootEditArea.containsMouse ? 0.8 : 0.55)
                        border.width: 1
                        border.color: Qt.rgba(root.foreground.r, root.foreground.g, root.foreground.b, 0.3)

                        Text {
                          id: bootEditLabel
                          anchors.centerIn: parent
                          text: root.tr("Edit")
                          color: root.foreground
                          font.family: root.fontFamily
                          font.pixelSize: Style.font.caption
                        }

                        MouseArea {
                          id: bootEditArea
                          anchors.fill: parent
                          hoverEnabled: true
                          onClicked: root.openBootEditor(bootCard.modelData.id.substring(7))
                        }
                      }

                      // Your own videos and layouts can be deleted; press twice.
                      Rectangle {
                        visible: (bootCard.modelData.id.indexOf("video:") === 0 || bootCard.editable) && !root.bootRotating
                        anchors.bottom: parent.bottom
                        anchors.left: parent.left
                        anchors.margins: Style.space(8)
                        width: bootDelLabel.implicitWidth + Style.space(14)
                        height: Style.space(24)
                        radius: root.cornerRadius
                        color: root.confirmingDelete === bootCard.modelData.id ? root.danger : root.shade(bootDelArea.containsMouse ? 0.8 : 0.55)
                        border.width: 1
                        border.color: root.confirmingDelete === bootCard.modelData.id ? Qt.lighter(root.danger, 1.3) : Qt.rgba(root.foreground.r, root.foreground.g, root.foreground.b, 0.3)

                        Text {
                          id: bootDelLabel
                          anchors.centerIn: parent
                          text: root.tr(root.confirmingDelete === bootCard.modelData.id ? "Sure?" : "Delete")
                          color: root.confirmingDelete === bootCard.modelData.id ? Color.background : root.foreground
                          font.family: root.fontFamily
                          font.pixelSize: Style.font.caption
                        }

                        MouseArea {
                          id: bootDelArea
                          anchors.fill: parent
                          hoverEnabled: true
                          onClicked: root.deleteBootCard(bootCard.modelData.id)
                        }
                      }
                    }

                    Row {
                      spacing: Style.space(8)

                      Text {
                        text: bootCard.modelData.name
                        textFormat: Text.PlainText
                        color: root.foreground
                        font.family: root.fontFamily
                        font.pixelSize: Style.font.bodySmall
                        font.weight: bootCard.picked ? Font.DemiBold : Font.Normal
                      }

                      Text {
                        anchors.verticalCenter: parent.verticalCenter
                        text: bootCard.modelData.kind
                        textFormat: Text.PlainText
                        color: Qt.rgba(root.accent.r, root.accent.g, root.accent.b, 0.9)
                        font.family: root.fontFamily
                        font.pixelSize: Style.font.caption
                      }
                    }
                  }
                }

                // Snapshot the current lock screen as a static boot background.
                Column {
                  spacing: Style.space(6)

                  Rectangle {
                    width: Style.space(252)
                    height: Style.space(142)
                    radius: root.cornerRadius
                    color: Qt.rgba(root.accent.r, root.accent.g, root.accent.b, snapshotCardArea.containsMouse ? 0.16 : 0.08)
                    border.width: 1
                    border.color: Qt.rgba(root.accent.r, root.accent.g, root.accent.b, 0.5)
                    Behavior on color { ColorAnimation { duration: 100 } }

                    Column {
                      anchors.centerIn: parent
                      spacing: Style.space(4)
                      width: parent.width - Style.space(24)

                      Text {
                        anchors.horizontalCenter: parent.horizontalCenter
                        text: "+"
                        color: root.accent
                        font.family: root.fontFamily
                        font.pixelSize: Style.font.heading
                      }
                      Text {
                        width: parent.width
                        horizontalAlignment: Text.AlignHCenter
                        wrapMode: Text.WordWrap
                        text: root.tr("Snapshot this lock screen")
                        color: root.foreground
                        font.family: root.fontFamily
                        font.pixelSize: Style.font.caption
                      }
                    }

                    MouseArea {
                      id: snapshotCardArea
                      anchors.fill: parent
                      hoverEnabled: true
                      onClicked: root.snapshotActiveDesign()
                    }
                  }

                  Text {
                    text: root.tr("%1 as a still").arg(Designs.byId(root.activeDesignId) ? Designs.byId(root.activeDesignId).name : root.tr("current"))
                    textFormat: Text.PlainText
                    color: root.muted
                    font.family: root.fontFamily
                    font.pixelSize: Style.font.caption
                  }
                }

              }

              // Editor tab, gallery view: existing custom layouts to edit,
              // plus a card to start a new one.
              Flow {
                visible: root.mainTab === "editor" && root.bootEditing.length === 0
                width: card.width - root.sidebarW - root.rightPanelW - Style.space(120)
                spacing: Style.space(14)

                Repeater {
                  model: root.bootCustomDesigns
                  Column {
                    id: editorCard
                    required property var modelData
                    spacing: Style.space(6)

                    Rectangle {
                      width: Style.space(252)
                      height: Style.space(142)
                      radius: root.cornerRadius
                      color: root.shade(0.3)
                      border.width: 1
                      border.color: Qt.rgba(root.foreground.r, root.foreground.g, root.foreground.b, editorCardArea.containsMouse ? 0.4 : 0.15)
                      clip: true
                      Behavior on border.color { ColorAnimation { duration: 100 } }

                      Image {
                        anchors.fill: parent
                        anchors.margins: 1
                        source: root.bootCardPreview("custom:" + editorCard.modelData)
                        fillMode: Image.PreserveAspectCrop
                        asynchronous: true
                        cache: false
                      }

                      MouseArea {
                        id: editorCardArea
                        anchors.fill: parent
                        hoverEnabled: true
                        onClicked: root.openBootEditor(editorCard.modelData)
                      }
                    }

                    Text {
                      text: editorCard.modelData
                      textFormat: Text.PlainText
                      color: root.foreground
                      font.family: root.fontFamily
                      font.pixelSize: Style.font.bodySmall
                    }
                  }
                }

                Column {
                  spacing: Style.space(6)

                  Rectangle {
                    width: Style.space(252)
                    height: Style.space(142)
                    radius: root.cornerRadius
                    color: Qt.rgba(root.foreground.r, root.foreground.g, root.foreground.b, newBootArea.containsMouse ? 0.10 : 0.04)
                    border.width: 1
                    border.color: Qt.rgba(root.foreground.r, root.foreground.g, root.foreground.b, 0.25)
                    Behavior on color { ColorAnimation { duration: 100 } }

                    Column {
                      anchors.centerIn: parent
                      spacing: Style.space(4)

                      Text {
                        anchors.horizontalCenter: parent.horizontalCenter
                        text: "+"
                        color: root.muted
                        font.family: root.fontFamily
                        font.pixelSize: Style.font.display
                      }

                      Text {
                        anchors.horizontalCenter: parent.horizontalCenter
                        text: root.tr("New layout")
                        color: root.muted
                        font.family: root.fontFamily
                        font.pixelSize: Style.font.caption
                      }
                    }

                    MouseArea {
                      id: newBootArea
                      anchors.fill: parent
                      hoverEnabled: true
                      onClicked: root.newBootDesign()
                    }
                  }

                  Text {
                    text: root.tr("One layout, both screens")
                    color: root.muted
                    font.family: root.fontFamily
                    font.pixelSize: Style.font.caption
                  }
                }
              }

              // Unified layout editor: fields on the left, the matching lock
              // and boot previews on the right. Changes save and re-render.
              Row {
                visible: root.mainTab === "editor" && root.bootEditing.length > 0
                spacing: Style.space(24)

                Column {
                  width: Style.space(360)
                  spacing: Style.space(12)

                  Text {
                    text: root.bootEditing
                    textFormat: Text.PlainText
                    color: root.foreground
                    font.family: root.fontFamily
                    font.pixelSize: Style.font.body
                    font.weight: Font.DemiBold
                  }

                  BootField {
                    label: root.tr("Background")
                    control: "dropdown"
                    rev: root.bootFormRev
                    onEscaped: { keyCatcher.forceActiveFocus(); root.handleEscape() }
                    value: root.bootFormGet("background", "theme")
                    optionNames: root.bootOptionNames
                    options: ["theme", "wallpaper"]
                    onSelected: function(o) { root.bootFormSet("background", o) }
                  }
                  BootField {
                    label: root.tr("Logo")
                    control: "dropdown"
                    rev: root.bootFormRev
                    onEscaped: { keyCatcher.forceActiveFocus(); root.handleEscape() }
                    value: root.bootFormGet("logo", "theme")
                    optionNames: root.bootOptionNames
                    options: ["theme", "none"]
                    onSelected: function(o) { root.bootFormSet("logo", o) }
                  }
                  BootField {
                    label: root.tr("Title")
                    control: "text"
                    rev: root.bootFormRev
                    onEscaped: { keyCatcher.forceActiveFocus(); root.handleEscape() }
                    value: root.bootFormGet("title", "")
                    onEdited: function(t) { root.bootFormSet("title", t) }
                  }
                  BootField {
                    label: root.tr("Subtitle")
                    control: "text"
                    rev: root.bootFormRev
                    onEscaped: { keyCatcher.forceActiveFocus(); root.handleEscape() }
                    value: root.bootFormGet("subtitle", "")
                    onEdited: function(t) { root.bootFormSet("subtitle", t) }
                  }
                  BootField {
                    label: root.tr("Clock (lock screen)")
                    control: "toggle"
                    rev: root.bootFormRev
                    onEscaped: { keyCatcher.forceActiveFocus(); root.handleEscape() }
                    on: root.bootFormGet("clock", "on") === "on"
                    onToggled: root.bootFormSet("clock", root.bootFormGet("clock", "on") === "on" ? "off" : "on")
                  }
                  BootField {
                    label: root.tr("Passphrase field")
                    control: "dropdown"
                    rev: root.bootFormRev
                    onEscaped: { keyCatcher.forceActiveFocus(); root.handleEscape() }
                    value: root.bootFormGet("entry", "pill")
                    optionNames: root.bootOptionNames
                    options: ["pill", "line", "none"]
                    onSelected: function(o) { root.bootFormSet("entry", o) }
                  }
                  BootField {
                    label: root.tr("Scanlines")
                    control: "toggle"
                    rev: root.bootFormRev
                    onEscaped: { keyCatcher.forceActiveFocus(); root.handleEscape() }
                    on: root.bootFormGet("scanlines", "off") === "on"
                    onToggled: root.bootFormSet("scanlines", root.bootFormGet("scanlines", "off") === "on" ? "off" : "on")
                  }
                  BootField {
                    label: root.tr("Title position")
                    control: "stepper"
                    rev: root.bootFormRev
                    onEscaped: { keyCatcher.forceActiveFocus(); root.handleEscape() }
                    value: root.bootFormGet("title_y", "18")
                    onStep: function(d) { root.bootFormSet("title_y", Math.max(0, Math.min(100, (parseInt(root.bootFormGet("title_y", "18")) || 18) + d * 4))) }
                  }
                  BootField {
                    label: root.tr("Title size")
                    control: "stepper"
                    suffix: ""
                    rev: root.bootFormRev
                    onEscaped: root.handleEscape()
                    value: root.bootFormGet("title_size", "26")
                    onStep: function(d) { root.bootFormSet("title_size", Math.max(10, Math.min(64, (parseInt(root.bootFormGet("title_size", "26")) || 26) + d * 2))) }
                  }
                  BootField {
                    label: root.tr("Subtitle position")
                    control: "stepper"
                    rev: root.bootFormRev
                    onEscaped: { keyCatcher.forceActiveFocus(); root.handleEscape() }
                    value: root.bootFormGet("subtitle_y", "26")
                    onStep: function(d) { root.bootFormSet("subtitle_y", Math.max(0, Math.min(100, (parseInt(root.bootFormGet("subtitle_y", "26")) || 26) + d * 4))) }
                  }
                  BootField {
                    label: root.tr("Subtitle size")
                    control: "stepper"
                    suffix: ""
                    rev: root.bootFormRev
                    onEscaped: { keyCatcher.forceActiveFocus(); root.handleEscape() }
                    value: root.bootFormGet("subtitle_size", "15")
                    onStep: function(d) { root.bootFormSet("subtitle_size", Math.max(8, Math.min(40, (parseInt(root.bootFormGet("subtitle_size", "15")) || 15) + d * 1))) }
                  }
                  BootField {
                    label: root.tr("Field position")
                    control: "stepper"
                    rev: root.bootFormRev
                    onEscaped: { keyCatcher.forceActiveFocus(); root.handleEscape() }
                    value: root.bootFormGet("entry_y", "72")
                    onStep: function(d) { root.bootFormSet("entry_y", Math.max(0, Math.min(100, (parseInt(root.bootFormGet("entry_y", "72")) || 72) + d * 4))) }
                  }
                }

                Column {
                  spacing: Style.space(14)

                  // Both previews on one row so neither hides below the fold.
                  Row {
                    spacing: Style.space(14)

                    Column {
                      spacing: Style.space(6)
                      Text {
                        text: root.tr("Lock screen")
                        color: root.foreground
                        font.family: root.fontFamily
                        font.pixelSize: Style.font.bodySmall
                        font.weight: Font.DemiBold
                      }
                      Rectangle {
                        id: edLockRect
                        width: Math.floor((settingsColumn.width - Style.space(360) - Style.space(24) - Style.space(14)) / 2)
                        height: Math.round(width * 9 / 16)
                        radius: root.cornerRadius
                        color: root.shade(0.3)
                        border.width: 1
                        border.color: Qt.rgba(root.foreground.r, root.foreground.g, root.foreground.b, 0.2)
                        clip: true
                        Text {
                          anchors.centerIn: parent
                          visible: editorLockPreview.status !== Image.Ready
                          text: root.tr("rendering preview...")
                          color: root.muted
                          font.family: root.fontFamily
                          font.pixelSize: Style.font.caption
                        }
                        Rectangle {
                          visible: root.bootEditBusy
                          z: 2
                          anchors.right: parent.right
                          anchors.bottom: parent.bottom
                          anchors.margins: Style.space(8)
                          width: busyLabel1.implicitWidth + Style.space(14)
                          height: Style.space(22)
                          radius: root.cornerRadius
                          color: root.shade(0.6)
                          Text {
                            id: busyLabel1
                            anchors.centerIn: parent
                            text: root.tr("re-rendering…")
                            color: root.foreground
                            font.family: root.fontFamily
                            font.pixelSize: Style.font.caption
                            SequentialAnimation on opacity {
                              running: root.bootEditBusy
                              loops: Animation.Infinite
                              NumberAnimation { from: 1; to: 0.35; duration: 600 }
                              NumberAnimation { from: 0.35; to: 1; duration: 600 }
                            }
                          }
                        }
                        Image {
                          id: editorLockPreview
                          anchors.fill: parent; anchors.margins: 1
                          source: "file://" + Quickshell.env("HOME") + "/.local/state/omarchy/lock-explorer-boot-previews/custom-" + root.bootEditing + "-lock-" + root.bootCurrentTheme + ".png?v=" + root.bootPreviewsVersion
                          fillMode: Image.PreserveAspectCrop
                          asynchronous: true
                          cache: false
                        }
                      }
                    }

                    Column {
                      spacing: Style.space(6)
                      Text {
                        text: root.tr("Boot screen")
                        color: root.foreground
                        font.family: root.fontFamily
                        font.pixelSize: Style.font.bodySmall
                        font.weight: Font.DemiBold
                      }
                      Rectangle {
                        width: edLockRect.width
                        height: edLockRect.height
                        radius: root.cornerRadius
                        color: root.shade(0.3)
                        border.width: 1
                        border.color: Qt.rgba(root.foreground.r, root.foreground.g, root.foreground.b, 0.2)
                        clip: true
                        Text {
                          anchors.centerIn: parent
                          visible: editorBootPreview.status !== Image.Ready
                          text: root.tr("rendering preview...")
                          color: root.muted
                          font.family: root.fontFamily
                          font.pixelSize: Style.font.caption
                        }
                        Rectangle {
                          visible: root.bootEditBusy
                          z: 2
                          anchors.right: parent.right
                          anchors.bottom: parent.bottom
                          anchors.margins: Style.space(8)
                          width: busyLabel2.implicitWidth + Style.space(14)
                          height: Style.space(22)
                          radius: root.cornerRadius
                          color: root.shade(0.6)
                          Text {
                            id: busyLabel2
                            anchors.centerIn: parent
                            text: root.tr("re-rendering…")
                            color: root.foreground
                            font.family: root.fontFamily
                            font.pixelSize: Style.font.caption
                            SequentialAnimation on opacity {
                              running: root.bootEditBusy
                              loops: Animation.Infinite
                              NumberAnimation { from: 1; to: 0.35; duration: 600 }
                              NumberAnimation { from: 0.35; to: 1; duration: 600 }
                            }
                          }
                        }
                        Image {
                          id: editorBootPreview
                          anchors.fill: parent; anchors.margins: 1
                          source: root.bootCardPreview("custom:" + root.bootEditing)
                          fillMode: Image.PreserveAspectCrop
                          asynchronous: true
                          cache: false
                        }
                      }
                    }
                  }

                  Text {
                    width: edLockRect.width * 2 + Style.space(14)
                    wrapMode: Text.WordWrap
                    text: root.tr("Changes save and re-render automatically") + " \u00b7 " + root.tr("Esc goes back") + " \u00b7 "
                      + root.tr("apply the boot screen from its card, pick the lock screen under Styling or Animation. $USER and $HOST expand.")
                    color: root.muted
                    font.family: root.fontFamily
                    font.pixelSize: Style.font.caption
                  }
                }
              }
            }
          }
          }
        }
      }

      // Left nav sidebar (redesign): sections as a vertical list with a
      // border-left accent, counts on the right.
      Column {
        id: sidebar
        anchors.top: header.bottom
        anchors.bottom: footer.top
        anchors.left: parent.left
        anchors.leftMargin: card.contentLeftInset
        anchors.topMargin: Style.space(4)
        anchors.bottomMargin: Style.space(8)
        width: root.sidebarW
        spacing: Style.space(2)

        Repeater {
          model: {
            var r = root.service ? root.service.designsRevision : 0
            return [
              { id: "styling", name: "Styling", count: Designs.stylings().length },
              { id: "animation", name: "Animation", count: Designs.animations().length },
              { id: "favorites", name: "Favorites", count: root.favoriteDesigns().length },
              { id: "boot", name: "Boot screen", count: 0 },
              { id: "settings", name: "Settings", count: 0 }
            ]
          }
          Rectangle {
            id: navItem
            required property var modelData
            readonly property bool current: modelData.id === root.mainTab
            width: root.sidebarW
            height: Style.space(36)
            color: navItem.current ? Qt.rgba(root.foreground.r, root.foreground.g, root.foreground.b, 0.08)
                   : Qt.rgba(root.foreground.r, root.foreground.g, root.foreground.b, navItemArea.containsMouse ? 0.05 : 0.0)
            Behavior on color { ColorAnimation { duration: 100 } }

            Rectangle {
              anchors.left: parent.left
              anchors.top: parent.top
              anchors.bottom: parent.bottom
              width: Math.max(2, Style.space(2))
              color: navItem.current ? root.accent : "transparent"
            }

            Text {
              anchors.left: parent.left
              anchors.leftMargin: Style.space(12)
              anchors.verticalCenter: parent.verticalCenter
              text: (root.tr(navItem.modelData.name) + (navItem.modelData.id === "boot" && root.bootApplying ? " ·" : "")).toUpperCase()
              color: navItem.current ? Color.menu.text : root.muted
              font.family: root.fontFamily
              font.pixelSize: Style.font.bodySmall
              font.weight: navItem.current ? Font.Bold : Font.Normal
              font.letterSpacing: 1
            }

            Text {
              anchors.right: parent.right
              anchors.rightMargin: Style.space(12)
              anchors.verticalCenter: parent.verticalCenter
              visible: navItem.modelData.count > 0
              text: navItem.modelData.count
              color: Qt.rgba(root.foreground.r, root.foreground.g, root.foreground.b, 0.45)
              font.family: root.fontFamily
              font.pixelSize: Style.font.caption
            }

            // Pending dot when the boot screen has an unapplied change.
            Rectangle {
              anchors.right: parent.right
              anchors.rightMargin: Style.space(12)
              anchors.verticalCenter: parent.verticalCenter
              visible: navItem.modelData.id === "boot" && root.bootApplying
              width: Style.space(7); height: Style.space(7); radius: width / 2
              color: root.accent
            }

            MouseArea {
              id: navItemArea
              anchors.fill: parent
              hoverEnabled: true
              onClicked: root.mainTab = navItem.modelData.id
            }
          }
        }
      }

      // "+ New design" at the top of the three: the visual designer, where a
      // lock screen is put together by dragging pieces onto the screen.
      Rectangle {
        id: newDesignBtn
        anchors.left: parent.left
        anchors.leftMargin: card.contentLeftInset
        anchors.bottom: newClipBtn.top
        anchors.bottomMargin: Style.space(8)
        width: root.sidebarW
        height: Style.space(34)
        color: Qt.rgba(root.accent.r, root.accent.g, root.accent.b, newDesignArea.containsMouse ? 0.28 : 0.14)
        border.width: 1
        border.color: Qt.rgba(root.accent.r, root.accent.g, root.accent.b, 0.6)
        Behavior on color { ColorAnimation { duration: 100 } }

        Text {
          anchors.centerIn: parent
          text: "+ " + root.tr("New design")
          color: root.foreground
          font.family: root.fontFamily
          font.pixelSize: Style.font.bodySmall
          font.weight: Font.DemiBold
        }

        MouseArea {
          id: newDesignArea
          anchors.fill: parent
          hoverEnabled: true
          onClicked: root.newDesignerDesign()
        }
      }

      // "+ New clip" above it: your own video as an unlock clip design.
      Rectangle {
        id: newClipBtn
        anchors.left: parent.left
        anchors.leftMargin: card.contentLeftInset
        anchors.bottom: newStylingBtn.top
        anchors.bottomMargin: Style.space(8)
        width: root.sidebarW
        height: Style.space(34)
        color: Qt.rgba(root.foreground.r, root.foreground.g, root.foreground.b, newClipArea.containsMouse ? 0.08 : 0.0)
        border.width: 1
        border.color: Qt.rgba(root.foreground.r, root.foreground.g, root.foreground.b, 0.3)
        Behavior on color { ColorAnimation { duration: 100 } }

        Text {
          anchors.centerIn: parent
          text: "+ " + root.tr("New clip")
          color: newClipArea.containsMouse ? Color.menu.text : root.muted
          font.family: root.fontFamily
          font.pixelSize: Style.font.bodySmall
        }

        MouseArea {
          id: newClipArea
          anchors.fill: parent
          hoverEnabled: true
          onClicked: root.newClipDesign()
        }
      }

      // "+ New styling" pinned to the bottom of the sidebar.
      Rectangle {
        id: newStylingBtn
        anchors.left: parent.left
        anchors.leftMargin: card.contentLeftInset
        anchors.bottom: footer.top
        anchors.bottomMargin: Style.space(14)
        width: root.sidebarW
        height: Style.space(34)
        color: Qt.rgba(root.foreground.r, root.foreground.g, root.foreground.b, newStylingArea.containsMouse ? 0.08 : 0.0)
        border.width: 1
        border.color: Qt.rgba(root.foreground.r, root.foreground.g, root.foreground.b, 0.3)
        Behavior on color { ColorAnimation { duration: 100 } }

        Text {
          anchors.centerIn: parent
          text: "+ " + root.tr("New styling")
          color: newStylingArea.containsMouse ? Color.menu.text : root.muted
          font.family: root.fontFamily
          font.pixelSize: Style.font.bodySmall
        }

        MouseArea {
          id: newStylingArea
          anchors.fill: parent
          hoverEnabled: true
          onClicked: root.newBootDesign()
        }
      }

      // Right live-preview panel (redesign): the current lock screen rendered
      // live, plus the boot-screen preview.
      Column {
        id: previewPanel
        // The editor brings its own pair of previews; give it the width.
        visible: root.mainTab !== "editor"
        anchors.top: header.bottom
        anchors.bottom: footer.top
        anchors.right: parent.right
        anchors.rightMargin: card.contentRightInset + Style.space(8)
        anchors.topMargin: Style.space(6)
        anchors.bottomMargin: Style.space(10)
        width: root.rightPanelW - Style.space(8)
        spacing: Style.space(12)

        Row {
          width: parent.width
          Text {
            text: root.tr("LOCK SCREEN")
            color: root.muted
            font.family: root.fontFamily
            font.pixelSize: Style.font.caption
            font.letterSpacing: 2
          }
          Item { width: parent.width - lockLbl.width - liveLbl.width; height: 1 }
          Text {
            id: lockLbl; visible: false; text: root.tr("LOCK SCREEN")
            font.family: root.fontFamily; font.pixelSize: Style.font.caption; font.letterSpacing: 2
          }
          Text {
            id: liveLbl
            text: "● " + root.tr("Live")
            color: root.accent
            font.family: root.fontFamily
            font.pixelSize: Style.font.caption
          }
        }

        // Live render of the selected design, scaled from full screen.
        Rectangle {
          width: parent.width
          height: Math.round(parent.width * 9 / 16)
          radius: root.cornerRadius
          color: Color.background
          border.width: 1
          border.color: Qt.rgba(root.foreground.r, root.foreground.g, root.foreground.b, 0.2)
          clip: true

          Item {
            width: panel.width
            height: panel.height
            scale: (parent.width - 2) / panel.width
            transformOrigin: Item.TopLeft
            enabled: false   // never let the preview's input steal keyboard focus
            LockHost {
              anchors.fill: parent
              designId: root.selectedDesign ? root.selectedDesign.id : root.activeDesignId
              revision: root.service ? root.service.designsRevision : 0
              twelveHour: root.twelveHour
              wallpaperBlur: root.wallpaperBlurValue
              wallpaperDim: root.wallpaperDimShift
              uiScale: root.uiScale
              holdStill: root.motionReduced
              language: root.lockLanguage
              fullName: root.accountName
              showLayoutBadge: root.showLayoutBadge
              showCapsBadge: root.showCapsBadge
              allowPasswordToggle: root.allowPasswordToggle
              showAuthIcons: root.showAuthIcons
              backgroundPath: root.service ? root.service.backgroundPath : ""
              backgroundVersion: root.service ? root.service.backgroundVersion : 0
              avatarPath: root.service ? root.service.avatarPath : ""
              avatarVersion: root.service ? root.service.avatarVersion : 0
              inputEnabled: false
              loadBackground: root.opened
              passwordText: "omarchy"
              videoPath: root.service ? root.service.videoPath : ""
              videoPlaying: root.opened
            }
          }
        }

        Rectangle {
          width: parent.width
          height: Style.space(30)
          radius: root.cornerRadius
          color: Qt.rgba(root.foreground.r, root.foreground.g, root.foreground.b, fullBtnArea.containsMouse ? 0.12 : 0.05)
          border.width: 1
          border.color: Qt.rgba(root.foreground.r, root.foreground.g, root.foreground.b, 0.2)
          Text {
            anchors.centerIn: parent
            text: root.tr("Preview full screen") + " · Space"
            color: root.foreground
            font.family: root.fontFamily
            font.pixelSize: Style.font.caption
          }
          MouseArea {
            id: fullBtnArea
            anchors.fill: parent
            hoverEnabled: true
            onClicked: root.fullPreview = true
          }
        }

        Item { width: 1; height: Style.space(4) }

        Row {
          width: parent.width
          Text {
            text: root.tr("BOOT SCREEN")
            color: root.muted
            font.family: root.fontFamily
            font.pixelSize: Style.font.caption
            font.letterSpacing: 2
          }
        }

        Row {
          width: parent.width
          spacing: Style.space(12)

          Rectangle {
            width: Style.space(150)
            height: Math.round(Style.space(150) * 9 / 16)
            radius: root.cornerRadius
            color: Color.background
            border.width: 1
            border.color: Qt.rgba(root.foreground.r, root.foreground.g, root.foreground.b, 0.2)
            clip: true
            Image {
              id: appliedBootThumb
              anchors.fill: parent; anchors.margins: 1
              // Every apply writes its own preview image, so this always shows
              // exactly what is on the boot image — snapshots included, which
              // the per-card cache never carries.
              source: root.bootApplied.length > 0
                ? "file://" + Quickshell.env("HOME") + "/.local/state/omarchy/lock-explorer-boot-preview.png?v="
                  + (root.service ? root.service.bootAppliedVersion : 0)
                : root.bootCardPreview("stock")
              fillMode: Image.PreserveAspectCrop
              asynchronous: true
              cache: false
            }
            Text {
              anchors.centerIn: parent
              visible: root.bootApplied.length === 0 && appliedBootThumb.status !== Image.Ready
              text: root.tr("stock")
              color: root.muted
              font.family: root.fontFamily
              font.pixelSize: Style.font.caption
            }
          }

          Column {
            width: parent.width - Style.space(162)
            spacing: Style.space(3)
            Text {
              width: parent.width
              elide: Text.ElideRight
              text: root.bootNowName
              textFormat: Text.PlainText
              color: Color.menu.text
              font.family: root.fontFamily
              font.pixelSize: Style.font.bodySmall
            }
            Text {
              width: parent.width
              wrapMode: Text.WordWrap
              text: root.bootApplying ? root.tr("Rebuilding…") : (root.bootAppliedTheme.length > 0 ? root.tr("Baked from %1").arg(root.bootAppliedTheme) : root.tr("The disk passphrase screen"))
              textFormat: Text.PlainText
              color: root.muted
              font.family: root.fontFamily
              font.pixelSize: Style.font.caption
            }
            Text {
              width: parent.width
              wrapMode: Text.WordWrap
              text: root.tr("Boot screen settings") + " ›"
              color: root.accent
              font.family: root.fontFamily
              font.pixelSize: Style.font.caption
              MouseArea { anchors.fill: parent; anchors.margins: -Style.space(4); onClicked: root.mainTab = "boot" }
            }
          }
        }
      }

      // What an empty grid means: nothing starred yet, or no match.
      Text {
        visible: root.gridTab && root.designs.length === 0
        anchors.centerIn: grid
        width: Math.min(grid.width, Style.space(420))
        horizontalAlignment: Text.AlignHCenter
        wrapMode: Text.WordWrap
        textFormat: Text.PlainText
        text: root.searchText.trim().length > 0
              ? root.tr("No design matches “%1”. Esc clears the search.").arg(root.searchText.trim())
              : root.tr("Nothing starred yet. Press F on a design, or click the star on its card, to keep it here.")
        color: root.muted
        font.family: root.fontFamily
        font.pixelSize: Style.font.bodySmall
      }

      GridView {
        id: grid
        visible: root.gridTab
        anchors.top: header.bottom
        anchors.bottom: footer.top
        anchors.left: parent.left
        anchors.right: parent.right
        anchors.leftMargin: card.contentLeftInset + root.sidebarW + Style.space(20)
        anchors.rightMargin: card.contentRightInset + root.rightPanelW + Style.space(20)
        anchors.bottomMargin: Style.space(8)
        clip: true
        model: root.designs
        cellWidth: root.cellWidth
        cellHeight: root.thumbHeight + root.captionHeight + root.gap
        topMargin: Style.space(4)
        cacheBuffer: cellHeight * 2
        boundsBehavior: Flickable.StopAtBounds
        flickDeceleration: 4000
        maximumFlickVelocity: 3000

        delegate: Item {
          id: cell
          required property var modelData
          required property int index
          readonly property bool selected: index === root.selectedIndex
          readonly property bool active: modelData.id === root.activeDesignId
          // A preview is a whole lock screen, so only the ones on screen are
          // worth drawing. The rest stay built but out of the scene graph.
          readonly property bool inView: (y + height > grid.contentY - grid.cellHeight / 2)
            && (y < grid.contentY + grid.height + grid.cellHeight / 2)
          width: grid.cellWidth
          height: grid.cellHeight

          // Its turn to build: see thumbSlots. Once started it stays built.
          readonly property int rank: index - root.gridTopRow * root.columns
          readonly property bool mayLoad: inView && rank < root.thumbSlots
          property bool wanted: false
          onMayLoadChanged: if (mayLoad) wanted = true
          Component.onCompleted: if (mayLoad) wanted = true

          readonly property string cachedThumb: root.thumbFor(modelData.id)
          readonly property bool designUp: thumbLoader.status === Loader.Ready && !!thumbLoader.item && !!thumbLoader.item.item
          // Over a picture the live design fades in once it has had a moment
          // to draw; with no picture it shows as soon as it is there.
          property bool liveShown: false
          onDesignUpChanged: {
            if (!designUp) return
            if (cachedThumb.length === 0) liveShown = true
            else thumbnailRevealTimer.restart()
            if (cachedThumb.length === 0) grabTimer.restart()
          }
          onCachedThumbChanged: if (cachedThumb.length === 0 && designUp) grabTimer.restart()
          Timer { id: thumbnailRevealTimer; interval: 700; onTriggered: cell.liveShown = true }
          // A first picture soon, so a quick change of tab already has one,
          // and a second once slow wallpapers and intros have finished.
          Timer { id: grabTimer; interval: 1200; onTriggered: { cell.grabThumb(false); regrabTimer.restart() } }
          Timer { id: regrabTimer; interval: 3500; onTriggered: cell.grabThumb(true) }
          function grabThumb(again) {
            if (!root.opened || !cell.inView || !thumbLoader.item || (!again && cell.cachedThumb.length > 0)) return
            var id = cell.modelData.id
            var key = root.thumbStateKey
            var dpr = Screen.devicePixelRatio || 1
            thumbLoader.item.grabToImage(function(result) { root.keepThumb(id, key, result) },
              Qt.size(Math.round(root.thumbWidth * dpr), Math.round(root.thumbHeight * dpr)))
          }

          Rectangle {
            id: frame
            width: root.thumbWidth
            height: root.thumbHeight
            radius: root.cornerRadius
            color: Color.background
            border.width: cell.selected ? 3 : 1
            border.color: cell.selected ? root.accent : Qt.rgba(root.foreground.r, root.foreground.g, root.foreground.b, 0.18)
            clip: true
            Behavior on border.color { ColorAnimation { duration: 120 } }

            Item {
              anchors.fill: parent
              anchors.margins: frame.border.width
              clip: true
              Image {
                anchors.fill: parent
                visible: cell.inView && source != "" && !(cell.liveShown && cell.designUp)
                source: cell.cachedThumb
                cache: false
                smooth: true
              }
              Item {
                width: panel.width
                height: panel.height
                scale: (frame.width - frame.border.width * 2) / panel.width
                transformOrigin: Item.TopLeft
                visible: cell.inView
                opacity: cell.liveShown ? 1 : 0
                Behavior on opacity { NumberAnimation { duration: 180 } }
                Loader {
                  id: thumbLoader
                  anchors.fill: parent
                  asynchronous: true
                  active: cell.wanted
                  sourceComponent: LockHost {
                    stillTextureSize: Qt.size(root.thumbWidth, root.thumbHeight)
                    designId: cell.modelData.id
                    revision: root.service ? root.service.designsRevision : 0
                    twelveHour: root.twelveHour
                    wallpaperBlur: root.wallpaperBlurValue
                    wallpaperDim: root.wallpaperDimShift
                    uiScale: root.uiScale
                    holdStill: root.motionReduced
                    language: root.lockLanguage
                    fullName: root.accountName
                    showLayoutBadge: root.showLayoutBadge
                    showCapsBadge: root.showCapsBadge
                    allowPasswordToggle: root.allowPasswordToggle
                    showAuthIcons: root.showAuthIcons
                    backgroundPath: root.service ? root.service.backgroundPath : ""
                    backgroundVersion: root.service ? root.service.backgroundVersion : 0
                    avatarPath: root.service ? root.service.avatarPath : ""
                    avatarVersion: root.service ? root.service.avatarVersion : 0
                    fingerprintConfigured: root.service ? root.service.fingerprintConfigured : false
                    inputEnabled: false
                    loadBackground: root.opened
                    passwordText: "omarchy"
                    videoPath: root.service ? root.service.videoPath : ""
                    // Only the cell on screen decodes, the rest hold still.
                    videoPlaying: cell.inView
                  }
                }
              }
            }

            Rectangle {
              anchors.left: parent.left; anchors.top: parent.top; anchors.margins: Style.space(10)
              width: Style.space(24); height: Style.space(24); radius: 5
              color: root.shade(0.55)
              Text {
                anchors.centerIn: parent
                text: (cell.index + 1)
                color: root.foreground
                font.family: root.fontFamily
                font.pixelSize: Style.font.caption
                font.bold: true
              }
            }

            // Favorite: shown when starred, and on the selected card as the
            // way to star it with the mouse. Above the card's own click area,
            // which is declared after it.
            Rectangle {
              z: 2
              readonly property bool starred: root.isFavorite(cell.modelData.id)
              visible: starred || cell.selected
              anchors.left: parent.left; anchors.top: parent.top
              anchors.leftMargin: Style.space(40); anchors.topMargin: Style.space(10)
              width: Style.space(24); height: Style.space(24); radius: 5
              color: root.shade(0.55)
              Text {
                anchors.centerIn: parent
                text: parent.starred ? "★" : "☆"
                color: parent.starred ? root.accent : root.muted
                font.family: root.fontFamily
                font.pixelSize: Style.font.bodySmall
              }
              MouseArea {
                anchors.fill: parent
                z: 1
                onClicked: {
                  root.selectedIndex = cell.index
                  if (root.service && typeof root.service.toggleFavorite === "function") root.service.toggleFavorite(cell.modelData.id)
                }
              }
            }

            Rectangle {
              visible: cell.active
              anchors.right: parent.right; anchors.top: parent.top; anchors.margins: Style.space(10)
              width: activeText.implicitWidth + Style.space(14); height: Style.space(24); radius: root.cornerRadius
              color: root.accent
              Text {
                id: activeText
                anchors.centerIn: parent
                text: "󰄬 " + root.tr("Active")
                color: Color.background
                font.family: root.fontFamily
                font.pixelSize: Style.font.caption
                font.bold: true
              }
            }

            MouseArea {
              anchors.fill: parent
              onClicked: root.selectedIndex = cell.index
              onDoubleClicked: { root.selectedIndex = cell.index; root.apply() }
            }

            Row {
              visible: cell.selected
              anchors.right: parent.right
              anchors.bottom: parent.bottom
              anchors.margins: Style.space(10)
              spacing: Style.space(6)
              Rectangle {
                width: useLabel.implicitWidth + Style.space(16); height: Style.space(26); radius: 6
                color: root.accent
                Text {
                  id: useLabel
                  anchors.centerIn: parent
                  text: root.tr("Use") + "  ⏎"
                  color: Color.background
                  font.family: root.fontFamily
                  font.pixelSize: Style.font.caption
                  font.bold: true
                }
                MouseArea { anchors.fill: parent; onClicked: { root.selectedIndex = cell.index; root.apply() } }
              }
              Rectangle {
                width: custLabel.implicitWidth + Style.space(16); height: Style.space(26); radius: 6
                color: root.shade(0.6)
                border.width: 1
                border.color: Qt.rgba(root.foreground.r, root.foreground.g, root.foreground.b, 0.25)
                Text {
                  id: custLabel
                  anchors.centerIn: parent
                  text: cell.modelData.designer ? root.tr("Design") + "  E"
                    : (cell.modelData.path ? root.tr("Edit") + "  E" : root.tr("Customize") + "  C")
                  color: root.foreground
                  font.family: root.fontFamily
                  font.pixelSize: Style.font.caption
                  font.bold: true
                }
                MouseArea { anchors.fill: parent; onClicked: { root.selectedIndex = cell.index; root.customizeSelected() } }
              }
              // Only your own designs can be deleted; two clicks to confirm.
              Rectangle {
                visible: cell.modelData.path ? true : false
                width: delLabel.implicitWidth + Style.space(16); height: Style.space(26); radius: 6
                color: root.confirmingDelete === cell.modelData.id ? root.danger : root.shade(0.6)
                border.width: 1
                border.color: root.confirmingDelete === cell.modelData.id ? Qt.lighter(root.danger, 1.3) : Qt.rgba(root.foreground.r, root.foreground.g, root.foreground.b, 0.25)
                Text {
                  id: delLabel
                  anchors.centerIn: parent
                  text: root.tr(root.confirmingDelete === cell.modelData.id ? "Sure?" : "Delete") + "  X"
                  color: root.confirmingDelete === cell.modelData.id ? Color.background : root.foreground
                  font.family: root.fontFamily
                  font.pixelSize: Style.font.caption
                  font.bold: true
                }
                MouseArea { anchors.fill: parent; onClicked: { root.selectedIndex = cell.index; root.deleteSelected() } }
              }
            }
          }

          Column {
            anchors.top: frame.bottom
            anchors.topMargin: Style.space(8)
            width: root.thumbWidth
            spacing: 2
            Row {
              spacing: Style.space(8)
              Text {
                text: cell.modelData.name
                textFormat: Text.PlainText
                color: cell.selected ? root.foreground : root.muted
                font.family: root.fontFamily
                font.pixelSize: Style.font.title
                font.weight: cell.selected ? Font.DemiBold : Font.Normal
              }
              Row {
                spacing: Style.space(4)
                anchors.verticalCenter: parent.verticalCenter
                Repeater {
                  model: cell.modelData.tags || []
                  Rectangle {
                    required property string modelData
                    width: tagLabel.implicitWidth + Style.space(10)
                    height: Style.space(18)
                    radius: 4
                    color: Qt.rgba(root.foreground.r, root.foreground.g, root.foreground.b, 0.08)
                    Text {
                      id: tagLabel
                      anchors.centerIn: parent
                      text: {
                        var cats = Designs.categories()
                        for (var i = 0; i < cats.length; i++) if (cats[i].id === parent.modelData) return root.tr(cats[i].name)
                        return parent.modelData
                      }
                      textFormat: Text.PlainText
                      color: root.muted
                      font.family: root.fontFamily
                      font.pixelSize: Style.font.caption
                    }
                  }
                }
              }
            }
            Text {
              width: parent.width
              text: cell.modelData.description + (cell.modelData.credit ? "  ·  " + root.tr("Clip by %1").arg(cell.modelData.credit) : "")
              textFormat: Text.PlainText
              color: root.muted
              font.family: root.fontFamily
              font.pixelSize: Style.font.caption
              elide: Text.ElideRight
              maximumLineCount: 1
            }
          }
        }
      }

      // Above the grid: every design has a MouseArea of its own and so does the
      // cell, and those eat wheel events before the grid ever sees them. No
      // buttons, so clicks and drags still reach the cells underneath.
      MouseArea {
        anchors.fill: grid
        acceptedButtons: Qt.NoButton
        onWheel: function(wheel) {
          // Touchpads send pixel deltas with a coarse angle alongside them.
          // Reading the angle for both turned every small two finger move into
          // a whole notch, so use the pixels when they are there.
          var dy = wheel.pixelDelta.y !== 0 ? wheel.pixelDelta.y : wheel.angleDelta.y * 1.2
          var next = grid.contentY - dy
          grid.contentY = Math.max(0, Math.min(Math.max(0, grid.contentHeight - grid.height), next))
        }
      }

      Rectangle {
        anchors.top: grid.top
        anchors.bottom: grid.bottom
        anchors.right: parent.right
        anchors.rightMargin: card.contentRightInset - Style.space(4)
        width: 4
        radius: 2
        visible: grid.visible && grid.contentHeight > grid.height
        color: Qt.rgba(root.foreground.r, root.foreground.g, root.foreground.b, 0.08)
        Rectangle {
          width: parent.width
          radius: 2
          color: Qt.rgba(root.foreground.r, root.foreground.g, root.foreground.b, 0.35)
          height: Math.max(24, parent.height * grid.height / Math.max(1, grid.contentHeight))
          y: (parent.height - height) * (grid.contentY / Math.max(1, grid.contentHeight - grid.height))
        }
      }

      Item {
        id: footer
        anchors.bottom: parent.bottom
        anchors.left: parent.left
        anchors.right: parent.right
        anchors.bottomMargin: card.contentBottomInset
        anchors.leftMargin: card.contentLeftInset
        anchors.rightMargin: card.contentRightInset
        height: root.footerHeight
        Text {
          anchors.left: parent.left
          anchors.verticalCenter: parent.verticalCenter
          text: {
            if (root.mainTab === "editor") return root.tr("Changes save automatically   ·   Esc: back")
            if (root.mainTab === "boot") return root.tr("Click a card to pick it   ·   Apply writes it to the boot image   ·   B / Esc: back   ·   ?: all keys")
            if (root.mainTab === "settings") return root.tr("Arrows / PgUp / PgDn: scroll   ·   U / Esc: back   ·   ?: all keys")
            return root.tr("Arrows: browse   Space: preview   Enter: select   /: search   F: favorite   D: designer   U: settings   ?: all keys   Esc: close")
          }
          color: root.muted
          font.family: root.fontFamily
          font.pixelSize: Style.font.bodySmall
        }
      }
    }

    BorderSurface {
      id: editorSurface
      visible: root.editing
      width: root.cardWidth
      height: root.cardHeight
      radius: root.cornerRadius
      anchors.centerIn: parent
      color: root.background
      borderSpec: root.borderSpec

      MouseArea { anchors.fill: parent; onClicked: {} }

      Item {
        anchors.fill: parent
        anchors.topMargin: editorSurface.contentTopInset + root.contentMargin
        anchors.bottomMargin: editorSurface.contentBottomInset + root.contentMargin
        anchors.leftMargin: editorSurface.contentLeftInset + root.contentMargin
        anchors.rightMargin: editorSurface.contentRightInset + root.contentMargin

        Item {
          id: editorHeader
          anchors.top: parent.top
          anchors.left: parent.left
          anchors.right: parent.right
          height: Style.space(48)
          Column {
            anchors.left: parent.left
            anchors.verticalCenter: parent.verticalCenter
            spacing: 2
            Text {
              text: root.editingDesign ? root.editingDesign.name : ""
              textFormat: Text.PlainText
              color: root.foreground
              font.family: root.fontFamily
              font.pixelSize: Style.font.display
              font.weight: Font.DemiBold
            }
            Text {
              text: root.tr("Custom design")
              color: root.muted
              font.family: root.fontFamily
              font.pixelSize: Style.font.bodySmall
            }
          }
          Row {
            anchors.right: parent.right
            anchors.verticalCenter: parent.verticalCenter
            spacing: Style.space(8)
            Rectangle {
              width: saveLabel.implicitWidth + Style.space(20); height: Style.space(30); radius: 6
              color: editorView.dirty ? root.accent : Qt.rgba(root.foreground.r, root.foreground.g, root.foreground.b, 0.08)
              Text {
                id: saveLabel
                anchors.centerIn: parent
                text: root.tr("Save  Ctrl+S")
                color: editorView.dirty ? Color.background : root.foreground
                font.family: root.fontFamily
                font.pixelSize: Style.font.bodySmall
                font.bold: editorView.dirty
              }
              MouseArea { anchors.fill: parent; onClicked: editorView.save() }
            }
            Rectangle {
              width: useLabel2.implicitWidth + Style.space(20); height: Style.space(30); radius: 6
              color: Qt.rgba(root.foreground.r, root.foreground.g, root.foreground.b, 0.08)
              Text {
                id: useLabel2
                anchors.centerIn: parent
                text: root.tr("Use this design")
                color: root.foreground
                font.family: root.fontFamily
                font.pixelSize: Style.font.bodySmall
              }
              MouseArea {
                anchors.fill: parent
                onClicked: {
                  if (root.editingDesign) root.useDesign(root.editingDesign.id, false)
                }
              }
            }
            Rectangle {
              width: backLabel.implicitWidth + Style.space(20); height: Style.space(30); radius: 6
              color: Qt.rgba(root.foreground.r, root.foreground.g, root.foreground.b, 0.08)
              Text {
                id: backLabel
                anchors.centerIn: parent
                text: root.tr("Back  Esc")
                color: root.foreground
                font.family: root.fontFamily
                font.pixelSize: Style.font.bodySmall
              }
              MouseArea { anchors.fill: parent; onClicked: editorView.requestClose() }
            }
          }
        }

        Editor {
          id: editorView
          anchors.top: editorHeader.bottom
          anchors.topMargin: Style.space(12)
          anchors.bottom: parent.bottom
          anchors.left: parent.left
          anchors.right: parent.right
          service: root.service
          design: root.editing ? root.editingDesign : null
          background: root.background
          foreground: root.foreground
          accent: root.accent
          fontFamily: root.fontFamily
          screenWidth: panel.width
          screenHeight: panel.height
          onCloseRequested: root.closeEditor()
          onOpenExternalRequested: function(path) { root.openExternal(path) }
        }
      }
    }

    BorderSurface {
      id: designerCard
      visible: root.designing
      width: root.cardWidth
      height: root.cardHeight
      radius: root.cornerRadius
      anchors.centerIn: parent
      color: root.background
      borderSpec: root.borderSpec

      MouseArea { anchors.fill: parent; onClicked: {} }

      Designer {
        id: designerView
        anchors.fill: parent
        anchors.topMargin: designerCard.contentTopInset + root.contentMargin
        anchors.bottomMargin: designerCard.contentBottomInset + root.contentMargin
        anchors.leftMargin: designerCard.contentLeftInset + root.contentMargin
        anchors.rightMargin: designerCard.contentRightInset + root.contentMargin
        service: root.service
        design: root.designing ? root.designingDesign : null
        pluginId: root.pluginId
        background: root.background
        foreground: root.foreground
        accent: root.accent
        fontFamily: root.fontFamily
        screenWidth: panel.width
        screenHeight: panel.height
        onCloseRequested: root.closeDesigner()
        onUseRequested: if (root.designingDesign) root.useDesign(root.designingDesign.id, false)
        onPickFileRequested: root.pickDesignerImage()
        onOpenCodeRequested: function(path) {
          // Straight from the canvas into the code, on the same file.
          root.designing = false
          root.openEditor(root.designingDesign)
        }
      }
    }

    Item {
      anchors.fill: parent
      visible: root.fullPreview

      LockHost {
        anchors.fill: parent
        designId: root.selectedDesign ? root.selectedDesign.id : Designs.DEFAULT_ID
        revision: root.service ? root.service.designsRevision : 0
        twelveHour: root.twelveHour
        wallpaperBlur: root.wallpaperBlurValue
        wallpaperDim: root.wallpaperDimShift
        uiScale: root.uiScale
        holdStill: root.motionReduced
        language: root.lockLanguage
        fullName: root.accountName
        showLayoutBadge: root.showLayoutBadge
        showCapsBadge: root.showCapsBadge
        allowPasswordToggle: root.allowPasswordToggle
        showAuthIcons: root.showAuthIcons
        backgroundPath: root.service ? root.service.backgroundPath : ""
        backgroundVersion: root.service ? root.service.backgroundVersion : 0
        fingerprintConfigured: root.service ? root.service.fingerprintConfigured : false
        inputEnabled: false
        loadBackground: root.opened && root.fullPreview
        passwordText: ""
        videoPath: root.service ? root.service.videoPath : ""
        videoPlaying: root.fullPreview
      }

      MouseArea { anchors.fill: parent; onClicked: root.fullPreview = false }

      Rectangle {
        anchors.top: parent.top
        anchors.horizontalCenter: parent.horizontalCenter
        anchors.topMargin: Style.space(20)
        width: hud.implicitWidth + Style.space(32)
        height: hud.implicitHeight + Style.space(20)
        radius: root.cornerRadius
        color: Qt.rgba(root.background.r, root.background.g, root.background.b, 0.85)
        border.width: 1
        border.color: Qt.rgba(root.foreground.r, root.foreground.g, root.foreground.b, 0.2)
        Row {
          id: hud
          anchors.centerIn: parent
          spacing: Style.space(18)
          Text {
            text: (root.selectedIndex + 1) + "/" + root.designs.length + "   " + (root.selectedDesign ? root.selectedDesign.name : "")
            textFormat: Text.PlainText
            color: root.foreground
            font.family: root.fontFamily
            font.pixelSize: Style.font.title
            font.weight: Font.DemiBold
          }
          Text {
            text: root.tr("Arrows: next   Enter: select   Esc: back")
            color: root.muted
            font.family: root.fontFamily
            font.pixelSize: Style.font.bodySmall
            anchors.verticalCenter: parent.verticalCenter
          }
        }
      }
    }

    Item {
      anchors.fill: parent
      visible: root.showingKeys
      z: 100

      Rectangle { anchors.fill: parent; color: root.scrim }
      MouseArea { anchors.fill: parent; onClicked: root.showingKeys = false }

      BorderSurface {
        id: keysSheet
        anchors.centerIn: parent
        width: keysBody.implicitWidth + contentLeftInset + contentRightInset
        height: keysBody.implicitHeight + contentTopInset + contentBottomInset
        radius: root.cornerRadius
        color: root.background
        borderSpec: root.borderSpec
        padding: root.contentMargin

        MouseArea { anchors.fill: parent; onClicked: {} }

        Column {
          id: keysBody
          x: keysSheet.contentLeftInset
          y: keysSheet.contentTopInset
          spacing: Style.space(24)

          Column {
            spacing: 3
            Row {
              spacing: Style.space(8)
              Text {
                text: "::"
                color: root.accent
                font.family: root.fontFamily
                font.pixelSize: Style.font.display
                font.weight: Font.Bold
              }
              Text {
                text: root.tr("KEYBOARD SHORTCUTS")
                color: root.foreground
                font.family: root.fontFamily
                font.pixelSize: Style.font.display
                font.weight: Font.Bold
                font.letterSpacing: 2
              }
            }
            Text {
              text: root.tr("On the design grid") + " · " + root.tr("Esc or ? closes this")
              color: root.muted
              font.family: root.fontFamily
              font.pixelSize: Style.font.bodySmall
            }
          }

          Grid {
            columns: 2
            columnSpacing: Style.space(48)
            rowSpacing: Style.space(24)

            Repeater {
              model: root.keySections
              Column {
                id: keySection
                required property var modelData
                spacing: Style.space(8)

                Text {
                  text: root.tr(keySection.modelData.title).toUpperCase()
                  color: root.accent
                  font.family: root.fontFamily
                  font.pixelSize: Style.font.caption
                  font.weight: Font.DemiBold
                  font.letterSpacing: 1.5
                }

                Repeater {
                  model: keySection.modelData.rows
                  Row {
                    id: keyRow
                    required property var modelData
                    spacing: Style.space(12)

                    Item {
                      width: root.keyCapsWidth
                      height: Style.space(22)
                      Row {
                        anchors.verticalCenter: parent.verticalCenter
                        spacing: Style.space(4)
                        onImplicitWidthChanged: root.keyCapsWidth = Math.max(root.keyCapsWidth, implicitWidth)
                        Repeater {
                          model: keyRow.modelData.keys
                          Rectangle {
                            id: keyCap
                            required property var modelData
                            width: Math.max(Style.space(22), capLabel.implicitWidth + Style.space(12))
                            height: Style.space(22)
                            radius: root.cornerRadius
                            color: Qt.rgba(root.foreground.r, root.foreground.g, root.foreground.b, 0.08)
                            border.width: 1
                            border.color: Qt.rgba(root.foreground.r, root.foreground.g, root.foreground.b, 0.18)
                            Text {
                              id: capLabel
                              anchors.centerIn: parent
                              text: keyCap.modelData
                              textFormat: Text.PlainText
                              color: root.foreground
                              font.family: root.fontFamily
                              font.pixelSize: Style.font.caption
                            }
                          }
                        }
                      }
                    }

                    Text {
                      anchors.verticalCenter: parent.verticalCenter
                      text: root.tr(keyRow.modelData.text)
                      textFormat: Text.PlainText
                      color: root.foreground
                      font.family: root.fontFamily
                      font.pixelSize: Style.font.bodySmall
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
  }
}
