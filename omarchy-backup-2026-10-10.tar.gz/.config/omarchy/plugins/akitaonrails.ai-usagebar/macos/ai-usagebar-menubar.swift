// ai-usagebar-menubar — macOS menu bar app for ai-usagebar.
//
// Shows ai-usagebar's 5-hour (session), weekly, and optional extra-usage
// bars in the macOS menu bar, next to the clock, with a native dropdown and
// a Preferences window (⌘,). Mirrors the GNOME Shell extension: same binary,
// same One Dark colors and severity thresholds. Runs as a menu-bar agent.
//
// Settings persist in UserDefaults (edit them in Preferences, no rebuild).
//
// Build:  swiftc -O -parse-as-library ai-usagebar-menubar.swift -o ai-usagebar-menubar
//         (needs the Xcode command-line tools: `xcode-select --install`)
// Run:    ./ai-usagebar-menubar &      (or ./install-agent.sh for login start)
// macOS:  12+ (Monterey) for the Preferences window; menu bar works on 10.15+.
//
// First, on the Mac: run `claude` once so the OAuth creds land in the login
// Keychain — ai-usagebar reads them there (src/anthropic/keychain.rs).

import Cocoa
import SwiftUI
import Carbon.HIToolbox  // RegisterEventHotKey for the global vendor-swap shortcut

// ─── Settings (persisted in UserDefaults; edit in Preferences) ───────────
let DEF = UserDefaults.standard

let SETTINGS_DEFAULTS: [String: Any] = [
    "vendor": "anthropic",
    "interval": 30.0,
    "barWidth": 8,
    "showSession": true,
    "showWeekly": true,
    "showExtra": false,
    "showPercent": true,
    "showBars": true,
    "showMeta": true,
    "showResetClock": false,
    "barStyle": "block",
    "colorLow": "#98c379",
    "colorMid": "#e5c07b",
    "colorHigh": "#d19a66",
    "colorCritical": "#e06c75",
    "colorEmpty": "#3e4451",
    "binaryPath": "",
]

var VENDOR: String { DEF.string(forKey: "vendor") ?? "anthropic" }
var INTERVAL: Double { let v = DEF.double(forKey: "interval"); return v > 0 ? v : 30 }
/// Upper bound on one `ai-usagebar` invocation. It can block on the cache
/// flock (up to 15s) and then refresh OAuth over the network, so without a
/// bound a hung run holds a worker indefinitely and the panel simply stops
/// updating with no explanation. Matches the GNOME extension's own timeout.
let REFRESH_TIMEOUT: Double = 45
var BAR_WIDTH: Int { max(4, min(20, DEF.integer(forKey: "barWidth"))) }
let MENU_BAR_W = 14
var SHOW_SESSION: Bool { DEF.bool(forKey: "showSession") }
var SHOW_WEEKLY: Bool { DEF.bool(forKey: "showWeekly") }
var SHOW_EXTRA: Bool { DEF.bool(forKey: "showExtra") }
var SHOW_PERCENT: Bool { DEF.bool(forKey: "showPercent") }
var SHOW_BARS: Bool { DEF.bool(forKey: "showBars") }
// Layout of the progress indicator: "block" (default, text bars ░█) or "ring"
// (a Core Graphics arc image). Both honor the meta marker the same way.
var BAR_STYLE: String { DEF.string(forKey: "barStyle") ?? "block" }
var COLOR_LOW: String { DEF.string(forKey: "colorLow") ?? "#98c379" }
var COLOR_MID: String { DEF.string(forKey: "colorMid") ?? "#e5c07b" }
var COLOR_HIGH: String { DEF.string(forKey: "colorHigh") ?? "#d19a66" }
var COLOR_CRITICAL: String { DEF.string(forKey: "colorCritical") ?? "#e06c75" }
var COLOR_EMPTY: String { DEF.string(forKey: "colorEmpty") ?? "#3e4451" }
// Meta reference: draw a pace marker at the elapsed-time position and flag the
// over-meta segment of the fill. Off = plain absolute-usage bars, no marker.
var SHOW_META: Bool { DEF.bool(forKey: "showMeta") }
// Off (default) = countdown ("1d 1h", "14h 32m"); on = the wall-clock time the
// window resets at ("14:32", or "9/7/26, 2:32 PM" beyond today), computed
// client-side from the countdown the binary already reports — see
// `resetSeconds`/`resetDate` below.
var SHOW_RESET_CLOCK: Bool { DEF.bool(forKey: "showResetClock") }
// The meta marker is a fixed blue, matching the binary's default theme `marker`
// color and distinct from the over-pace warning fill.
let COLOR_MARKER = "#61afef"
let POINT_MID_MIN = -10
let POINT_CRITICAL_MIN = 10

// The `{scoped_*}` fields (10-12) carry the model-scoped weekly window (e.g.
// "Fable") from the API's `limits[]`; empty on older binaries → the row falls
// back to the flat `{sonnet_*}` window and the "Sonnet only" label. The trailing
// `*_elapsed` fields (13-15) carry the meta (pace) position; `vendor_short`
// (16) lets balance-only vendors suppress meaningless quota rows. The balance
// fields (17-22) carry the per-vendor credits — only the selected vendor's is
// populated — and the `aapi_*` fields (23-26) carry the Anthropic API headline
// plus its spend-vs-limit bar. `cursor_total_pct` (27) is followed by the
// Antigravity-only fourth-window fields (28-30) and the Z.AI MCP-tools pool
// (31-33), which fills that same fourth-window slot. `{oll_monthly_pct}` /
// `{oll_monthly_reset}` (50-51) carry Ollama Cloud's calendar-month pool;
// empty when the account reports session/weekly instead. `{lyceum_balance}` (52)
// carries Lyceum's USD balance. `{dif_balance}` (53) carries DeepInfra's
// USD balance. `{devin_daily_pct}` / `{devin_daily_reset}` /
// `{devin_daily_elapsed}` (54-56) carry Devin's daily quota pool (empty when
// not selected); Devin's weekly pool uses the shared `{weekly_*}` placeholders.
// A final literal
// sentinel absorbs the widget's stale suffix, preserving these fields.
let FORMAT = "{plan};;{session_pct};;{session_reset};;{weekly_pct};;{weekly_reset};;" +
             "{sonnet_pct};;{sonnet_reset};;{extra_pct};;{extra_spent};;{extra_limit};;" +
             "{scoped_model};;{scoped_pct};;{scoped_reset};;" +
             "{session_elapsed};;{weekly_elapsed};;{scoped_elapsed};;{vendor_short};;{or_balance};;" +
             "{ds_balance};;{kilo_balance};;{nv_balance};;{km_balance};;{grok_balance};;" +
             "{aapi_headline};;{aapi_pct};;{aapi_spent};;{aapi_limit};;{cursor_total_pct};;" +
             "{extra_model};;{extra_reset};;{extra_elapsed};;" +
             "{zai_mcp_pct};;{zai_mcp_reset};;{zai_mcp_elapsed};;" +
             "{ocg_monthly_pct};;{ocg_monthly_reset};;" +
             "{cc_monthly_pct};;{cc_monthly_reset};;" +
             "{copilot_completions_pct};;{copilot_reset};;" +
             "{sgk_period};;{minimax_video_pct};;{minimax_video_reset};;" +
             "{minimax_video_elapsed};;{minimax_video_weekly_pct};;{minimax_video_weekly_reset};;{minimax_video_weekly_elapsed};;" +
             "{copilot_chat_limit};;{copilot_completions_limit};;{copilot_premium_limit};;" +
             "{oll_monthly_pct};;{oll_monthly_reset};;{lyceum_balance};;{dif_balance};;" +
             "{devin_daily_pct};;{devin_daily_reset};;{devin_daily_elapsed}"

let FORMAT_WITH_SENTINEL = FORMAT + ";;__aiub_end__"

// ─── Color / text helpers ────────────────────────────────────────────────
func hexColor(_ hex: String) -> NSColor {
    var s = hex
    if s.hasPrefix("#") { s.removeFirst() }
    guard s.count == 6, let v = UInt32(s, radix: 16) else { return .labelColor }
    return NSColor(srgbRed: CGFloat((v >> 16) & 0xff) / 255.0,
                   green: CGFloat((v >> 8) & 0xff) / 255.0,
                   blue: CGFloat(v & 0xff) / 255.0,
                   alpha: 1.0)
}

func colorForPct(_ pct: Int) -> NSColor {
    if pct >= 90 { return hexColor(COLOR_CRITICAL) }
    if pct >= 75 { return hexColor(COLOR_HIGH) }
    if pct >= 50 { return hexColor(COLOR_MID) }
    return hexColor(COLOR_LOW)
}

// Matches pacing::pace_severity: < -10 low, -10...0 mid, 1...9 high, >= 10 critical.
func colorForDelta(_ delta: Int) -> NSColor {
    if delta >= POINT_CRITICAL_MIN { return hexColor(COLOR_CRITICAL) }
    if delta > 0 { return hexColor(COLOR_HIGH) }
    if delta >= POINT_MID_MIN { return hexColor(COLOR_MID) }
    return hexColor(COLOR_LOW)
}

func menuBarTextColor(_ appearance: NSAppearance, secondary: Bool = false) -> NSColor {
    let isDark = appearance.bestMatch(from: [.darkAqua, .aqua]) == .darkAqua
    let color = isDark ? NSColor.white : NSColor.black
    return secondary ? color.withAlphaComponent(0.72) : color
}

// The ring track needs to stay visible over both light and dark menu bars /
// dropdowns. The user-configured COLOR_EMPTY is a dark charcoal meant for the
// block bar's ░ glyphs on a light surface; on a dark wallpaper or dark menu bar
// it vanishes. So the ring track uses a faint white in dark appearance (visible
// against the dark background) and falls back to COLOR_EMPTY in light
// appearance, keeping parity with the block bar there.
func ringTrackColor(_ appearance: NSAppearance) -> NSColor {
    let isDark = appearance.bestMatch(from: [.darkAqua, .aqua]) == .darkAqua
    return isDark ? NSColor.white.withAlphaComponent(0.25) : hexColor(COLOR_EMPTY)
}

/// True when a countdown field carries a real value. The widget prints `—` for
/// a window the vendor did not report, and an older binary that does not know a
/// placeholder leaves it empty.
func isReported(_ countdown: String) -> Bool {
    !countdown.isEmpty && countdown != "—"
}

// A missing reset keeps its row visible but never has a meaningful pace marker.
func markerElapsed(reset: String, elapsed: Int?) -> Int? {
    guard isReported(reset) else { return nil }
    return elapsed
}

/// Squeeze a countdown ("4d 1h", "2h 05m", "now") down to its leading unit for
/// the overview status-bar title, where every character fights for space:
/// "4d 1h" → "4d", "2h 05m" → "2h", "0h 05m" → "5m". Missing/em-dash → nil.
func shortReset(_ r: String) -> String? {
    guard !r.isEmpty, r != "—" else { return nil }
    let parts = r.split(separator: " ")
    guard let first = parts.first else { return nil }
    if first == "0h", parts.count > 1 {
        let m = parts[1].drop(while: { $0 == "0" })
        return m == "m" ? "0m" : String(m)
    }
    return String(first)
}

/// Parse the binary's countdown text ("4d 1h", "23h 59m", "now", "—") back
/// into seconds remaining. `nil` for "—"/empty/unparseable, matching
/// `isReported`. The binary's own `countdown::format` drops minutes once a
/// day is present, so a `>=1d` result only carries hour precision — the same
/// precision loss the countdown display already has.
func resetSeconds(_ r: String) -> Int? {
    guard isReported(r) else { return nil }
    if r == "now" { return 0 }
    let parts = r.split(separator: " ")
    var seconds = 0
    var matchedAny = false
    for part in parts {
        if let h = part.hasSuffix("h") ? Int(part.dropLast()) : nil {
            seconds += h * 3600
            matchedAny = true
        } else if let d = part.hasSuffix("d") ? Int(part.dropLast()) : nil {
            seconds += d * 86_400
            matchedAny = true
        } else if let m = part.hasSuffix("m") ? Int(part.dropLast()) : nil {
            seconds += m * 60
            matchedAny = true
        }
    }
    return matchedAny ? seconds : nil
}

/// The absolute instant a countdown string resolves to, or `nil` when the
/// countdown itself carries no value.
func resetDate(_ r: String, now: Date = Date()) -> Date? {
    resetSeconds(r).map { now.addingTimeInterval(TimeInterval($0)) }
}

private let resetTimeOnlyFormatter: DateFormatter = {
    let f = DateFormatter()
    f.dateStyle = .none
    f.timeStyle = .short
    return f
}()

private let resetDateTimeFormatter: DateFormatter = {
    let f = DateFormatter()
    f.dateStyle = .short
    f.timeStyle = .short
    return f
}()

/// Wall-clock label for a countdown, honoring `SHOW_RESET_CLOCK`: off returns
/// the countdown unchanged (`fallback`), on renders the resolved instant —
/// just the time when it falls today, date + time otherwise. `nil` when the
/// countdown itself is unreported, same as the value it replaces.
func resetClockLabel(_ r: String, fallback: String?, showClock: Bool = SHOW_RESET_CLOCK,
                     now: Date = Date()) -> String? {
    guard showClock else { return fallback }
    guard let date = resetDate(r, now: now) else { return nil }
    let formatter = Calendar.current.isDate(date, inSameDayAs: now)
        ? resetTimeOnlyFormatter
        : resetDateTimeFormatter
    return formatter.string(from: date)
}

let barFont = NSFont.monospacedSystemFont(ofSize: 13, weight: .regular)

func run(_ s: String, _ color: NSColor, _ font: NSFont = barFont) -> NSAttributedString {
    NSAttributedString(string: s, attributes: [.foregroundColor: color, .font: font])
}

// Block bar. When `elapsed` (0..100) is known and the meta is on, the fill stays
// in the calm absolute-usage color up to a blue marker at the elapsed position,
// and only the part that overshoots the meta (how far ahead of pace you are →
// risk of paid extra usage) is painted in the warning color. Otherwise it's a
// plain absolute-color bar with no marker.
func barAttr(pct: Int, width: Int, elapsed: Int?) -> NSAttributedString {
    let p = max(0, min(100, pct))
    let filled = Int((Double(p) * Double(width) / 100.0).rounded())
    let out = NSMutableAttributedString()

    guard SHOW_META, let elapsedVal = elapsed else {
        out.append(run(String(repeating: "█", count: filled), colorForPct(p)))
        out.append(run(String(repeating: "░", count: max(0, width - filled)), hexColor(COLOR_EMPTY)))
        return out
    }

    let e = max(0, min(100, elapsedVal))
    let base = colorForPct(p)        // on-track portion → calm absolute color
    let over = colorForDelta(p - e)  // excess beyond the meta → pace warning
    var m = Int(Double(e) * Double(width) / 100.0) // floor
    if m > width - 1 { m = width - 1 }
    if m < 0 { m = 0 }
    let preF = min(filled, m)
    let postF = filled > m + 1 ? filled - m - 1 : 0
    let preE = m - preF
    let postE = width - m - 1 - postF
    out.append(run(String(repeating: "█", count: max(0, preF)), base))
    out.append(run(String(repeating: "░", count: max(0, preE)), hexColor(COLOR_EMPTY)))
    out.append(run("│", hexColor(COLOR_MARKER)))
    out.append(run(String(repeating: "█", count: max(0, postF)), over))
    out.append(run(String(repeating: "░", count: max(0, postE)), hexColor(COLOR_EMPTY)))
    return out
}

// Ring indicator (optional layout). A Core Graphics arc whose sweep is the
// usage fraction, painted in the severity color, over a faint track. When the
// meta is on, the elapsed position marks a blue tick and the arc beyond it (how
// far ahead of pace you are) shifts to the pace-warning color — the same idea
// as the block bar, just radial. The image is rendered as an attachment so it
// composes in an attributed string alongside the percentage text.
/// Arc geometry for a ring segment, in degrees for `NSBezierPath.appendArc`.
/// The ring starts at 12 o'clock (`startRad = -π/2`) and fills clockwise, so a
/// segment [from, to] spans `[start - 2π·from, start - 2π·to]`. Pure and tested
/// so the pace-arc regression (overshoot restarting at 12h) cannot return.
func arcAngles(from fromFraction: CGFloat, to toFraction: CGFloat,
               startRad: CGFloat = -.pi / 2) -> (startDeg: CGFloat, endDeg: CGFloat) {
    ((startRad - 2 * .pi * fromFraction) * 180 / .pi,
     (startRad - 2 * .pi * toFraction) * 180 / .pi)
}

func ringImage(pct: Int, size: CGFloat, elapsed: Int?, appearance: NSAppearance) -> NSImage {
    let p = CGFloat(max(0, min(100, pct))) / 100.0
    let img = NSImage(size: NSSize(width: size, height: size))
    img.lockFocus()

    let box = NSRect(x: 0, y: 0, width: size, height: size)
    let lw = max(1.6, size * 0.16)
    let inset = lw / 2 + 0.5
    let rect = box.insetBy(dx: inset, dy: inset)
    let start: CGFloat = -.pi / 2

    // Track (empty background ring).
    let track = NSBezierPath()
    track.appendArc(withCenter: CGPoint(x: size / 2, y: size / 2),
                    radius: rect.width / 2, startAngle: 0, endAngle: 360)
    track.lineWidth = lw
    ringTrackColor(appearance).setStroke()
    track.stroke()

    // Filled arc. With the meta on, the part behind the pace marker keeps the
    // calm absolute color and the overshoot turns warning; otherwise a single
    // severity-colored sweep. The helper draws [from, to] so the overshoot can
    // continue from the elapsed marker to pct instead of restarting at 12h.
    let drawArc = { (fromFraction: CGFloat, toFraction: CGFloat, color: NSColor) in
        guard toFraction > fromFraction else { return }
        let a = arcAngles(from: fromFraction, to: toFraction, startRad: start)
        let arc = NSBezierPath()
        arc.appendArc(withCenter: CGPoint(x: size / 2, y: size / 2),
                      radius: rect.width / 2,
                      startAngle: a.startDeg,
                      endAngle: a.endDeg,
                      clockwise: true)
        arc.lineWidth = lw
        color.setStroke()
        arc.stroke()
    }
    let pInt = max(0, min(100, pct))
    if SHOW_META, let elapsedVal = elapsed {
        let e = max(0, min(100, elapsedVal))
        let base = colorForPct(pInt)
        let over = colorForDelta(pInt - e)
        let eFrac = CGFloat(e) / 100.0
        let boundary = min(p, eFrac)
        drawArc(0, boundary, base)
        if p > eFrac { drawArc(boundary, p, over) }
        // Pace tick at the elapsed position.
        let tickAngle = start - 2 * .pi * eFrac
        let c = CGPoint(x: size / 2, y: size / 2)
        let r = rect.width / 2
        let tick = NSBezierPath()
        tick.move(to: CGPoint(x: c.x + (r - lw) * cos(tickAngle),
                              y: c.y + (r - lw) * sin(tickAngle)))
        tick.line(to: CGPoint(x: c.x + (r + lw) * cos(tickAngle),
                              y: c.y + (r + lw) * sin(tickAngle)))
        tick.lineWidth = max(1, lw * 0.5)
        hexColor(COLOR_MARKER).setStroke()
        tick.stroke()
    } else {
        drawArc(0, p, colorForPct(pInt))
    }
    img.unlockFocus()
    img.isTemplate = false
    return img
}

final class ColoredAttachmentCell: NSTextAttachmentCell {
    override func draw(withFrame cellFrame: NSRect, in controlView: NSView?) {
        guard let image else { return }
        image.draw(in: cellFrame,
                   from: .zero,
                   operation: .sourceOver,
                   fraction: 1.0,
                   respectFlipped: true,
                   hints: nil)
    }
}

func ringAttr(pct: Int, size: CGFloat, elapsed: Int?, appearance: NSAppearance) -> NSAttributedString {
    let out = NSMutableAttributedString()
    let attachment = NSTextAttachment()
    let image = ringImage(pct: pct, size: size, elapsed: elapsed, appearance: appearance)
    attachment.image = image
    attachment.attachmentCell = ColoredAttachmentCell(imageCell: image)
    // Vertically center the ring on the text's cap height rather than sitting it
    // on the baseline: without this the attachment grows upward only, so larger
    // rings drift toward the top of the menu bar. The origin is baseline-relative,
    // so offset by half the gap between the image and the cap height.
    let cap = barFont.capHeight
    let dy = (cap - size) / 2
    attachment.bounds = NSRect(x: 0, y: dy, width: size, height: size)
    out.append(NSAttributedString(attachment: attachment))
    return out
}

// Dispatches to the block bar or the ring according to the selected layout, so
// the panel and dropdown render with one call regardless of style. The ring has
// its own fixed pixel sizes (it does not scale with the block `width`, which is
// a character count); `menu` picks the larger ring used in dropdown rows. The
// appearance is threaded through so the ring track can adapt to light/dark.
func progressAttr(pct: Int, width: Int, elapsed: Int?, menu: Bool = false,
                  appearance: NSAppearance) -> NSAttributedString {
    if BAR_STYLE == "ring" {
        let size: CGFloat = menu ? CGFloat(MENU_BAR_W) + 4 : CGFloat(BAR_WIDTH) + 6
        return ringAttr(pct: pct, size: size, elapsed: elapsed, appearance: appearance)
    }
    return barAttr(pct: pct, width: width, elapsed: elapsed)
}

/// Width every row label is padded to, so the bars of one dropdown start in the
/// same column. 12 is the floor every vendor already used; a longer label (Cursor's
/// "Cursor Models") widens the column for its siblings instead of pushing only its
/// own bar to the right. The longest label keeps one trailing space, otherwise its
/// bar or ring touches the text.
func menuLabelWidth(_ labels: [String]) -> Int {
    max(12, (labels.map(\.count).max() ?? 0) + 1)
}

/// Left-pads `text` with spaces to `width` (monospaced rows), so "49%" and "100%"
/// end in the same column and the reset that follows them lines up too.
func rightAligned(_ text: String, width: Int) -> String {
    String(repeating: " ", count: max(0, width - text.count)) + text
}

func subprocessEnvironment() -> [String: String] {
    var env = ProcessInfo.processInfo.environment
    let home = NSHomeDirectory()
    let standardPaths = ["\(home)/.cargo/bin", "\(home)/.local/bin", "/opt/homebrew/bin", "/usr/local/bin"]
    let currentPath = env["PATH"] ?? "/usr/bin:/bin:/usr/sbin:/sbin"
    let currentParts = currentPath.split(separator: ":").map(String.init)
    var allPaths: [String] = []
    for path in standardPaths + currentParts where !allPaths.contains(path) {
        allPaths.append(path)
    }
    env["PATH"] = allPaths.joined(separator: ":")
    return env
}

func resolveBinary(_ name: String) -> String? {
    let fm = FileManager.default
    if name == "ai-usagebar" {
        let configured = DEF.string(forKey: "binaryPath") ?? ""
        if !configured.isEmpty, fm.isExecutableFile(atPath: configured) { return configured }
    }
    let home = NSHomeDirectory()
    for c in ["\(home)/.cargo/bin/\(name)", "\(home)/.local/bin/\(name)", "/opt/homebrew/bin/\(name)", "/usr/local/bin/\(name)"]
    where fm.isExecutableFile(atPath: c) {
        return c
    }
    let p = Process()
    p.executableURL = URL(fileURLWithPath: "/usr/bin/which")
    p.arguments = [name]
    p.environment = subprocessEnvironment()
    let pipe = Pipe()
    p.standardOutput = pipe
    p.standardError = FileHandle.nullDevice
    do {
        try p.run()
        let data = pipe.fileHandleForReading.readDataToEndOfFile()
        p.waitUntilExit()
        let path = String(data: data, encoding: .utf8)?
            .trimmingCharacters(in: .whitespacesAndNewlines) ?? ""
        if !path.isEmpty && fm.isExecutableFile(atPath: path) { return path }
    } catch {}
    return nil
}

struct Window: Equatable {
    let pct: Int
    let reset: String
    let elapsed: Int?
    var unlimited: Bool = false

    init(pct: Int, reset: String, elapsed: Int?, unlimited: Bool = false) {
        self.pct = pct
        self.reset = reset
        self.elapsed = elapsed
        self.unlimited = unlimited
    }
}
struct Snapshot {
    let plan: String
    let hasUsageWindows: Bool
    let creditBalance: String?
    let session: Window?
    let weekly: Window?
    /// The per-model weekly bar (model-scoped window, e.g. Fable, or the legacy
    /// flat sonnet window).
    let sonnet: Window?
    /// Label for that bar: the scoped model name ("Fable") or "Sonnet only".
    let sonnetLabel: String
    let extra: (pct: Int, spent: String, limit: String)?
    /// Antigravity's optional fourth rate-limit window (Claude & GPT OSS
    /// weekly). This is distinct from `extra`, which is a monetary budget.
    var secondaryWeekly: Window? = nil
    var secondaryWeeklyLabel: String = ""
    /// Overridable labels for the session/weekly bars. Default to the
    /// time-window names; a vendor whose two windows aren't time-based (Cursor:
    /// "Cursor Models" / "Other Models") sets its own. Tags are the 2-char
    /// prefixes shown on the compact status bar. Defaulted so every other
    /// vendor's construction is unchanged.
    var sessionTag: String = "5h"
    var weeklyTag: String = "7d"
    var sessionLabel: String = "Session"
    var weeklyLabel: String = "Weekly"
    /// Cursor's combined "included total usage" headline (`totalPercentUsed`),
    /// the single number its dashboard shows across both pools. nil for others.
    var cursorTotalPct: Int? = nil
}

func stripMarkup(_ s: String) -> String {
    // Decode exactly one layer after removing tags. Rust escapes API-controlled
    // labels for Pango; the native surface consumes plain text and must not
    // display those entities literally or reactivate decoded markup.
    s.replacingOccurrences(of: "<[^>]*>", with: "", options: .regularExpression)
        .replacingOccurrences(of: "&lt;", with: "<")
        .replacingOccurrences(of: "&gt;", with: ">")
        .replacingOccurrences(of: "&quot;", with: "\"")
        .replacingOccurrences(of: "&apos;", with: "'")
        .replacingOccurrences(of: "&amp;", with: "&")
}

func parse(_ text: String, vendor: String) -> Snapshot? {
    let f = stripMarkup(text).components(separatedBy: ";;")
    guard f.count >= 10 else { return nil }
    let isAntigravity = vendor == "antigravity"
    func unknownPlaceholder(_ s: String) -> Bool {
        s.hasPrefix("{") && s.hasSuffix("}")
    }
    func t(_ i: Int) -> String {
        guard i >= 0 && i < f.count else { return "" }
        let v = f[i].trimmingCharacters(in: .whitespaces)
        return unknownPlaceholder(v) ? "" : v
    }
    // Do not accept a numeric prefix: a stale suffix such as "27 ⏸" is not elapsed.
    func n(_ i: Int) -> Int? {
        let value = t(i)
        guard value.range(of: "^-?[0-9]+(\\.[0-9]+)?$", options: .regularExpression) != nil else { return nil }
        if let intVal = Int(value) { return intVal }
        if let doubleVal = Double(value) { return Int(doubleVal.rounded()) }
        return nil
    }
    func quotaWindow(_ pctIndex: Int, _ resetIndex: Int, _ elapsedIndex: Int, unlimited: Bool = false) -> Window? {
        guard let pct = n(pctIndex), (0...100).contains(pct) else { return nil }
        let reset = t(resetIndex)
        return Window(
            pct: pct,
            reset: reset,
            elapsed: markerElapsed(reset: reset, elapsed: n(elapsedIndex)),
            unlimited: unlimited)
    }
    // Third bar = the per-model weekly window: a non-empty scoped model is the
    // presence signal. Its reset can legitimately be unavailable, so do not
    // mistake a missing reset for an absent scoped window and show Sonnet.
    let sonnetReset = t(6)
    var sonnet: Window? = nil
    var sonnetLabel = "Sonnet only"
    let scopedReset = t(12)
    let scopedModel = t(10)
    if !scopedModel.isEmpty {
        // A malformed scoped percentage is unavailable too, but must not make
        // us fall back to the unrelated legacy Sonnet window.
        if let p = n(11), (0...100).contains(p) {
            let reset = scopedReset.isEmpty ? "—" : scopedReset
            sonnet = Window(pct: p, reset: reset, elapsed: markerElapsed(reset: reset, elapsed: n(15)))
            sonnetLabel = isAntigravity ? "\(scopedModel) 5h" : scopedModel
        }
    } else if !sonnetReset.isEmpty, sonnetReset != "—", let p = n(5) {
        sonnet = Window(pct: p, reset: sonnetReset, elapsed: nil)
    } else if vendor == "opencode-go" {
        if isReported(t(35)), let w = quotaWindow(34, 35, -1) {
            sonnet = w
            sonnetLabel = "Monthly"
        }
    } else if vendor == "commandcode" {
        if isReported(t(37)), let w = quotaWindow(36, 37, -1) {
            sonnet = w
            sonnetLabel = "Monthly"
        }
    } else if vendor == "copilot" {
        let completionsUnlimited = t(48).lowercased().contains("unlimited")
        if isReported(t(39)), let w = quotaWindow(38, 39, -1, unlimited: completionsUnlimited) {
            sonnet = w
            sonnetLabel = "Completions"
        }
    } else if vendor == "minimax" {
        if isReported(t(42)), let w = quotaWindow(41, 42, 43) {
            sonnet = w
            sonnetLabel = "Video 5h"
        }
    }
    let spent = t(8)
    let limit = t(9)
    let extra: (pct: Int, spent: String, limit: String)? =
        (spent.isEmpty || limit.isEmpty) ? nil : n(7).map { (pct: $0, spent: spent, limit: limit) }
    // Dispatch the balance by the SELECTED vendor, not by vendor_short: binaries
    // up to 0.16 report vendor_short = "kmi" for both Kimi and Moonshot, so
    // keying on vendor_short would collide and read the wrong field.
    let balanceFieldIndex: Int?
    switch vendor {
    case "openrouter": balanceFieldIndex = 17
    case "deepseek": balanceFieldIndex = 18
    case "kilo": balanceFieldIndex = 19
    case "novita": balanceFieldIndex = 20
    case "moonshot": balanceFieldIndex = 21
    case "grok": balanceFieldIndex = 22
    case "anthropic_api": balanceFieldIndex = 23
    case "lyceum": balanceFieldIndex = 52
    case "deepinfra": balanceFieldIndex = 53
    default: balanceFieldIndex = nil
    }
    let balance = balanceFieldIndex.flatMap { t($0).isEmpty ? nil : t($0) }
    // Vendors with no rate-limit windows show only a balance; suppress the fake
    // 5h/7d 0% rows their session_pct/weekly_pct aliases would otherwise paint.
    let balanceOnly = balanceFieldIndex != nil
    // Anthropic API exposes spend-vs-limit instead of a balance, and reports the
    // spend % through the session/weekly aliases. When a limit is configured it
    // becomes an extra ($) bar; otherwise it is balance-only headline display.
    // FORMAT tail: aapi_headline(23) aapi_pct(24) aapi_spent(25) aapi_limit(26).
    let aapiLimit = t(26)
    let aapiExtra: (pct: Int, spent: String, limit: String)?
    if vendor == "anthropic_api", !aapiLimit.isEmpty, aapiLimit != "—",
       let aapiPct = n(24), (0...100).contains(aapiPct), !t(25).isEmpty {
        aapiExtra = (pct: aapiPct, spent: t(25), limit: aapiLimit)
    } else {
        aapiExtra = nil
    }
    // With a limit configured the spend-vs-limit bar replaces the headline, so
    // avoid showing both the "cr" balance and the extra ($) row at once.
    let displayBalance = aapiExtra == nil ? balance : nil
    // Cursor carries its two included-usage pools on the session/weekly
    // aliases (session = Cursor Models, weekly = Other Models — both real, not
    // time windows), so relabel those bars rather than call them "Session"/
    // "Weekly". Every other vendor keeps the default time-window labels.
    let isCursor = vendor == "cursor"
    var sessionWindow = quotaWindow(1, 2, 13)
    let weeklyWindow: Window?
    let sessionTag: String
    let weeklyTag: String
    let sessionLabel: String
    let weeklyLabel: String

    switch vendor {
    case "opencode-go":
        weeklyWindow = quotaWindow(3, 4, 14)
        sessionTag = "5h"
        weeklyTag = "7d"
        sessionLabel = "Session"
        weeklyLabel = "Weekly"
    case "commandcode":
        weeklyWindow = quotaWindow(3, 4, 14)
        sessionTag = "5h"
        weeklyTag = "7d"
        sessionLabel = "Session"
        weeklyLabel = "Weekly"
    case "copilot":
        let chatUnlimited = t(47).lowercased().contains("unlimited")
        let premiumUnlimited = t(49).lowercased().contains("unlimited")
        weeklyWindow = quotaWindow(3, 4, 14, unlimited: chatUnlimited)
        sessionWindow = quotaWindow(1, 2, 13, unlimited: premiumUnlimited)
        sessionTag = "pm"
        weeklyTag = "ch"
        sessionLabel = "Premium"
        weeklyLabel = "Chat"
    case "minimax":
        weeklyWindow = quotaWindow(3, 4, 14)
        sessionTag = "5h"
        weeklyTag = "7d"
        sessionLabel = "Text 5h"
        weeklyLabel = "Text Weekly"
    case "supergrok":
        let period = t(40)
        weeklyWindow = nil
        sessionTag = period == "Monthly" ? "mo" : "7d"
        weeklyTag = "7d"
        sessionLabel = period.isEmpty ? "Usage" : "\(period) usage"
        weeklyLabel = ""
    case "nous":
        weeklyWindow = nil
        sessionTag = "us"
        weeklyTag = "7d"
        sessionLabel = "Usage"
        weeklyLabel = ""
    case "ollama":
        // Monthly-only accounts omit session/weekly (empty placeholders, not
        // "0"). Surface that pool on the primary bar — the title never draws
        // the third/sonnet slot — matching Nous/Kiro's single-pool dispatch.
        // A present window at 0% used still parses as 0.
        if sessionWindow == nil, quotaWindow(3, 4, 14) == nil,
           let monthly = quotaWindow(50, 51, -1) {
            sessionWindow = monthly
            weeklyWindow = nil
            sessionTag = "mo"
            weeklyTag = "7d"
            sessionLabel = "Monthly"
            weeklyLabel = ""
        } else {
            weeklyWindow = quotaWindow(3, 4, 14)
            sessionTag = "5h"
            weeklyTag = "7d"
            sessionLabel = "Session"
            weeklyLabel = "Weekly"
        }
    case "kiro":
        weeklyWindow = nil
        sessionTag = "cr"
        weeklyTag = "7d"
        sessionLabel = "Credits"
        weeklyLabel = ""
    case "cursor":
        weeklyWindow = quotaWindow(3, 4, 14)
        sessionTag = "auto"
        weeklyTag = "premium"
        sessionLabel = "Cursor Models"
        weeklyLabel = "Other Models"
    case "antigravity":
        weeklyWindow = quotaWindow(3, 4, 14)
        sessionTag = "5h"
        weeklyTag = "7d"
        sessionLabel = "Gemini 5h"
        weeklyLabel = "Gemini Weekly"
    case "devin":
        sessionWindow = quotaWindow(54, 55, 56)
        weeklyWindow = quotaWindow(3, 4, 14)
        sessionTag = "1d"
        weeklyTag = "7d"
        sessionLabel = "Daily"
        weeklyLabel = "Weekly"
    default:
        weeklyWindow = quotaWindow(3, 4, 14)
        sessionTag = "5h"
        weeklyTag = "7d"
        sessionLabel = "Session"
        weeklyLabel = "Weekly"
    }

    let secondaryWeekly: Window?
    let secondaryWeeklyLabel: String
    if isAntigravity, !t(28).isEmpty {
        secondaryWeekly = quotaWindow(7, 29, 30)
        secondaryWeeklyLabel = "\(t(28)) Weekly"
    } else if vendor == "zai", isReported(t(32)), let mcp = quotaWindow(31, 32, 33) {
        // Z.AI's monthly MCP-tools pool is a real quota window with its own
        // reset, so it rides the same fourth-window slot Antigravity uses.
        // `{zai_mcp_pct}` flattens an absent pool to "0", so the reset is the
        // presence signal — an account with no MCP quota reports "—" there and
        // must not grow a phantom 0% row.
        secondaryWeekly = mcp
        secondaryWeeklyLabel = "MCP tools"
    } else if vendor == "minimax", isReported(t(45)), let vw = quotaWindow(44, 45, 46) {
        secondaryWeekly = vw
        secondaryWeeklyLabel = "Video Weekly"
    } else {
        secondaryWeekly = nil
        secondaryWeeklyLabel = ""
    }
    return Snapshot(plan: t(0),
                    hasUsageWindows: !balanceOnly,
                    creditBalance: displayBalance,
                    session: sessionWindow,
                    weekly: weeklyWindow,
                    sonnet: sonnet,
                    sonnetLabel: sonnetLabel,
                    extra: aapiExtra ?? extra,
                    secondaryWeekly: secondaryWeekly,
                    secondaryWeeklyLabel: secondaryWeeklyLabel,
                    sessionTag: sessionTag,
                    weeklyTag: weeklyTag,
                    sessionLabel: sessionLabel,
                    weeklyLabel: weeklyLabel,
                    cursorTotalPct: isCursor ? n(27) : nil)
}

// ─── Preferences UI (SwiftUI) ────────────────────────────────────────────
extension Color {
    init(hexString: String) { self.init(nsColor: hexColor(hexString)) }
    var hexString: String {
        let ns = NSColor(self).usingColorSpace(.sRGB) ?? .black
        return String(format: "#%02x%02x%02x",
                      Int((ns.redComponent * 255).rounded()),
                      Int((ns.greenComponent * 255).rounded()),
                      Int((ns.blueComponent * 255).rounded()))
    }
}

struct HexColorPicker: View {
    let title: String
    @Binding var hex: String
    var body: some View {
        ColorPicker(title, selection: Binding(
            get: { Color(hexString: hex) },
            set: { hex = $0.hexString }
        ), supportsOpacity: false)
    }
}

// ─── Vendor login / config (mirrors the GNOME "Vendors" tab) ──────────────
struct VendorCatalogEntry: Codable, Equatable, Identifiable {
    let id: String
    let name: String
    let shortName: String
    let kind: String
    let enabled: Bool
    let configured: Bool
    let needsCredential: Bool
    let env: String
    let login: String

    var cli: String {
        login.split(separator: " ").first.map(String.init) ?? id
    }

    var pkg: String {
        switch id {
        case "anthropic": return "@anthropic-ai/claude-code"
        case "openai": return "@openai/codex"
        default: return ""
        }
    }

    enum CodingKeys: String, CodingKey {
        case id, name, kind, enabled, configured, env, login
        case shortName = "short_name"
        case needsCredential = "needs_credential"
    }
}

typealias VendorAuth = VendorCatalogEntry

struct VendorCatalogPayload: Codable {
    let vendors: [VendorCatalogEntry]
}

func parseVendorCatalog(_ data: Data) -> [VendorCatalogEntry]? {
    guard let payload = try? JSONDecoder().decode(VendorCatalogPayload.self, from: data) else {
        return nil
    }
    return payload.vendors
}

func fetchVendorCatalog(timeout: TimeInterval = REFRESH_TIMEOUT) -> [VendorCatalogEntry]? {
    guard let bin = resolveBinary("ai-usagebar") else { return nil }
    let p = Process()
    p.executableURL = URL(fileURLWithPath: bin)
    p.arguments = ["vendors", "--json"]
    p.environment = subprocessEnvironment()
    let pipe = Pipe()
    p.standardOutput = pipe
    p.standardError = FileHandle.nullDevice

    let watchdog = DispatchWorkItem { if p.isRunning { p.terminate() } }
    DispatchQueue.global(qos: .utility)
        .asyncAfter(deadline: .now() + timeout, execute: watchdog)
    var data = Data()
    do {
        try p.run()
        data = pipe.fileHandleForReading.readDataToEndOfFile()
        p.waitUntilExit()
    } catch {
        watchdog.cancel()
        return nil
    }
    watchdog.cancel()
    guard p.terminationStatus == 0 else { return nil }
    return parseVendorCatalog(data)
}

var vendorCatalog: [VendorCatalogEntry] = []

// The config file the Rust binary would actually read. On macOS
// `directories::ProjectDirs` resolves to ~/Library/Application Support, so
// checking only ~/.config reported "no key configured" for a key the binary
// was happily using. Prefer the canonical location, fall back to the legacy
// Unix path the docs have always shown (the binary accepts both).
func configPathTOML() -> String {
    let appSupport = "\(NSHomeDirectory())/Library/Application Support/ai-usagebar/config.toml"
    if FileManager.default.fileExists(atPath: appSupport) { return appSupport }
    return "\(NSHomeDirectory())/.config/ai-usagebar/config.toml"
}

/// Read a single `key` under `[section]` from TOML text. Pure (no filesystem)
/// so key parsing is testable. Handles quoted strings, bare booleans
/// (`show_default_account = true`), inline comments, and `api_key_env`.
func tomlValueInText(_ text: String, section: String, key: String) -> String? {
    var inSection = false
    for raw in text.split(separator: "\n", omittingEmptySubsequences: false) {
        let line = String(raw).trimmingCharacters(in: .whitespaces)
        if line.hasPrefix("[") {
            inSection = line == "[\(section)]"
            continue
        }
        guard inSection, !line.hasPrefix("#") else { continue }
        let parts = line.split(separator: "=", maxSplits: 1).map(String.init)
        guard parts.count == 2, parts[0].trimmingCharacters(in: .whitespaces) == key else { continue }
        // A `#` starts a comment only outside quotes. Check for a quoted value
        // first so `api_key = "sk-abc#def"` keeps its embedded `#` instead of
        // being truncated into an unterminated string.
        let value = parts[1].trimmingCharacters(in: .whitespaces)
        if let quote = value.first, quote == "\"" || quote == "'" {
            let content = value.dropFirst()
            guard let end = content.firstIndex(of: quote) else { continue }
            return String(content[..<end])
        }
        // Unquoted value: strip a trailing inline comment —
        // `show_default_account = true # per-account` is a bare boolean,
        // not a string starting with '#'.
        var bare = value
        if let hash = bare.firstIndex(of: "#") {
            bare = String(bare[..<hash]).trimmingCharacters(in: .whitespaces)
        }
        // Bare tokens (booleans, numbers) reach here. Only `true`/`false` are
        // meaningful for the keys this reader serves; everything else is left
        // for the caller to ignore.
        return bare
    }
    return nil
}

/// Read a TOML array of quoted strings. This intentionally stays small (the
/// native app is a single dependency-free Swift file), but accepts multiline
/// arrays and rejects malformed values instead of silently widening Overview.
func tomlStringArrayInText(_ text: String, section: String, key: String) -> [String]? {
    func withoutComment(_ line: String) -> String {
        var result = ""
        var quote: Character?
        var escaped = false
        for ch in line {
            if let active = quote {
                result.append(ch)
                if active == "\"", escaped {
                    escaped = false
                } else if active == "\"", ch == "\\" {
                    escaped = true
                } else if ch == active {
                    quote = nil
                }
            } else if ch == "#" {
                break
            } else {
                result.append(ch)
                if ch == "\"" || ch == "'" { quote = ch }
            }
        }
        return result
    }

    func hasClosingBracket(_ value: String) -> Bool {
        var quote: Character?
        var escaped = false
        for ch in value {
            if let active = quote {
                if active == "\"", escaped {
                    escaped = false
                } else if active == "\"", ch == "\\" {
                    escaped = true
                } else if ch == active {
                    quote = nil
                }
            } else if ch == "\"" || ch == "'" {
                quote = ch
            } else if ch == "]" {
                return true
            }
        }
        return false
    }

    var inSection = false
    var rawValue: String?
    for rawLine in text.components(separatedBy: .newlines) {
        let line = withoutComment(rawLine).trimmingCharacters(in: .whitespaces)
        if let current = rawValue {
            let joined = current + " " + line
            rawValue = joined
            if hasClosingBracket(joined) { break }
            continue
        }
        if line.hasPrefix("[") {
            inSection = line == "[\(section)]"
            continue
        }
        guard inSection, !line.isEmpty else { continue }
        let parts = line.split(separator: "=", maxSplits: 1).map(String.init)
        guard parts.count == 2,
              parts[0].trimmingCharacters(in: .whitespaces) == key else { continue }
        let value = parts[1].trimmingCharacters(in: .whitespaces)
        guard value.hasPrefix("[") else { return nil }
        rawValue = value
        if hasClosingBracket(value) { break }
    }

    guard let raw = rawValue, hasClosingBracket(raw) else { return nil }
    let chars = Array(raw)
    guard chars.first == "[" else { return nil }
    var result: [String] = []
    var i = 1

    func skipSpace() {
        while i < chars.count && chars[i].isWhitespace { i += 1 }
    }

    while true {
        skipSpace()
        guard i < chars.count else { return nil }
        if chars[i] == "]" {
            i += 1
            skipSpace()
            return i == chars.count ? result : nil
        }
        let quote = chars[i]
        guard quote == "\"" || quote == "'" else { return nil }
        i += 1
        var value = ""
        var closed = false
        while i < chars.count {
            let ch = chars[i]
            i += 1
            if ch == quote {
                closed = true
                break
            }
            if quote == "\"", ch == "\\", i < chars.count {
                value.append(chars[i])
                i += 1
            } else {
                value.append(ch)
            }
        }
        guard closed else { return nil }
        result.append(value)
        skipSpace()
        guard i < chars.count else { return nil }
        if chars[i] == "," {
            i += 1
            continue
        }
        guard chars[i] == "]" else { return nil }
    }
}

func configValueTOML(_ section: String, _ key: String) -> String? {
    let path = configPathTOML()
    guard let text = try? String(contentsOfFile: path, encoding: .utf8) else { return nil }
    return tomlValueInText(text, section: section, key: key)
}

func configuredOverviewVendorIds() -> [String]? {
    let path = configPathTOML()
    guard let text = try? String(contentsOfFile: path, encoding: .utf8) else { return nil }
    return tomlStringArrayInText(text, section: "ui", key: "overview_vendors")
}

func apiKeyEnvironment(_ v: VendorAuth) -> String {
    configValueTOML(v.id, "api_key_env") ?? v.env
}

// ── Multi-account identities ───────────────────────────────────────────────
// Claude mirrors the Rust side (`src/config.rs`): explicit
// `[[anthropic.accounts]]` entries plus subdirectories of `[anthropic]`
// `accounts_dir`, with explicit labels winning on a clash. Each account is a
// selectable entry with the pseudo-id `anthropic@<label>`, fetched by the
// binary as `--vendor anthropic --account <label>` — the binary resolves the
// account's credentials itself (file or its own Keychain item), so the app
// never needs to know where they live.

/// Account-array labels for one provider, in file order. Pure text scan, like
/// the rest of this app's TOML reading: a `[[provider.accounts]]` header opens
/// a block, and the first `label = "…"` inside it counts.
func accountLabels(inTOML text: String, vendor: String) -> [String] {
    var labels: [String] = []
    var inBlock = false
    let header = "[[\(vendor).accounts]]"
    for rawLine in text.components(separatedBy: .newlines) {
        let line = rawLine.trimmingCharacters(in: .whitespaces)
        if line.hasPrefix("[") {
            inBlock = line == header
            continue
        }
        guard inBlock, line.hasPrefix("label") else { continue }
        let parts = line.split(separator: "=", maxSplits: 1)
        guard parts.count == 2,
              parts[0].trimmingCharacters(in: .whitespaces) == "label" else { continue }
        var value = parts[1].trimmingCharacters(in: .whitespaces)
        if let quote = value.first, quote == "\"" || quote == "'" {
            let content = value.dropFirst()
            guard let end = content.firstIndex(of: quote) else { continue }
            value = String(content[..<end])
        }
        if !value.isEmpty {
            labels.append(value)
            inBlock = false  // one label per block
        }
    }
    return labels
}

func anthropicAccountLabels(inTOML text: String) -> [String] {
    accountLabels(inTOML: text, vendor: "anthropic")
}

/// Immediate subdirectories of `dir`, sorted — the same discovery rule as the
/// Rust `accounts_dir` scan. Credentials may be file- or Keychain-backed.
func discoverAccountLabels(inDir dir: String) -> [String] {
    let fm = FileManager.default
    guard let names = try? fm.contentsOfDirectory(atPath: dir) else { return [] }
    return names.filter { name in
        var isDir: ObjCBool = false
        let sub = "\(dir)/\(name)"
        return fm.fileExists(atPath: sub, isDirectory: &isDir) && isDir.boolValue
    }.sorted()
}

/// Explicit labels first (file order), then discovered ones that don't clash.
func mergedAccountLabels(explicit: [String], discovered: [String]) -> [String] {
    explicit + discovered.filter { !explicit.contains($0) }
}

/// All configured Claude account labels, from the same config the binary reads.
func claudeAccountLabels() -> [String] {
    guard let text = try? String(contentsOfFile: configPathTOML(), encoding: .utf8) else {
        return []
    }
    let explicit = anthropicAccountLabels(inTOML: text)
    var discovered: [String] = []
    if let dir = tomlValueInText(text, section: "anthropic", key: "accounts_dir"), !dir.isEmpty {
        discovered = discoverAccountLabels(inDir: NSString(string: dir).expandingTildeInPath)
    }
    return mergedAccountLabels(explicit: explicit, discovered: discovered)
}

/// The API-key vendors whose config takes a `[[<vendor>.accounts]]` array —
/// Rust's `Config::API_KEY_ACCOUNT_VENDORS`, by slug.
let API_KEY_ACCOUNT_VENDORS = [
    "zai", "openrouter", "deepseek", "deepinfra", "kilo", "novita", "moonshot", "grok", "minimax", "orcarouter", "lyceum",
]

/// Explicit `[[<vendor>.accounts]]` labels for one API-key vendor.
func apiKeyAccountLabels(_ vendor: String) -> [String] {
    guard let text = try? String(contentsOfFile: configPathTOML(), encoding: .utf8) else {
        return []
    }
    return accountLabels(inTOML: text, vendor: vendor)
}

/// Every API-key vendor's named labels, keyed by slug (vendors without any omitted).
func apiKeyAccountLabelsByVendor() -> [String: [String]] {
    guard let text = try? String(contentsOfFile: configPathTOML(), encoding: .utf8) else {
        return [:]
    }
    var out: [String: [String]] = [:]
    for vendor in API_KEY_ACCOUNT_VENDORS {
        let labels = accountLabels(inTOML: text, vendor: vendor)
        if !labels.isEmpty { out[vendor] = labels }
    }
    return out
}

/// Explicit `[[openai.accounts]]` labels; Rust resolves each auth file.
func codexAccountLabels() -> [String] {
    guard let text = try? String(contentsOfFile: configPathTOML(), encoding: .utf8) else {
        return []
    }
    return accountLabels(inTOML: text, vendor: "openai")
}

/// Explicit `[[copilot.accounts]]` labels; Rust resolves each one to a GitHub
/// login and asks `gh` for that account's token (#378).
func copilotAccountLabels() -> [String] {
    guard let text = try? String(contentsOfFile: configPathTOML(), encoding: .utf8) else {
        return []
    }
    return accountLabels(inTOML: text, vendor: "copilot")
}

/// Preferences include enabled providers even before they have credentials.
func preferenceVendorIds(catalog: [VendorCatalogEntry], claude: [String],
                         apiKeyAccounts: [String: [String]], codex: [String],
                         copilot: [String] = []) -> [String] {
    catalog.filter { $0.enabled }.flatMap { vendor -> [String] in
        let labels: [String]
        switch vendor.id {
        case "anthropic": labels = claude
        case "openai": labels = codex
        case "copilot": labels = copilot
        default: labels = apiKeyAccounts[vendor.id] ?? []
        }
        return [vendor.id] + labels.map { vendor.id + "@" + $0 }
    }
}

/// Rust semantics (`show_default_account`): `false` hides an unnamed entry,
/// but is ignored when there are no named accounts, so a vendor never loses
/// its only entry.
func showDefaultAccount(configValue: String?, hasAccounts: Bool) -> Bool {
    guard hasAccounts else { return true }
    return configValue != "false"
}

/// Pseudo-id mapping: `<vendor>@<label>` selects a named account.
let CLAUDE_ACCOUNT_ID_PREFIX = "anthropic@"
// A Claude account whose usage comes from the Desktop app's own token (a saved
// ~/.claude-acc/profiles/<label>), fetched with the widget's `--desktop` flag.
// Distinct prefix so `vendorArgs` knows to pass it; every other helper treats it
// as a Claude account via `accountLabel(of:)`.
let DESKTOP_ACCOUNT_ID_PREFIX = "anthropic-desktop@"

func accountLabel(of id: String) -> String? {
    if id.hasPrefix(DESKTOP_ACCOUNT_ID_PREFIX) {
        return String(id.dropFirst(DESKTOP_ACCOUNT_ID_PREFIX.count))
    }
    guard let separator = id.firstIndex(of: "@") else { return nil }
    let label = String(id[id.index(after: separator)...])
    return label.isEmpty ? nil : label
}

func isDesktopAccountId(_ id: String) -> Bool { id.hasPrefix(DESKTOP_ACCOUNT_ID_PREFIX) }

func baseVendorId(_ id: String) -> String {
    if isDesktopAccountId(id) { return "anthropic" }
    guard let separator = id.firstIndex(of: "@") else { return id }
    return String(id[..<separator])
}

/// The subprocess arguments that select `id` (base vendor or named account).
func vendorArgs(for id: String) -> [String] {
    if let label = accountLabel(of: id) {
        var args = ["--vendor", baseVendorId(id), "--account", label]
        if isDesktopAccountId(id) { args.append("--desktop") }
        return args
    }
    return ["--vendor", id]
}

/// One selectable entry: a base vendor or a named account.
struct MenuEntry {
    let id: String    // "cursor", or "<vendor>@<label>" for a named account
    let name: String  // display: "Cursor" or "Vendor · <label>"
}

func claudeAccountMenuEntries(_ accounts: [UsageAccount]) -> [MenuEntry] {
    accounts.map { account in
        let prefix = account.desktop ? DESKTOP_ACCOUNT_ID_PREFIX : CLAUDE_ACCOUNT_ID_PREFIX
        return MenuEntry(id: prefix + account.label, name: "Claude · \(account.label)")
    }
}

func apiKeyAccountMenuEntries(vendor: VendorCatalogEntry, labels: [String]) -> [MenuEntry] {
    labels.map { MenuEntry(id: vendor.id + "@" + $0, name: "\(vendor.name) · \($0)") }
}

/// Apply `[ui] overview_vendors` with the same semantics as the TUI: preserve
/// config order, omit unavailable vendors, and include every named account
/// when its base vendor is requested.
func filterOverviewEntries(_ entries: [MenuEntry], requested: [String]?) -> [MenuEntry] {
    guard let requested else { return entries }
    var result: [MenuEntry] = []
    var seen = Set<String>()
    for vendor in requested {
        for entry in entries where baseVendorId(entry.id) == vendor && !seen.contains(entry.id) {
            result.append(entry)
            seen.insert(entry.id)
        }
    }
    return result
}

/// The selectable entries, in menu order: every enabled+configured vendor,
/// with Claude, Codex and the API-key vendors expanded into named accounts.
/// Claude and the API-key vendors honor `show_default_account`. `active` stays listed even when
/// unconfigured — same rule the per-vendor list always had.
func vendorEntries(active: String,
                   usageAccounts: [UsageAccount]? = nil,
                   catalog: [VendorCatalogEntry] = vendorCatalog,
                   codexLabels: () -> [String] = codexAccountLabels,
                   copilotLabels: () -> [String] = copilotAccountLabels,
                   apiKeyLabels: (String) -> [String] = apiKeyAccountLabels) -> [MenuEntry] {
    var out: [MenuEntry] = []
    for v in catalog where v.enabled {
        if v.id == "anthropic" {
            // Once account status is available, Rust owns profile-directory
            // resolution and CLI/Desktop dedup. The nil fallback preserves
            // configured CLI accounts with an older binary.
            let accounts = usageAccounts ?? claudeAccountLabels().map {
                UsageAccount(label: $0, desktop: false)
            }
            let showDefault = showDefaultAccount(
                configValue: configValueTOML("anthropic", "show_default_account"),
                hasAccounts: !accounts.isEmpty)
            if showDefault && (v.id == active || v.configured) {
                out.append(MenuEntry(id: v.id, name: v.name))
            }
            out.append(contentsOf: claudeAccountMenuEntries(accounts))
        } else if v.id == "openai" {
            // Named auth files work independently of the default Codex login.
            // Codex has no show_default_account option: keep the existing
            // default-entry visibility rule, then append every named account.
            if v.id == active || v.configured {
                out.append(MenuEntry(id: v.id, name: v.name))
            }
            out.append(contentsOf: codexLabels().map {
                MenuEntry(id: "openai@" + $0, name: "\(v.name) · \($0)")
            })
        } else if v.id == "copilot" {
            // Unlike Codex, Copilot does have show_default_account: the
            // unnamed entry is the active `gh` account, which duplicates
            // whichever named account happens to be active.
            let labels = copilotLabels()
            let showDefault = showDefaultAccount(
                configValue: configValueTOML("copilot", "show_default_account"),
                hasAccounts: !labels.isEmpty)
            if showDefault && (v.id == active || v.configured) {
                out.append(MenuEntry(id: v.id, name: v.name))
            }
            out.append(contentsOf: labels.map {
                MenuEntry(id: "copilot@" + $0, name: "\(v.name) · \($0)")
            })
        } else if API_KEY_ACCOUNT_VENDORS.contains(v.id) {
            let labels = apiKeyLabels(v.id)
            let showDefault = showDefaultAccount(
                configValue: configValueTOML(v.id, "show_default_account"),
                hasAccounts: !labels.isEmpty)
            if showDefault && (v.id == active || v.configured) {
                out.append(MenuEntry(id: v.id, name: v.name))
            }
            out.append(contentsOf: apiKeyAccountMenuEntries(vendor: v, labels: labels))
        } else if v.id == active || v.configured {
            out.append(MenuEntry(id: v.id, name: v.name))
        }
    }
    return out
}

/// Display name for any selectable id (base vendor, account, or overview).
func entryDisplayName(_ id: String, catalog: [VendorCatalogEntry] = vendorCatalog) -> String {
    if id == "overview" { return "Overview" }
    if let label = accountLabel(of: id) {
        let base = baseVendorId(id)
        let vendor = catalog.first { $0.id == base }?.name
            ?? (base == "anthropic" ? "Claude" : (base == "openrouter" ? "OpenRouter" : base))
        return "\(vendor) · \(label)"
    }
    if let name = catalog.first(where: { $0.id == id })?.name {
        return name
    }
    if id == "anthropic" { return "Claude" }
    return id
}

// MARK: - Which account each surface is signed in as
//
// Separate from the vendor entries above: those decide whose usage is *shown*,
// these are who the Claude Desktop app and the `claude` CLI are actually signed
// in as. Both come from `ai-usagebar account status --json`; the binary owns
// every path and credential detail, so this side only parses and displays.

struct AccountStatus: Equatable {
    /// False when there is no Claude Desktop app on this machine. Distinct from
    /// "no accounts saved yet": with the app present but nothing captured, the
    /// submenu still has to appear so the user can add the first one.
    var desktopAvailable = false
    var desktopActive: String?
    var cliActive: String?
    var desktopLabels: [String] = []
    var cliLabels: [String] = []
    /// Canonical Rust/TUI usage enumeration. Nil means an older binary, so the
    /// menu falls back to configured CLI labels; an empty array is authoritative.
    var usageAccounts: [UsageAccount]?
    /// Routines one account deleted that another still holds. A switch would
    /// hand them back, so the user is asked before it starts.
    var deletionConflicts: [DeletionConflict] = []
}

struct UsageAccount: Equatable {
    var label: String
    var desktop: Bool
}

struct DeletionConflict: Equatable {
    /// Opaque, type-scoped value accepted by `--delete-conflict`.
    var key: String
    var id: String
    /// "routine" or "chat" — they are swept differently but answered together.
    var kind: String
    var summary: String
    var deletedBy: String
    var stillIn: [String]

    /// One line for the dialog: what it is, and who dropped it.
    var line: String { "[\(kind)] \(summary) — deleted in \(deletedBy)" }
}

/// Parse `account status --json`. Every field is optional on purpose: a Mac
/// with no Claude Desktop app reports `"desktop": null`, and an older binary
/// may not know the subcommand at all — both must degrade to "no submenus"
/// rather than crash.
func parseAccountStatus(_ data: Data) -> AccountStatus? {
    guard let root = try? JSONSerialization.jsonObject(with: data) as? [String: Any] else {
        return nil
    }
    func labels(_ side: Any?, _ key: String) -> [String] {
        guard let side = side as? [String: Any], let rows = side[key] as? [[String: Any]] else {
            return []
        }
        return rows.compactMap { $0["label"] as? String }
    }
    func active(_ side: Any?) -> String? {
        (side as? [String: Any])?["active_label"] as? String
    }
    let desktop = root["desktop"], cli = root["cli"]
    let usageAccounts: [UsageAccount]?
    if let rows = root["usage_accounts"] as? [[String: Any]] {
        usageAccounts = rows.compactMap { row in
            guard let label = row["label"] as? String,
                  let desktop = row["desktop"] as? Bool else { return nil }
            return UsageAccount(label: label, desktop: desktop)
        }
    } else {
        usageAccounts = nil
    }
    let conflicts = ((desktop as? [String: Any])?["deletion_conflicts"] as? [[String: Any]] ?? [])
        .compactMap { row -> DeletionConflict? in
            guard let id = row["id"] as? String else { return nil }
            let kind = row["kind"] as? String ?? "item"
            guard let key = row["key"] as? String else { return nil }
            return DeletionConflict(key: key,
                                   id: id,
                                   kind: kind,
                                   summary: row["summary"] as? String ?? id,
                                   deletedBy: row["deleted_by"] as? String ?? "?",
                                   stillIn: row["still_in"] as? [String] ?? [])
        }
    return AccountStatus(desktopAvailable: desktop is [String: Any],
                         desktopActive: active(desktop),
                         cliActive: active(cli),
                         desktopLabels: labels(desktop, "profiles"),
                         cliLabels: labels(cli, "accounts"),
                         usageAccounts: usageAccounts,
                         deletionConflicts: conflicts)
}

/// The one dim line under the header. Empty when neither surface resolved, so
/// the caller can hide the row entirely rather than show a bare label.
func accountsSummaryLine(_ s: AccountStatus) -> String {
    var parts: [String] = []
    if !s.desktopLabels.isEmpty { parts.append("Desktop: \(s.desktopActive ?? "?")") }
    if !s.cliLabels.isEmpty { parts.append("Code: \(s.cliActive ?? "?")") }
    return parts.joined(separator: "   ·   ")
}

/// `-y` because the menu has already asked; without it the binary would prompt
/// on a stdin that is not a terminal and abort.
func switchArgs(label: String, desktop: Bool, deleting: [String] = []) -> [String] {
    var args = ["account", "switch", label, desktop ? "--desktop" : "--cli", "-y"]
    // Passing any --delete-conflict also tells the binary the question was
    // already answered, so it never blocks on a prompt it cannot show here.
    for id in deleting { args += ["--delete-conflict", id] }
    return args
}

/// The first few conflicts spelled out, the rest summarised — a switch after a
/// big clean-up must not grow a dialog taller than the screen.
func conflictPreview(_ conflicts: [DeletionConflict], limit: Int = 10) -> String {
    var lines = conflicts.prefix(limit).map { "• \($0.line)" }
    if conflicts.count > limit {
        lines.append("… e mais \(conflicts.count - limit)")
    }
    return lines.joined(separator: "\n")
}

/// Adding an account is interactive — a Desktop capture waits for you to sign
/// in, and a CLI one runs `claude` — so it goes to Terminal rather than being
/// swallowed by a background subprocess. Single-quoted with `'` doubled out,
/// so a label with a quote in it can't break out of the command.
func addAccountScript(binary: String, label: String, desktop: Bool) -> String {
    func quote(_ s: String) -> String { "'" + s.replacingOccurrences(of: "'", with: "'\\''") + "'" }
    return "#!/usr/bin/env bash\n"
        + "\(quote(binary)) account add \(quote(label))\(desktop ? " --desktop" : "")\n"
        + "echo; read -n 1 -s -r -p 'Press any key to close…'\n"
}

func cliInstalled(_ cli: String) -> Bool {
    let home = NSHomeDirectory()
    let fm = FileManager.default
    for dir in ["\(home)/.local/bin", "/opt/homebrew/bin", "/usr/local/bin", "\(home)/.cargo/bin"]
    where fm.isExecutableFile(atPath: "\(dir)/\(cli)") {
        return true
    }
    // Fall back to a login shell (covers nvm etc.).
    let p = Process()
    p.executableURL = URL(fileURLWithPath: "/bin/bash")
    p.arguments = ["-lc", "command -v \(cli)"]
    let pipe = Pipe()
    p.standardOutput = pipe
    p.standardError = FileHandle.nullDevice
    do {
        try p.run()
        let data = pipe.fileHandleForReading.readDataToEndOfFile()
        p.waitUntilExit()
        return !(String(data: data, encoding: .utf8) ?? "")
            .trimmingCharacters(in: .whitespacesAndNewlines).isEmpty
    } catch { return false }
}

// Write a script to a temp file and run it in Terminal.app (no AppleScript quoting hell).
func runInTerminal(_ script: String) {
    let tmp = NSTemporaryDirectory() + "ai-usagebar-\(UUID().uuidString).sh"
    try? script.write(toFile: tmp, atomically: true, encoding: .utf8)
    try? FileManager.default.setAttributes([.posixPermissions: 0o755], ofItemAtPath: tmp)
    let osa = "tell application \"Terminal\" to do script \"bash '\(tmp)'; rm -f '\(tmp)'\"\n" +
        "tell application \"Terminal\" to activate"
    let p = Process()
    p.executableURL = URL(fileURLWithPath: "/usr/bin/osascript")
    p.arguments = ["-e", osa]
    try? p.run()
}

func oauthScript(_ v: VendorAuth) -> String {
    if v.pkg.isEmpty {
        return """
        export PATH="$HOME/.local/bin:/opt/homebrew/bin:/usr/local/bin:$PATH"
        if command -v \(v.cli) >/dev/null 2>&1; then
          \(v.login)
        else
          echo "\(v.cli) not found. Please install \(v.name)."
        fi
        echo
        read -p "Press Enter to close..."
        """
    }
    return """
    export PATH="$HOME/.local/bin:$PATH"
    if command -v \(v.cli) >/dev/null 2>&1; then
      \(v.login)
    else
      echo "\(v.cli) not found. I can install it under ~/.local without sudo. Package: \(v.pkg)"
      read -p "Install now? [y/N] " a
      if [ "$a" = y ] || [ "$a" = Y ]; then npm i -g --prefix "$HOME/.local" \(v.pkg) && hash -r && \(v.login); fi
    fi
    echo
    read -p "Press Enter to close..."
    """
}

func openTuiInTerminal() {
    let cargo = "\(NSHomeDirectory())/.cargo/bin/ai-usagebar-tui"
    let tui = FileManager.default.isExecutableFile(atPath: cargo) ? cargo : "ai-usagebar-tui"
    runInTerminal("\"\(tui)\"\necho\nread -p \"Press Enter to close...\"")
}

// Launch a .app by name (e.g. "Cursor") via `open -a`, so a local-kind vendor's
// button can bring the user to the app they need to sign into.
func openApp(_ name: String) {
    let p = Process()
    p.executableURL = URL(fileURLWithPath: "/usr/bin/open")
    p.arguments = ["-a", name]
    try? p.run()
}

func vendorStatusText(_ v: VendorCatalogEntry, cliPresent: Bool?) -> String {
    if !v.enabled { return v.configured && v.needsCredential ? "Disabled — credential available" : "Disabled" }
    if v.configured { return "✓ Configured" }
    if v.kind == "oauth" {
        if cliPresent == false { return "⚠ \(v.cli) not installed" }
        return "⚠ Not signed in — \(v.login)"
    }
    // Enabled local providers still need their app login.
    if v.id == "antigravity" {
        return "⚠ Open Antigravity (app, IDE or agy)"
    }
    if v.id == "cursor" {
        return "⚠ Sign in to the Cursor app"
    }
    if v.id == "supergrok" {
        return "⚠ Sign in via Grok Build CLI"
    }
    if v.id == "kiro" {
        return "⚠ Sign in to kiro-cli"
    }
    if v.kind == "local" {
        return "⚠ Sign in to \(v.name)"
    }
    return "⚠ No API key — \(apiKeyEnvironment(v))"
}

func vendorButtonLabel(_ v: VendorCatalogEntry, cliPresent: Bool?) -> String {
    if !v.enabled { return "Enable" }
    if v.kind == "oauth" {
        if v.configured { return "Sign in again" }
        if cliPresent == false { return v.pkg.isEmpty ? "Install CLI" : "Install + sign in" }
        return "Sign in"
    }
    if v.id == "antigravity" { return "Open Antigravity" }
    if v.id == "cursor" { return "Open Cursor" }
    if v.id == "kiro" { return "Sign in" }
    if v.kind == "local" { return "Configure (TUI)" }
    return "Configure (TUI)"
}

// Runs off the main thread; stdout contains only the settings acknowledgement.
func enableVendor(binary: String, id: String) -> String? {
    let p = Process()
    p.executableURL = URL(fileURLWithPath: binary)
    p.arguments = ["settings", "enable", id]
    p.environment = subprocessEnvironment()
    p.standardOutput = FileHandle.nullDevice
    p.standardError = FileHandle.nullDevice
    do { try p.run() } catch { return "Could not start ai-usagebar: \(error.localizedDescription)" }
    let watchdog = DispatchWorkItem { if p.isRunning { p.terminate() } }
    DispatchQueue.global().asyncAfter(deadline: .now() + REFRESH_TIMEOUT, execute: watchdog)
    p.waitUntilExit()
    watchdog.cancel()
    return p.terminationStatus == 0 ? nil
        : "Could not enable the provider. Check that the config is writable and valid, and update ai-usagebar if it does not support settings enable."
}

struct VendorsSection: View {
    @State private var catalog: [VendorCatalogEntry] = vendorCatalog
    @State private var cliPresent: [String: Bool] = [:]
    @State private var checking = false
    @State private var enableFailure: String?

    var body: some View {
        GroupBox("Vendors") {
            VStack(alignment: .leading, spacing: 8) {
                ForEach(catalog) { v in
                    HStack(alignment: .firstTextBaseline) {
                        VStack(alignment: .leading, spacing: 2) {
                            Text(v.name)
                            Text(vendorStatusText(v, cliPresent: cliPresent[v.id])).font(.caption).foregroundColor(.secondary)
                        }
                        Spacer()
                        Button(vendorButtonLabel(v, cliPresent: cliPresent[v.id])) { action(v) }
                            .disabled(checking)
                    }
                }
                if let enableFailure {
                    Text(enableFailure).font(.caption).foregroundColor(.red)
                }
                if checking {
                    Text("checking…").font(.caption).foregroundColor(.secondary)
                }
            }
            .frame(maxWidth: .infinity, alignment: .leading)
        }
        .onAppear(perform: refresh)
    }

    private func refresh() {
        checking = true
        DispatchQueue.global(qos: .userInitiated).async {
            let updated = fetchVendorCatalog() ?? vendorCatalog
            var cli: [String: Bool] = [:]
            for v in updated {
                if v.kind == "oauth" { cli[v.id] = cliInstalled(v.cli) }
            }
            DispatchQueue.main.async {
                self.catalog = updated
                vendorCatalog = updated
                self.cliPresent = cli
                self.checking = false
            }
        }
    }

    private func action(_ v: VendorCatalogEntry) {
        enableFailure = nil
        if !v.enabled {
            guard let bin = resolveBinary("ai-usagebar") else {
                enableFailure = "ai-usagebar binary not found. Check Binary path in Preferences."
                return
            }
            checking = true
            DispatchQueue.global(qos: .userInitiated).async {
                let failure = enableVendor(binary: bin, id: v.id)
                DispatchQueue.main.async {
                    self.enableFailure = failure
                    self.refresh()
                }
            }
            return
        }
        if v.kind == "oauth" { runInTerminal(oauthScript(v)) }
        else if v.id == "antigravity" { openApp("Antigravity") }
        else if v.id == "cursor" { openApp("Cursor") }
        else if v.id == "kiro" { runInTerminal("kiro-cli login\necho\nread -p 'Press Enter to close...'") }
        else if v.kind == "local" { openTuiInTerminal() }
        else { openTuiInTerminal() }
        DispatchQueue.main.asyncAfter(deadline: .now() + 4) { refresh() }
    }
}

/// Claude Desktop and Claude Code sign-ins, shown in Preferences rather than
/// the dropdown: most people use one of them or neither, so two permanent menu
/// rows were noise. The delegate owns the actions (they raise alerts and spawn
/// the switch subprocess) and feeds this model; the view only renders it.
final class ClaudeAccountsModel: ObservableObject {
    /// Nil until `account status --json` answers, and for a binary that predates
    /// the subcommand — the section stays hidden in both cases.
    @Published var status: AccountStatus?
    /// A switch quits and reopens another app, so every button waits for it.
    @Published var switching = false
    var switchAccount: (_ label: String, _ desktop: Bool) -> Void = { _, _ in }
    var addAccount: (_ desktop: Bool) -> Void = { _ in }
}

struct ClaudeAccountsSection: View {
    @ObservedObject var model: ClaudeAccountsModel

    var body: some View {
        if let status = model.status {
            GroupBox("Claude accounts") {
                VStack(alignment: .leading, spacing: 14) {
                    // Only a machine with no Claude Desktop app at all loses its
                    // list. With the app present but nothing captured, the empty
                    // list is exactly where "Add account…" matters.
                    if status.desktopAvailable {
                        surface("Claude Desktop", desktop: true,
                                labels: status.desktopLabels, active: status.desktopActive,
                                note: "Switching quits and reopens the app.")
                    }
                    surface("Claude Code", desktop: false,
                            labels: status.cliLabels, active: status.cliActive, note: nil)
                }
                .frame(maxWidth: .infinity, alignment: .leading)
            }
        }
    }

    private func surface(_ title: String, desktop: Bool, labels: [String],
                         active: String?, note: String?) -> some View {
        VStack(alignment: .leading, spacing: 6) {
            Text(title).font(.headline)
            ForEach(labels, id: \.self) { label in
                HStack {
                    Text(label)
                    if label == active {
                        Text("active").font(.caption).foregroundColor(.secondary)
                    }
                    Spacer()
                    if label != active {
                        Button("Switch") { model.switchAccount(label, desktop) }
                            .disabled(model.switching)
                    }
                }
            }
            if labels.isEmpty {
                Text("No accounts saved yet.").font(.caption).foregroundColor(.secondary)
            }
            Button("Add account…") { model.addAccount(desktop) }
                .disabled(model.switching)
            if let note {
                Text(note).font(.caption).foregroundColor(.secondary)
            }
        }
    }
}

struct SettingsView: View {
    @AppStorage("vendor") private var vendor = "anthropic"
    @AppStorage("interval") private var interval = 30.0
    @AppStorage("barWidth") private var barWidth = 8
    @AppStorage("showSession") private var showSession = true
    @AppStorage("showWeekly") private var showWeekly = true
    @AppStorage("showExtra") private var showExtra = false
    @AppStorage("showPercent") private var showPercent = true
    @AppStorage("showBars") private var showBars = true
    @AppStorage("showMeta") private var showMeta = true
    @AppStorage("showResetClock") private var showResetClock = false
    @AppStorage("barStyle") private var barStyle = "block"
    @AppStorage("swapShortcutEnabled") private var swapShortcutEnabled = true
    @AppStorage("compactShortcutEnabled") private var compactShortcutEnabled = true
    @AppStorage("colorLow") private var colorLow = "#98c379"
    @AppStorage("colorMid") private var colorMid = "#e5c07b"
    @AppStorage("colorHigh") private var colorHigh = "#d19a66"
    @AppStorage("colorCritical") private var colorCritical = "#e06c75"
    @AppStorage("colorEmpty") private var colorEmpty = "#3e4451"
    @AppStorage("binaryPath") private var binaryPath = ""
    @State private var launchAtLogin = launchAgentIsInstalled()
    @State private var launchAtLoginError: String?
    @ObservedObject var accounts: ClaudeAccountsModel

    // Only vendors the Rust catalog marks enabled appear in the selector —
    // whatever `vendors --json` reports, so a provider added in Rust (and its
    // opt-in or enabled default) reaches here with no menubar change. Claude,
    // Codex and API-key vendor accounts use `vendor@<label>` pseudo-ids, same
    // as the "Switch provider" submenu.
    private var vendors: [String] {
        preferenceVendorIds(catalog: vendorCatalog, claude: claudeAccountLabels(),
                            apiKeyAccounts: apiKeyAccountLabelsByVendor(),
                            codex: codexAccountLabels(),
                            copilot: copilotAccountLabels())
    }

    var body: some View {
        // A ScrollView (not a Form) so the pane reliably scrolls on every macOS
        // version: on short displays the window can't grow past the screen, and
        // a plain Form clipped its top rows with no way to reach them.
        ScrollView(.vertical) {
            VStack(alignment: .leading, spacing: 18) {
                GroupBox("Display") {
                    VStack(alignment: .leading, spacing: 8) {
                        Toggle("Show 5h (session) bar", isOn: $showSession)
                        Toggle("Show weekly bar", isOn: $showWeekly)
                        Toggle("Show extra usage bar ($)", isOn: $showExtra)
                        Toggle("Show percentage/value", isOn: $showPercent)
                        Toggle("Show bars (off = numbers only)", isOn: $showBars)
                        Toggle("Show pace reference line", isOn: $showMeta)
                        Toggle("Show reset time instead of a countdown", isOn: $showResetClock)
                        Picker("Indicator style", selection: $barStyle) {
                            Text("Bars (░█)").tag("block")
                            Text("Ring (○)").tag("ring")
                        }
                        Stepper("Bar width: \(barWidth)", value: $barWidth, in: 4...20)
                    }
                    .frame(maxWidth: .infinity, alignment: .leading)
                }
                GroupBox("Shortcut") {
                    VStack(alignment: .leading, spacing: 4) {
                        Toggle("Switch provider with ⌥⌘\\ (global shortcut)", isOn: $swapShortcutEnabled)
                        Text("Switches the active provider from any app.")
                            .font(.caption).foregroundColor(.secondary)
                        Toggle("Collapse/Expand with ⌥⌘E (global shortcut)", isOn: $compactShortcutEnabled)
                        Text("Switches the Overview between bars and compact mode.")
                            .font(.caption).foregroundColor(.secondary)
                    }
                    .frame(maxWidth: .infinity, alignment: .leading)
                }
                GroupBox("Colours") {
                    VStack(alignment: .leading, spacing: 8) {
                        HexColorPicker(title: "Low (<50%)", hex: $colorLow)
                        HexColorPicker(title: "Medium (50–74%)", hex: $colorMid)
                        HexColorPicker(title: "High (75–89%)", hex: $colorHigh)
                        HexColorPicker(title: "Critical (≥90%)", hex: $colorCritical)
                        HexColorPicker(title: "Empty (bar background)", hex: $colorEmpty)
                    }
                    .frame(maxWidth: .infinity, alignment: .leading)
                }
                GroupBox("Data") {
                    VStack(alignment: .leading, spacing: 8) {
                        Picker("Vendor", selection: $vendor) {
                            ForEach(vendors, id: \.self) { Text($0) }
                        }
                        Stepper("Intervalo: \(Int(interval))s", value: $interval, in: 5...3600, step: 5)
                        TextField("Binary path (empty = auto)", text: $binaryPath)
                    }
                    .frame(maxWidth: .infinity, alignment: .leading)
                }
                GroupBox("System") {
                    VStack(alignment: .leading, spacing: 4) {
                        Toggle("Start at login", isOn: Binding(
                            get: { launchAtLogin },
                            set: { enabled in
                                do {
                                    try setLaunchAtLogin(enabled)
                                    launchAtLogin = launchAgentIsInstalled()
                                    launchAtLoginError = nil
                                } catch {
                                    launchAtLogin = launchAgentIsInstalled()
                                    launchAtLoginError = error.localizedDescription
                                }
                            }))
                        Text("Installs a LaunchAgent that starts the app when you log in.")
                            .font(.caption).foregroundColor(.secondary)
                        if let error = launchAtLoginError {
                            Text("Could not refresh: \(error)")
                                .font(.caption).foregroundColor(.red)
                        }
                    }
                    .frame(maxWidth: .infinity, alignment: .leading)
                }
                ClaudeAccountsSection(model: accounts)
                VendorsSection()
            }
            .padding(20)
            .frame(maxWidth: .infinity, alignment: .leading)
        }
        .frame(width: 460)
        .frame(minHeight: 300, idealHeight: 560, maxHeight: .infinity)
        .onAppear { launchAtLogin = launchAgentIsInstalled() }
    }
}

// ─── Launch at login (macOS LaunchAgent) ─────────────────────────────────
//
// The app is an unbundled single binary, so the modern SMAppService.mainApp
// API (which needs a bundle id) doesn't apply. A per-user LaunchAgent is the
// portable way to start an unbundled executable at login — the same mechanism
// install-agent.sh sets up, now toggleable from Preferences.
let LAUNCH_AGENT_LABEL = "com.akitaonrails.ai-usagebar-menubar"

func launchAgentPlistPath() -> String {
    "\(NSHomeDirectory())/Library/LaunchAgents/\(LAUNCH_AGENT_LABEL).plist"
}

func launchAgentIsInstalled() -> Bool {
    FileManager.default.fileExists(atPath: launchAgentPlistPath())
}

/// Absolute path of the running executable, for the LaunchAgent to relaunch.
func selfExecutablePath() -> String {
    if let p = Bundle.main.executablePath, !p.isEmpty { return p }
    let arg0 = CommandLine.arguments.first ?? "ai-usagebar-menubar"
    if arg0.hasPrefix("/") { return arg0 }
    return URL(fileURLWithPath: FileManager.default.currentDirectoryPath)
        .appendingPathComponent(arg0).standardized.path
}

/// Install (or remove) the login LaunchAgent by managing its plist file.
/// Building the plist via PropertyListSerialization sidesteps the XML-escaping
/// the shell installer has to do by hand.
///
/// Deliberately no `launchctl load`/`unload`: the app is already running when
/// this is toggled, so `RunAtLoad` on load would spawn a *second* copy, and
/// `unload` on disable would SIGTERM this very process (quitting the app the
/// user is still using) if it happened to be the launchd-managed one. launchd
/// loads every agent in ~/Library/LaunchAgents at the next login, so writing
/// (or removing) the file is all that's needed for a start-at-login toggle.
func launchAgentPlist(executable: String) throws -> Data {
    let plist: [String: Any] = [
        "Label": LAUNCH_AGENT_LABEL,
        "ProgramArguments": [executable],
        "RunAtLoad": true,
        "ProcessType": "Interactive",
    ]
    return try PropertyListSerialization.data(
        fromPropertyList: plist, format: .xml, options: 0)
}

func setLaunchAtLogin(_ enabled: Bool) throws {
    let path = launchAgentPlistPath()
    if enabled {
        let dir = (path as NSString).deletingLastPathComponent
        try FileManager.default.createDirectory(atPath: dir, withIntermediateDirectories: true)
        let data = try launchAgentPlist(executable: selfExecutablePath())
        try data.write(to: URL(fileURLWithPath: path), options: .atomic)
    } else if FileManager.default.fileExists(atPath: path) {
        try FileManager.default.removeItem(atPath: path)
    }
}

// ─── App ─────────────────────────────────────────────────────────────────
// ─── Global vendor-swap shortcut (⌥⌘\) ───────────────────────────────────
//
// A menu-bar app has no focused window, so a system-wide shortcut needs a
// Carbon hot key (RegisterEventHotKey), which fires regardless of focus and —
// unlike an NSEvent global monitor — needs no Accessibility permission. The
// Carbon handler is a C callback that can't capture Swift state, so it just
// posts a notification the delegate observes.

let swapHotKeyNotification = Notification.Name("aiusagebar.swapHotKey")
let compactHotKeyNotification = Notification.Name("aiusagebar.compactHotKey")

/// Default shortcuts: `\` (kVK_ANSI_Backslash) with Command+Option swaps the
/// vendor; `E` with Command+Option toggles the overview's Collapse/Expand.
/// `[ui]` on Linux has no equivalent; this is macOS-only.
let SWAP_HOTKEY_KEYCODE = UInt32(kVK_ANSI_Backslash)
let COMPACT_HOTKEY_KEYCODE = UInt32(kVK_ANSI_E)
let SWAP_HOTKEY_MODIFIERS = UInt32(cmdKey | optionKey)

/// Registered hot-key ids, carried back to us in the event so one shared C
/// callback can tell which shortcut fired.
let SWAP_HOTKEY_ID = UInt32(1)
let COMPACT_HOTKEY_ID = UInt32(2)

private func swapHotKeyCallback(
    _ next: EventHandlerCallRef?, _ event: EventRef?, _ userData: UnsafeMutableRawPointer?
) -> OSStatus {
    var hk = EventHotKeyID()
    GetEventParameter(event, EventParamName(kEventParamDirectObject),
                      EventParamType(typeEventHotKeyID), nil,
                      MemoryLayout<EventHotKeyID>.size, nil, &hk)
    NotificationCenter.default.post(
        name: hk.id == COMPACT_HOTKEY_ID ? compactHotKeyNotification : swapHotKeyNotification,
        object: nil)
    return noErr
}

/// Whether the overview status-bar title draws mini bars (vs. the compact
/// %-text mode). "Collapse" forces the text mode even under the bars-count
/// threshold. Pure + testable — the render path is not.
func overviewUsesBars(count: Int, barsMax: Int, compact: Bool) -> Bool {
    !compact && count <= barsMax
}

/// Provider ids the user toggled out of the always-visible top-bar summary in
/// Overview mode. The dropdown still lists them (unchecked + dimmed) so they can
/// be turned back on. Persisted in UserDefaults; absent key → nothing hidden.
func overviewHiddenProviders() -> Set<String> {
    Set(DEF.stringArray(forKey: "overviewHiddenProviders") ?? [])
}

func setOverviewProvider(_ id: String, hidden: Bool) {
    var hiddenSet = overviewHiddenProviders()
    if hidden { hiddenSet.insert(id) } else { hiddenSet.remove(id) }
    DEF.set(hiddenSet.sorted(), forKey: "overviewHiddenProviders")
}

/// The ids that survive the top-bar filter, in their original order. Pure +
/// testable — the render path (which also drops nil snapshots) is not.
func overviewVisibleIds(_ ids: [String], hidden: Set<String>) -> [String] {
    ids.filter { !hidden.contains($0) }
}

/// The next id in the cycle, wrapping. `current` absent from `ids` (e.g. the
/// selected vendor was disabled) starts at the first (or last, backward).
/// Pure + testable — the hot-key handler is not.
func nextVendorId(current: String, in ids: [String], forward: Bool = true) -> String? {
    guard !ids.isEmpty else { return nil }
    let n = ids.count
    let i = ids.firstIndex(of: current) ?? (forward ? -1 : 0)
    let j = forward ? (i + 1) % n : (i - 1 + n) % n
    return ids[j]
}

func hotKeyRegistrationSucceeded(_ status: OSStatus) -> Bool {
    status == noErr
}

class AppDelegate: NSObject, NSApplicationDelegate, NSMenuDelegate {
    var statusItem: NSStatusItem!
    var swapHotKeyRef: EventHotKeyRef?
    var compactHotKeyRef: EventHotKeyRef?
    var swapHotKeyHandlerInstalled = false
    var timer: Timer?
    var prefsWindow: NSWindow?
    var appearanceObservation: NSKeyValueObservation?
    /// Last resolved light/dark name, so the appearance observer ignores the
    /// layout-driven KVO fires that don't actually change the theme.
    var lastAppearanceName: NSAppearance.Name?
    /// Tracks the active vendor so `settingsChanged` can tell a vendor swap (show
    /// Loading) apart from an unrelated preference change (repaint from cache).
    var lastVendor = ""
    var lastSnapshot: Snapshot?
    var pendingRefresh: DispatchWorkItem?
    /// Live watch on config.toml so external edits (a text editor, the TUI's
    /// Settings overlay, `ai-usagebar account add`) hot-reload
    /// the vendor list without restarting the app. The fd is closed by the
    /// source's cancel handler; `pendingConfigReload` coalesces an editor's
    /// burst of vnode events into a single reload.
    var configWatchSource: DispatchSourceFileSystemObject?
    var configWatchFD: CInt = -1
    var pendingConfigReload: DispatchWorkItem?
    /// A visibility checkbox changes presentation only. Its UserDefaults
    /// notification should repaint from cache without restarting the timer or
    /// launching a fresh round of provider subprocesses.
    var overviewVisibilityChangePending = false
    /// Bumped on every refresh attempt. A result whose generation is no longer
    /// current belongs to a superseded attempt — most often the previously
    /// selected vendor — and must not be rendered. Without this, the timer,
    /// the Preferences window and a vendor change could each start their own
    /// subprocess and whichever finished last won, regardless of what the user
    /// had actually selected. Main-thread only.
    var refreshGeneration: Int = 0
    /// At most one subprocess in flight; a request arriving while one runs is
    /// coalesced rather than stacked.
    var refreshInFlight = false
    var refreshQueued = false
    let headerItem = NSMenuItem()
    var rows: [String: NSMenuItem] = [:]
    // Overview mode fills these (one per vendor/account); hidden in
    // single-vendor mode. The pool starts at the built-in vendor count and can
    // grow if account discovery adds more rows.
    var overviewRows: [NSMenuItem] = []
    /// Last overview fetch, so a settings/appearance change re-renders it without
    /// flashing the stale single-vendor snapshot.
    var lastOverview: [(name: String, id: String, snap: Snapshot?)]?
    // Rebuilt on every render so only configured vendors show, and the active
    // one is checked. Kept as a field so the menu owns it for its lifetime.
    let vendorSubmenu = NSMenu()
    let vendorSubmenuItem = NSMenuItem(title: "Switch provider", action: nil, keyEquivalent: "")
    /// Overview-only: forces the status-bar title into the compact %-text mode
    /// ("Collapse"); while compact it reads "Expand" and turns it back off.
    let compactItem = NSMenuItem(title: "Collapse", action: nil, keyEquivalent: "")
    /// Which account each surface is signed in as: one dim line under the
    /// header, hidden until `account status --json` answers so an older binary
    /// that doesn't know the subcommand shows the menu it always did. Switching
    /// and adding live in Preferences, through `accounts`.
    let accountsInfoItem = NSMenuItem()
    let accounts = ClaudeAccountsModel()
    var lastAccountStatus: AccountStatus?
    var accountStatusFetchedAt = Date.distantPast
    var accountStatusGeneration = 0
    var vendorCatalogGeneration = 0
    /// A switch runs a subprocess that quits and reopens another app; the
    /// Preferences buttons grey out until it returns so it cannot be fired twice.
    var accountSwitchInFlight = false
    var refreshOverride: (() -> Void)?

    @discardableResult
    func applyVendorCatalog(_ catalog: [VendorCatalogEntry], generation: Int) -> Bool {
        guard generation == vendorCatalogGeneration else { return false }
        vendorCatalog = catalog
        rebuildVendorSubmenu()
        if VENDOR == "overview" {
            refresh()
        }
        return true
    }

    func updateVendorCatalog(fetcher: @escaping () -> [VendorCatalogEntry]? = { fetchVendorCatalog() },
                             completion: (() -> Void)? = nil) {
        vendorCatalogGeneration += 1
        let generation = vendorCatalogGeneration
        DispatchQueue.global(qos: .utility).async { [weak self] in
            guard let fetched = fetcher() else { return }
            DispatchQueue.main.async {
                guard let self = self else { return }
                self.applyVendorCatalog(fetched, generation: generation)
                completion?()
            }
        }
    }

    func applicationDidFinishLaunching(_ notification: Notification) {
        DEF.register(defaults: ["swapShortcutEnabled": true, "compactShortcutEnabled": true])
        statusItem = NSStatusBar.system.statusItem(withLength: NSStatusItem.variableLength)
        statusItem.button?.title = "5h …"
        accounts.switchAccount = { [weak self] label, desktop in
            if desktop { self?.switchDesktopAccount(to: label) }
            else { self?.switchCliAccount(to: label) }
        }
        accounts.addAccount = { [weak self] desktop in self?.addAccount(desktop: desktop) }
        buildMenu()
        rebuildVendorSubmenu()
        updateVendorCatalog()
        observeAppearanceChanges()
        lastVendor = VENDOR  // so the first settingsChanged isn't mistaken for a swap
        refresh()
        restartTimer()
        NotificationCenter.default.addObserver(
            self, selector: #selector(settingsChanged),
            name: UserDefaults.didChangeNotification, object: nil)
        NotificationCenter.default.addObserver(
            self, selector: #selector(handleSwapHotKey),
            name: swapHotKeyNotification, object: nil)
        NotificationCenter.default.addObserver(
            self, selector: #selector(handleCompactHotKey),
            name: compactHotKeyNotification, object: nil)
        installSwapHotKey()
        installCompactHotKey()
        installConfigWatch()
        fetchAccountStatus()
    }

    /// Watch config.toml and hot-reload the vendor list when it changes on disk.
    /// Editors usually save atomically (write a temp file, then rename it over
    /// the target), which unlinks the inode our descriptor points at — so a
    /// `.delete`/`.rename` event means "re-open the path to keep watching the
    /// new file". A plain in-place write (`>>`, some editors) fires `.write` on
    /// the same descriptor. Idempotent: always tears down the previous watch.
    func installConfigWatch() {
        removeConfigWatch()
        let path = configPathTOML()
        let fd = open(path, O_EVTONLY)
        guard fd >= 0 else {
            // No readable file yet (not created, or momentarily gone between an
            // editor's unlink and rename). Retry shortly so a config created
            // after launch — or a non-atomic save's brief gap — is still picked
            // up. ponytail: a fixed 3s retry, not exponential backoff; this only
            // spins in the rare window before the file exists.
            DispatchQueue.main.asyncAfter(deadline: .now() + 3) { [weak self] in
                self?.installConfigWatch()
            }
            return
        }
        let src = DispatchSource.makeFileSystemObjectSource(
            fileDescriptor: fd, eventMask: [.write, .extend, .delete, .rename, .attrib],
            queue: .main)
        src.setEventHandler { [weak self] in
            guard let self, let flags = self.configWatchSource?.data else { return }
            self.scheduleConfigReload()
            // The watched inode was replaced; re-arm on whatever is at the path
            // now so future edits keep firing.
            if flags.contains(.delete) || flags.contains(.rename) {
                self.installConfigWatch()
            }
        }
        src.setCancelHandler { close(fd) }
        configWatchFD = fd
        configWatchSource = src
        src.resume()
    }

    func removeConfigWatch() {
        configWatchSource?.cancel()  // the cancel handler closes the fd
        configWatchSource = nil
        configWatchFD = -1
    }

    /// Coalesce the burst of vnode events a save emits (write → rename → attrib)
    /// into one reload a beat later, mirroring `settingsChanged`'s debounce.
    func scheduleConfigReload() {
        pendingConfigReload?.cancel()
        let work = DispatchWorkItem { [weak self] in self?.configFileChanged() }
        pendingConfigReload = work
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.3, execute: work)
    }

    /// A config.toml edit landed: rebuild the vendor submenu/ring, re-render the
    /// current view from cache so an `[ui]` tweak shows at once, then debounce a
    /// full refresh to fetch any newly-added vendor/account. Reads are all fresh
    /// from disk (nothing caches config.toml), so no invalidation is needed.
    @objc func configFileChanged() {
        updateVendorCatalog()
        rebuildVendorSubmenu()
        // A new [[anthropic.accounts]] entry changes the Claude Code list.
        fetchAccountStatus()
        if VENDOR == "overview" {
            if let ov = lastOverview { renderOverview(ov) }
        } else if let s = lastSnapshot {
            renderPanel(s); renderMenu(s)
        }
        pendingRefresh?.cancel()
        let work = DispatchWorkItem { [weak self] in self?.refresh() }
        pendingRefresh = work
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.6, execute: work)
    }

    /// (Re)register the global ⌥⌘\ hot key to match the `swapShortcutEnabled`
    /// preference. Idempotent: always unregisters first.
    func installSwapHotKey() {
        guard removeSwapHotKey() else {
            // The old registration is still live; reflect that instead of
            // showing a disabled toggle that continues intercepting the key.
            DEF.set(true, forKey: "swapShortcutEnabled")
            return
        }
        let enabled = DEF.bool(forKey: "swapShortcutEnabled")
        // Mirror the swap shortcut as a hint on the "Switch provider" item. A native
        // keyEquivalent is suppressed by the submenu's disclosure arrow, so paint
        // the hint into the title instead (right-aligned, dimmed). Cleared when off.
        if enabled {
            // Inline, dimmed hint right after the label. A right-aligned column
            // (like the other items' ⌘R) isn't possible here: the submenu arrow
            // takes the trailing slot, and a fixed tab stop would over-widen the
            // menu whenever the wide overview rows are hidden.
            let font = NSFont.menuFont(ofSize: 0)
            let s = NSMutableAttributedString(
                string: "Switch provider  ", attributes: [.font: font])
            s.append(NSAttributedString(string: "⌥⌘\\", attributes: [
                .font: font, .foregroundColor: NSColor.tertiaryLabelColor,
            ]))
            vendorSubmenuItem.attributedTitle = s
        } else {
            vendorSubmenuItem.attributedTitle = NSAttributedString(string: "Switch provider")
        }
        guard enabled else { return }
        guard installHotKeyHandlerOnce() else {
            disableFailedShortcut("swapShortcutEnabled", name: "⌥⌘\\")
            vendorSubmenuItem.attributedTitle = NSAttributedString(string: "Switch provider")
            return
        }
        let id = EventHotKeyID(signature: OSType(0x4149_4242), id: SWAP_HOTKEY_ID)  // 'AIBB'
        var ref: EventHotKeyRef?
        let status = RegisterEventHotKey(
            SWAP_HOTKEY_KEYCODE, SWAP_HOTKEY_MODIFIERS, id, GetApplicationEventTarget(), 0,
            &ref)
        guard hotKeyRegistrationSucceeded(status), let ref else {
            if let ref { UnregisterEventHotKey(ref) }
            disableFailedShortcut("swapShortcutEnabled", name: "⌥⌘\\", status: status)
            vendorSubmenuItem.attributedTitle = NSAttributedString(string: "Switch provider")
            return
        }
        swapHotKeyRef = ref
    }

    /// (Re)register the global ⌥⌘E Collapse/Expand hot key to match the
    /// `compactShortcutEnabled` preference. Idempotent, mirroring
    /// `installSwapHotKey` — including the painted-in hint (a native
    /// keyEquivalent would fire a second time while the menu is open, double-
    /// toggling on one press).
    func installCompactHotKey() {
        guard removeCompactHotKey() else {
            DEF.set(true, forKey: "compactShortcutEnabled")
            return
        }
        updateCompactItemTitle()
        guard DEF.bool(forKey: "compactShortcutEnabled") else { return }
        guard installHotKeyHandlerOnce() else {
            disableFailedShortcut("compactShortcutEnabled", name: "⌥⌘E")
            updateCompactItemTitle()
            return
        }
        let id = EventHotKeyID(signature: OSType(0x4149_4242), id: COMPACT_HOTKEY_ID)
        var ref: EventHotKeyRef?
        let status = RegisterEventHotKey(
            COMPACT_HOTKEY_KEYCODE, SWAP_HOTKEY_MODIFIERS, id, GetApplicationEventTarget(), 0,
            &ref)
        guard hotKeyRegistrationSucceeded(status), let ref else {
            if let ref { UnregisterEventHotKey(ref) }
            disableFailedShortcut("compactShortcutEnabled", name: "⌥⌘E", status: status)
            updateCompactItemTitle()
            return
        }
        compactHotKeyRef = ref
    }

    /// Collapse ↔ Expand label plus the dimmed ⌥⌘E hint when the global
    /// shortcut is on. Shared by the overview render and the hot-key installer.
    func updateCompactItemTitle() {
        let label = DEF.bool(forKey: "overviewCompact") ? "Expand" : "Collapse"
        guard DEF.bool(forKey: "compactShortcutEnabled") else {
            compactItem.attributedTitle = NSAttributedString(string: label)
            return
        }
        let font = NSFont.menuFont(ofSize: 0)
        let s = NSMutableAttributedString(string: "\(label)  ", attributes: [.font: font])
        s.append(NSAttributedString(string: "⌥⌘E", attributes: [
            .font: font, .foregroundColor: NSColor.tertiaryLabelColor,
        ]))
        compactItem.attributedTitle = s
    }

    /// One Carbon handler serves every hot key; the event's EventHotKeyID
    /// says which one fired.
    private func installHotKeyHandlerOnce() -> Bool {
        guard !swapHotKeyHandlerInstalled else { return true }
        var spec = EventTypeSpec(
            eventClass: OSType(kEventClassKeyboard), eventKind: UInt32(kEventHotKeyPressed))
        let status = InstallEventHandler(
            GetApplicationEventTarget(), swapHotKeyCallback, 1, &spec, nil, nil)
        guard hotKeyRegistrationSucceeded(status) else {
            NSLog("ai-usagebar: global hot-key handler registration failed (OSStatus %d)", status)
            return false
        }
        swapHotKeyHandlerInstalled = true
        return true
    }

    private func disableFailedShortcut(_ key: String, name: String,
                                       status: OSStatus? = nil) {
        if let status {
            NSLog("ai-usagebar: global shortcut %@ registration failed (OSStatus %d)",
                  name, status)
        } else {
            NSLog("ai-usagebar: global shortcut %@ registration failed", name)
        }
        // Keep the visible preference honest when another app already owns the
        // shortcut or Carbon refuses the registration.
        DEF.set(false, forKey: key)
    }

    @discardableResult
    func removeSwapHotKey() -> Bool {
        if let ref = swapHotKeyRef {
            let status = UnregisterEventHotKey(ref)
            guard hotKeyRegistrationSucceeded(status) else {
                NSLog("ai-usagebar: could not unregister ⌥⌘\\ (OSStatus %d)", status)
                return false
            }
            swapHotKeyRef = nil
        }
        return true
    }

    @discardableResult
    private func removeCompactHotKey() -> Bool {
        if let ref = compactHotKeyRef {
            let status = UnregisterEventHotKey(ref)
            guard hotKeyRegistrationSucceeded(status) else {
                NSLog("ai-usagebar: could not unregister ⌥⌘E (OSStatus %d)", status)
                return false
            }
            compactHotKeyRef = nil
        }
        return true
    }

    /// Advance the active vendor to the next configured one, wrapping. Fired by
    /// the global hot key; sets `vendor` in defaults, which drives the usual
    /// re-render via `settingsChanged`.
    @objc func handleSwapHotKey() {
        if let next = nextVendorId(current: VENDOR, in: swapCycleIds()) {
            DEF.set(next, forKey: "vendor")
        }
    }

    /// ⌥⌘E: toggle Collapse/Expand. Overview-only — flipping a hidden
    /// preference from another view would be invisible and confusing.
    @objc func handleCompactHotKey() {
        guard VENDOR == "overview" else { return }
        toggleCompact()
    }

    /// The swap-shortcut ring: every configured entry (vendors *and* Claude
    /// accounts) plus the synthetic "overview" target, so ⌥⌘\ cycles them all.
    func swapCycleIds() -> [String] {
        var ids = vendorEntries(active: VENDOR,
                                usageAccounts: lastAccountStatus?.usageAccounts).map { $0.id }
        ids.append("overview")
        return ids
    }

    func buildMenu() {
        let menu = NSMenu()
        menu.autoenablesItems = false

        menu.addItem(headerItem)
        // Reads as a sub-line of the header, so it sits above the usage rows.
        accountsInfoItem.isEnabled = false
        accountsInfoItem.isHidden = true
        menu.addItem(accountsInfoItem)
        // One hidden slot per built-in vendor for Overview mode. Named accounts
        // can take the total higher; renderOverview grows the pool on demand.
        for _ in 0..<vendorCatalog.count {
            let it = NSMenuItem()
            it.isHidden = true
            overviewRows.append(it)
            menu.addItem(it)
        }
        for key in ["session", "weekly", "sonnet", "extra"] {
            let it = NSMenuItem()
            rows[key] = it
            menu.addItem(it)
        }
        // First item after the usage rows, Overview-only (hidden elsewhere).
        compactItem.action = #selector(toggleCompact)
        compactItem.target = self
        compactItem.isHidden = true
        menu.addItem(compactItem)

        menu.addItem(.separator())
        addAction(menu, "Refresh now", #selector(refreshAction), "r")
        addAction(menu, "Open TUI", #selector(openTui), "t")
        vendorSubmenuItem.submenu = vendorSubmenu
        menu.addItem(vendorSubmenuItem)
        addAction(menu, "Preferences…", #selector(openPrefs), ",")
        menu.addItem(.separator())
        addAction(menu, "Quit", #selector(quit), "q")

        // Catches a switch made elsewhere (a terminal, claude-acc) without
        // polling for state that changes at most a few times a day.
        menu.delegate = self
        statusItem.menu = menu
    }

    func menuWillOpen(_ menu: NSMenu) {
        if Date().timeIntervalSince(accountStatusFetchedAt) >= 5 { fetchAccountStatus() }
    }

    func addAction(_ menu: NSMenu, _ title: String, _ sel: Selector, _ key: String) {
        let it = NSMenuItem(title: title, action: sel, keyEquivalent: key)
        it.target = self
        menu.addItem(it)
    }

    @objc func refreshAction() { refresh() }
    @objc func quit() { NSApp.terminate(nil) }

    /// Flip the overview's compact mode; the UserDefaults observer re-renders,
    /// which also relabels the item (Collapse ↔ Expand).
    @objc func toggleCompact() {
        DEF.set(!DEF.bool(forKey: "overviewCompact"), forKey: "overviewCompact")
    }

    @objc func openPrefs() {
        if prefsWindow == nil {
            let host = NSHostingController(rootView: SettingsView(accounts: accounts))
            // Install the host view directly so this window owns its size on
            // macOS 12 as well. The SwiftUI ScrollView still fills the
            // resizable content area without expanding it to its full height.
            let avail = NSScreen.main?.visibleFrame.height ?? 700
            let initialSize = NSSize(width: 460, height: min(560, avail - 40))
            let w = NSWindow(contentRect: NSRect(origin: .zero, size: initialSize),
                             styleMask: [.titled, .closable, .resizable],
                             backing: .buffered,
                             defer: false)
            w.contentViewController = host
            w.title = "AI Usage Bar — Preferences"
            // Resizable so the content can always be reached; a min size keeps
            // it usable, and the initial height is clamped to the visible screen
            // so the top never lands under the menu bar on short displays.
            w.contentMinSize = NSSize(width: 460, height: 360)
            w.setContentSize(initialSize)
            w.isReleasedWhenClosed = false
            w.center()
            prefsWindow = w
            // An account added in Terminal finishes while this window sits in the
            // background; re-read the status whenever it comes back to the front.
            NotificationCenter.default.addObserver(
                self, selector: #selector(prefsWindowBecameKey),
                name: NSWindow.didBecomeKeyNotification, object: w)
        }
        NSApp.activate(ignoringOtherApps: true)
        prefsWindow?.makeKeyAndOrderFront(nil)
    }

    @objc func prefsWindowBecameKey() { fetchAccountStatus() }

    @objc func openTui() {
        guard let tui = resolveBinary("ai-usagebar-tui") else { return }
        let p = Process()
        p.executableURL = URL(fileURLWithPath: "/usr/bin/osascript")
        p.arguments = ["-e", "tell application \"Terminal\" to do script \"\(tui)\""]
        try? p.run()
    }

    // Settings changed in Preferences: re-render instantly from cache, re-arm
    // the timer, and re-fetch (debounced) in case vendor/binary changed.
    @objc func settingsChanged() {
        if overviewVisibilityChangePending {
            overviewVisibilityChangePending = false
            if VENDOR == "overview", let ov = lastOverview { renderOverview(ov) }
            return
        }
        // The swap-shortcut toggle lives in defaults too; re-register only when
        // its state and the live registration disagree (avoids churn on every
        // vendor switch, which itself writes defaults).
        if DEF.bool(forKey: "swapShortcutEnabled") != (swapHotKeyRef != nil) {
            installSwapHotKey()
        }
        if DEF.bool(forKey: "compactShortcutEnabled") != (compactHotKeyRef != nil) {
            installCompactHotKey()
        }
        // A vendor swap re-fetches, which takes a moment; keeping the previous
        // vendor's view up reads as a freeze. Show a Loading placeholder at once.
        let vendorChanged = VENDOR != lastVendor
        lastVendor = VENDOR
        if vendorChanged {
            showLoading()
        } else if VENDOR == "overview" {
            if let ov = lastOverview { renderOverview(ov) }
        } else if let s = lastSnapshot {
            renderPanel(s); renderMenu(s)
        }
        restartTimer()
        pendingRefresh?.cancel()
        let work = DispatchWorkItem { [weak self] in self?.refresh() }
        pendingRefresh = work
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.6, execute: work)
    }

    /// Instant feedback for a vendor swap: replace the whole view with a Loading
    /// placeholder naming the target, until its data arrives.
    func showLoading() {
        lastSnapshot = nil
        lastOverview = nil
        let appearance = statusItem.button?.effectiveAppearance ?? NSApp.effectiveAppearance
        let name = entryDisplayName(VENDOR)
        statusItem.button?.attributedTitle = run("\(name) …", menuBarTextColor(appearance))
        headerItem.attributedTitle = run("\(name) · loading…", .labelColor,
                                         NSFont.boldSystemFont(ofSize: 13))
        for (_, it) in rows { it.isHidden = true }
        for it in overviewRows { it.isHidden = true }
        compactItem.isHidden = true
        rebuildVendorSubmenu()
    }

    func restartTimer() {
        timer?.invalidate()
        timer = Timer.scheduledTimer(withTimeInterval: INTERVAL, repeats: true) { [weak self] _ in
            self?.refresh()
        }
    }

    func observeAppearanceChanges() {
        guard let button = statusItem.button else { return }
        lastAppearanceName = button.effectiveAppearance.bestMatch(from: [.aqua, .darkAqua])
        appearanceObservation = button.observe(\NSStatusBarButton.effectiveAppearance,
                                               options: [.new]) { [weak self] btn, _ in
            // The KVO fires on every layout pass, not only on a real light↔dark
            // flip — and rendering (which relays out the button) would retrigger
            // it, spinning the main thread. Act only when the theme truly changes.
            let name = btn.effectiveAppearance.bestMatch(from: [.aqua, .darkAqua])
            DispatchQueue.main.async {
                guard let self, self.lastAppearanceName != name else { return }
                self.lastAppearanceName = name
                self.rerenderAppearance()
            }
        }
    }

    func rerenderAppearance() {
        // Appearance only changes colors; the configured-vendor set is unchanged,
        // so repaint without rebuilding the (subprocess-touching) submenu.
        if VENDOR == "overview", let ov = lastOverview { renderOverview(ov, rebuildSubmenu: false); return }
        guard let snapshot = lastSnapshot else { return }
        renderPanel(snapshot)
    }

    func refresh() {
        if let custom = refreshOverride {
            custom()
            return
        }
        if refreshInFlight {
            refreshQueued = true
            return
        }
        guard let bin = resolveBinary("ai-usagebar") else {
            setError("ai-usagebar not found (PATH / ~/.cargo/bin / homebrew)")
            return
        }
        refreshInFlight = true
        refreshGeneration += 1
        let generation = refreshGeneration
        // Captured for THIS attempt: reading `VENDOR` again on completion would
        // label a late result with whatever is selected by then.
        let vendor = VENDOR

        if vendor == "overview" {
            refreshOverview(bin: bin, generation: generation)
            return
        }

        DispatchQueue.global(qos: .utility).async { [weak self] in
            let p = Process()
            p.executableURL = URL(fileURLWithPath: bin)
            p.arguments = vendorArgs(for: vendor) + ["--format", FORMAT_WITH_SENTINEL]
            p.environment = subprocessEnvironment()
            let pipe = Pipe()
            p.standardOutput = pipe
            p.standardError = FileHandle.nullDevice

            // The subprocess takes the cache lock and may refresh OAuth over
            // the network; without a bound it can hold this worker for a very
            // long time. Kill it and report instead of hanging silently.
            let watchdog = DispatchWorkItem { if p.isRunning { p.terminate() } }
            DispatchQueue.global(qos: .utility)
                .asyncAfter(deadline: .now() + REFRESH_TIMEOUT, execute: watchdog)

            var out = ""
            do {
                try p.run()
                let data = pipe.fileHandleForReading.readDataToEndOfFile()  // read before wait
                p.waitUntilExit()
                out = String(data: data, encoding: .utf8) ?? ""
            } catch {
                watchdog.cancel()
                DispatchQueue.main.async {
                    self?.finishRefresh(generation) { $0.setError("could not run ai-usagebar") }
                }
                return
            }
            watchdog.cancel()
            let timedOut = out.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty
            DispatchQueue.main.async {
                self?.finishRefresh(generation) { me in
                    // Selection may have changed while this ran.
                    guard vendor == VENDOR else { return }
                    if timedOut {
                        me.setError("ai-usagebar demorou demais (>\(Int(REFRESH_TIMEOUT))s)")
                    } else {
                        me.consume(out)
                    }
                }
            }
        }
    }

    /// Applies `body` only when `generation` is still the current attempt, then
    /// releases the in-flight slot and runs any request that arrived meanwhile.
    private func finishRefresh(_ generation: Int, _ body: (AppDelegate) -> Void) {
        let current = generation == refreshGeneration
        if current {
            refreshInFlight = false
            body(self)
        }
        if current && refreshQueued {
            refreshQueued = false
            refresh()
        }
    }

    /// Overview mode: fetch every configured vendor and render one compact row
    /// each. Sequential on purpose — reads are cache-first, and serializing
    /// respects the per-vendor cache flock and avoids an OAuth-refresh 429 burst.
    /// ponytail: parallelize only if it ever feels slow.
    func refreshOverview(bin: String, generation: Int) {
        // vendorEntries(active: "") keeps only configured entries — the
        // active-vendor courtesy slot has no place in an all-vendors sweep.
        let entries = filterOverviewEntries(vendorEntries(
                                                active: "",
                                                usageAccounts: lastAccountStatus?.usageAccounts),
                                            requested: configuredOverviewVendorIds())
        DispatchQueue.global(qos: .utility).async { [weak self] in
            var results: [(name: String, id: String, snap: Snapshot?)] = []
            for v in entries {
                let p = Process()
                p.executableURL = URL(fileURLWithPath: bin)
                p.arguments = vendorArgs(for: v.id) + ["--format", FORMAT_WITH_SENTINEL]
                p.environment = subprocessEnvironment()
                let pipe = Pipe()
                p.standardOutput = pipe
                p.standardError = FileHandle.nullDevice
                let watchdog = DispatchWorkItem { if p.isRunning { p.terminate() } }
                DispatchQueue.global(qos: .utility)
                    .asyncAfter(deadline: .now() + REFRESH_TIMEOUT, execute: watchdog)
                var out = ""
                do {
                    try p.run()
                    let data = pipe.fileHandleForReading.readDataToEndOfFile()
                    p.waitUntilExit()
                    out = String(data: data, encoding: .utf8) ?? ""
                } catch { out = "" }
                watchdog.cancel()
                var snap: Snapshot?
                if let data = out.data(using: .utf8),
                   let obj = try? JSONSerialization.jsonObject(with: data) as? [String: Any],
                   let text = obj["text"] as? String {
                    snap = parse(text, vendor: baseVendorId(v.id))
                }
                results.append((name: v.name, id: v.id, snap: snap))
            }
            DispatchQueue.main.async {
                self?.finishRefresh(generation) { me in
                    guard VENDOR == "overview" else { return }
                    me.renderOverview(results)
                }
            }
        }
    }

    /// The single most-relevant number for a vendor in the overview.
    /// Cursor: the combined "included total usage" headline (both pools as one).
    /// Everyone else: the most-exhausted of its windows — for Anthropic that is
    /// the biggest of 5h, weekly, and the scoped model bar (Fable). Falls back to
    /// the $ budget when a vendor has no time windows.
    func overviewHeadline(_ s: Snapshot) -> (pct: Int, value: String, reset: String?, elapsed: Int?) {
        if let t = s.cursorTotalPct {
            return (t, "\(t)%", s.weekly?.reset ?? s.session?.reset, nil)
        }
        let windows = [s.session, s.weekly, s.sonnet, s.secondaryWeekly].compactMap { $0 }
        let finite = windows.filter { !$0.unlimited }
        if let w = finite.max(by: { $0.pct < $1.pct }) {
            return (w.pct, "\(w.pct)%", w.reset, w.elapsed)
        }
        if let w = windows.first(where: { $0.unlimited }) {
            return (0, "Unlimited", w.reset, nil)
        }
        if let e = s.extra { return (e.pct, "\(e.spent) / \(e.limit)", nil, nil) }
        return (0, "—", nil, nil)
    }

    /// Compact bar label for a vendor name. Usually the first word; for a
    /// Claude account ("Claude · gmail") the account label is the part that
    /// distinguishes entries, so use it instead of the shared "Claude".
    func ovLabel(_ name: String, _ maxLen: Int) -> String {
        let base = name.range(of: " · ").map { String(name[$0.upperBound...]) }
            ?? String(name.split(separator: " ").first ?? Substring(name))
        return base.count <= maxLen ? base : String(base.prefix(maxLen))
    }

    /// Status-bar summary for overview mode: every vendor at once. Mini bar per
    /// vendor when few; worst-first numbers (capped, with `+K` overflow) when
    /// many. Tunable via `[ui] overview_menubar_bars_max` (bar↔number threshold,
    /// default 4) and `overview_menubar_max` (how many numbers fit, default 4).
    func overviewBarTitle(_ items: [(name: String, id: String, snap: Snapshot?)],
                          _ appearance: NSAppearance) -> NSAttributedString {
        let secondary = menuBarTextColor(appearance, secondary: true)
        // Providers toggled off in the dropdown are dropped from the always-on
        // top summary (but still listed there so they can be re-enabled).
        let hidden = overviewHiddenProviders()
        let visible = Set(overviewVisibleIds(items.map { $0.id }, hidden: hidden))
        let heads: [(name: String, pct: Int, elapsed: Int?, value: String, reset: String?)] =
            items.compactMap {
                guard visible.contains($0.id), let s = $0.snap else { return nil }
                if let cb = s.creditBalance { return ($0.name, -1, nil, "cr \(cb)", nil) }
                let h = overviewHeadline(s)
                let shortValue = h.reset.flatMap(shortReset)
                let reset = h.reset.flatMap { resetClockLabel($0, fallback: shortValue) }
                return ($0.name, h.pct, h.elapsed, h.value, reset)
            }
        guard !heads.isEmpty else { return run("ovr", secondary) }

        let barsMax = Int(configValueTOML("ui", "overview_menubar_bars_max") ?? "") ?? 4
        let compact = DEF.bool(forKey: "overviewCompact")
        let t = NSMutableAttributedString()
        if overviewUsesBars(count: heads.count, barsMax: barsMax, compact: compact) {
            for (i, e) in heads.enumerated() {
                if i > 0 { t.append(run("   ", secondary)) }
                t.append(run("\(ovLabel(e.name, 6)) ", secondary))
                if e.pct >= 0 {
                    if e.value == "Unlimited" {
                        t.append(run("∞", hexColor(COLOR_LOW)))
                    } else {
                        t.append(run("\(e.pct)% ", colorForPct(e.pct)))
                        t.append(progressAttr(pct: e.pct, width: BAR_WIDTH, elapsed: e.elapsed,
                                              appearance: appearance))
                    }
                    if let r = e.reset { t.append(run(" \(r)", secondary)) }
                } else {
                    t.append(run(e.value, .labelColor))  // credit balance
                }
            }
        } else {
            let maxN = Int(configValueTOML("ui", "overview_menubar_max") ?? "") ?? 4
            // Entry order, not worst-first: entries are provider-grouped
            // (standard Claude, then its accounts, then the other vendors), and
            // stable positions beat a pct sort that reshuffles labels on every
            // refresh.
            for (i, e) in heads.prefix(maxN).enumerated() {
                if i > 0 { t.append(run("  ", secondary)) }
                t.append(run("\(ovLabel(e.name, 3)) ", secondary))
                if e.value == "Unlimited" {
                    t.append(run("∞", hexColor(COLOR_LOW)))
                } else {
                    t.append(run(e.value, e.pct >= 0 ? colorForPct(e.pct) : .labelColor))
                }
                if let r = e.reset { t.append(run(" \(r)", secondary)) }
            }
            if heads.count > maxN { t.append(run("  +\(heads.count - maxN)", secondary)) }
        }
        return t
    }

    func renderOverview(_ items: [(name: String, id: String, snap: Snapshot?)],
                        rebuildSubmenu: Bool = true) {
        lastSnapshot = nil
        lastOverview = items
        let appearance = statusItem.button?.effectiveAppearance ?? NSApp.effectiveAppearance
        headerItem.attributedTitle = run("Overview", .labelColor, NSFont.boldSystemFont(ofSize: 13))
        for key in ["session", "weekly", "sonnet", "extra"] { rows[key]?.isHidden = true }
        ensureOverviewRowCapacity(items.count)

        // Rows render in a monospaced font, so fixed character widths line the
        // columns up. Pre-compute the widest headline pct and reset so both can be
        // right-aligned — the reset then ends flush at the line's right edge.
        let nameW = 14
        var pctW = 0, resetW = 0
        for item in items.prefix(overviewRows.count) {
            guard let s = item.snap, s.creditBalance == nil else { continue }
            let h = overviewHeadline(s)
            pctW = max(pctW, h.value.count)
            if let r = h.reset, !r.isEmpty { resetW = max(resetW, r.count) }
        }
        func rpad(_ s: String, _ w: Int) -> String {
            String(repeating: " ", count: max(0, w - s.count)) + s
        }

        let hidden = overviewHiddenProviders()
        for (i, item) in items.enumerated() where i < overviewRows.count {
            let it = overviewRows[i]
            it.isHidden = false
            // Click a row to toggle whether this provider shows in the top-bar
            // summary. Checkmark = shown; unchecked + dimmed = hidden from the
            // bar (still listed here so it can be turned back on). Jump-to-vendor
            // moved to the "Switch provider" submenu and ⌥⌘\.
            let isHidden = hidden.contains(item.id)
            it.state = isHidden ? .off : .on
            it.representedObject = item.id
            it.target = self
            it.action = #selector(toggleOverviewProvider(_:))
            let a = NSMutableAttributedString()
            let fitted = item.name.count > nameW
                ? String(item.name.prefix(nameW - 1)) + "…"
                : item.name.padding(toLength: nameW, withPad: " ", startingAt: 0)
            a.append(run(fitted + " ", .labelColor))
            if let s = item.snap {
                if let cb = s.creditBalance {
                    a.append(run("cr \(cb)", .labelColor))
                } else {
                    let h = overviewHeadline(s)
                    if h.value == "Unlimited" {
                        a.append(run("Unlimited", hexColor(COLOR_LOW)))
                    } else {
                        a.append(progressAttr(pct: h.pct, width: MENU_BAR_W, elapsed: h.elapsed,
                                              menu: true, appearance: appearance))
                        a.append(run("  \(rpad(h.value, pctW))", colorForPct(h.pct)))
                    }
                    if let r = h.reset, !r.isEmpty {
                        a.append(run("   ↺ \(rpad(r, resetW))", .secondaryLabelColor))
                    }
                }
            } else {
                a.append(run("—", .secondaryLabelColor))
            }
            // Grey the whole row while hidden, so "off" reads at a glance.
            if isHidden {
                a.addAttribute(.foregroundColor, value: NSColor.tertiaryLabelColor,
                               range: NSRange(location: 0, length: a.length))
            }
            it.attributedTitle = a
        }
        for i in items.count..<overviewRows.count { overviewRows[i].isHidden = true }

        // Menu-bar title: every vendor at once (mini bars when few, numbers when
        // many). The dropdown always holds the full per-vendor list.
        statusItem.button?.attributedTitle = overviewBarTitle(items, appearance)
        compactItem.isHidden = false
        updateCompactItemTitle()
        if rebuildSubmenu { rebuildVendorSubmenu() }
    }

    /// Add overview row slots before the single-vendor rows when newly
    /// discovered Claude accounts outgrow the initial built-in-vendor pool.
    private func ensureOverviewRowCapacity(_ count: Int) {
        guard count > overviewRows.count,
              let menu = statusItem.menu,
              let firstDetail = rows["session"] else { return }
        while overviewRows.count < count {
            let item = NSMenuItem()
            item.isHidden = true
            menu.insertItem(item, at: menu.index(of: firstDetail))
            overviewRows.append(item)
        }
    }

    func consume(_ output: String) {
        guard let data = output.data(using: .utf8),
              let obj = try? JSONSerialization.jsonObject(with: data) as? [String: Any],
              let text = obj["text"] as? String else {
            setError("invalid output")
            return
        }
        guard let snap = parse(text, vendor: baseVendorId(VENDOR)) else {
            lastSnapshot = nil
            let appearance = statusItem.button?.effectiveAppearance ?? NSApp.effectiveAppearance
            statusItem.button?.attributedTitle = run(stripMarkup(text), menuBarTextColor(appearance))  // Loading… / ⚠
            let errorMsg = (obj["tooltip"] as? String).flatMap { $0.isEmpty ? nil : stripMarkup($0) }
                ?? "\(entryDisplayName(VENDOR)) · \(stripMarkup(text))"
            headerItem.attributedTitle = run(errorMsg, .labelColor, NSFont.boldSystemFont(ofSize: 13))
            return
        }
        lastSnapshot = snap
        renderPanel(snap)
        renderMenu(snap)
    }

    func renderPanel(_ s: Snapshot) {
        let title = NSMutableAttributedString()
        let appearance = statusItem.button?.effectiveAppearance ?? NSApp.effectiveAppearance
        let primaryTextColor = menuBarTextColor(appearance)
        let secondaryTextColor = menuBarTextColor(appearance, secondary: true)
        func seg(_ tag: String, _ w: Window) {
            if title.length > 0 { title.append(run("   ", secondaryTextColor)) }
            title.append(run("\(tag) ", secondaryTextColor))
            if w.unlimited {
                title.append(run("∞", hexColor(COLOR_LOW)))
                return
            }
            if SHOW_PERCENT { title.append(run("\(w.pct)%" + (SHOW_BARS ? " " : ""), colorForPct(w.pct))) }
            if SHOW_BARS { title.append(progressAttr(pct: w.pct, width: BAR_WIDTH, elapsed: w.elapsed, appearance: appearance)) }
            if !SHOW_PERCENT && !SHOW_BARS { title.append(run("\(w.pct)%", colorForPct(w.pct))) }
        }
        func segExtra(_ tag: String, _ pct: Int, _ value: String) {
            if title.length > 0 { title.append(run("   ", secondaryTextColor)) }
            title.append(run("\(tag) ", secondaryTextColor))
            if SHOW_PERCENT { title.append(run(value + (SHOW_BARS ? " " : ""), colorForPct(pct))) }
            if SHOW_BARS { title.append(progressAttr(pct: pct, width: BAR_WIDTH, elapsed: nil, appearance: appearance)) }
            if !SHOW_PERCENT && !SHOW_BARS { title.append(run(value, colorForPct(pct))) }
        }
        if let creditBalance = s.creditBalance {
            title.append(run("cr ", secondaryTextColor))
            title.append(run(creditBalance, primaryTextColor))
        } else {
            let hasFiniteSession = s.session.map { !$0.unlimited } ?? false
            let hasFiniteWeekly = s.weekly.map { !$0.unlimited } ?? false

            if s.hasUsageWindows && SHOW_SESSION, let session = s.session {
                if !session.unlimited || !hasFiniteWeekly {
                    seg(s.sessionTag, session)
                }
            }
            if s.hasUsageWindows && SHOW_WEEKLY, let weekly = s.weekly {
                if !weekly.unlimited || !hasFiniteSession {
                    seg(s.weeklyTag, weekly)
                }
            }
        }
        if SHOW_EXTRA, let e = s.extra { segExtra("ex", e.pct, e.spent) } // $ budget → no meta
        statusItem.button?.attributedTitle = title.length > 0 ? title : run("ai", secondaryTextColor)
    }

    func renderMenu(_ s: Snapshot) {
        let appearance = statusItem.button?.effectiveAppearance ?? NSApp.effectiveAppearance
        for it in overviewRows { it.isHidden = true }
        compactItem.isHidden = true
        // With several Claude accounts the plan alone ("Claude Max 20x") no
        // longer says WHICH account this is — suffix the label.
        let plan = s.plan.isEmpty ? "AI Usage" : s.plan
        let header = accountLabel(of: VENDOR).map { "\(plan) · \($0)" } ?? plan
        headerItem.attributedTitle = run(header, .labelColor, NSFont.boldSystemFont(ofSize: 13))

        let labelWidth = menuLabelWidth([
            s.session == nil ? nil : s.sessionLabel,
            s.weekly == nil ? nil : s.weeklyLabel,
            s.sonnet == nil ? nil : s.sonnetLabel,
            s.secondaryWeekly == nil ? nil : s.secondaryWeeklyLabel,
        ].compactMap { $0 })
        let pctWidth = [s.session, s.weekly, s.sonnet, s.secondaryWeekly]
            .compactMap { $0 }.map { "\($0.pct)%".count }.max() ?? 0
        func row(_ key: String, _ name: String, _ pct: Int, _ value: String, _ reset: String?, _ elapsed: Int?, unlimited: Bool = false) {
            guard let item = rows[key] else { return }
            item.isHidden = false
            let a = NSMutableAttributedString()
            let label = name.padding(toLength: max(labelWidth, name.count), withPad: " ", startingAt: 0)
            a.append(run(label, .labelColor))
            if unlimited {
                a.append(run("Unlimited", hexColor(COLOR_LOW)))
            } else {
                a.append(progressAttr(pct: pct, width: MENU_BAR_W, elapsed: elapsed, menu: true, appearance: appearance))
                a.append(run("  \(rightAligned(value, width: pctWidth))", colorForPct(pct)))
                if let r = reset, !r.isEmpty, let display = resetClockLabel(r, fallback: r) {
                    a.append(run("   ↺ \(display)", .secondaryLabelColor))
                }
            }
            item.attributedTitle = a
        }
        if let creditBalance = s.creditBalance {
            rows["session"]?.isHidden = false
            rows["session"]?.attributedTitle = run("Credits      \(creditBalance)", .labelColor)
            rows["weekly"]?.isHidden = true
            rows["sonnet"]?.isHidden = true
        } else {
            if s.hasUsageWindows, let session = s.session {
                row("session", s.sessionLabel, session.pct, "\(session.pct)%", session.reset, session.elapsed, unlimited: session.unlimited)
            } else { rows["session"]?.isHidden = true }
            if s.hasUsageWindows, let weekly = s.weekly {
                row("weekly", s.weeklyLabel, weekly.pct, "\(weekly.pct)%", weekly.reset, weekly.elapsed, unlimited: weekly.unlimited)
            } else { rows["weekly"]?.isHidden = true }
        }
        if let sn = s.sonnet {
            row("sonnet", s.sonnetLabel, sn.pct, "\(sn.pct)%", sn.reset, sn.elapsed, unlimited: sn.unlimited)
        } else {
            rows["sonnet"]?.isHidden = true
        }
        if let weekly = s.secondaryWeekly {
            row("extra", s.secondaryWeeklyLabel, weekly.pct, "\(weekly.pct)%", weekly.reset, weekly.elapsed, unlimited: weekly.unlimited)
        } else if let e = s.extra {
            row("extra", "Extra usage", e.pct, "\(e.spent) / \(e.limit)", nil, nil)
        } else {
            rows["extra"]?.isHidden = true
        }
        rebuildVendorSubmenu()
    }

    // Vendor switch submenu: lists only configured vendors, with a checkmark on
    // the active one. Selecting one rewrites the `vendor` default and triggers a
    // refresh via the shared settings-change observer.
    func rebuildVendorSubmenu() {
        vendorSubmenu.removeAllItems()
        let active = VENDOR
        let entries = vendorEntries(active: active,
                                    usageAccounts: lastAccountStatus?.usageAccounts)
        if entries.isEmpty {
            let none = NSMenuItem(title: "None configured", action: nil, keyEquivalent: "")
            none.isEnabled = false
            vendorSubmenu.addItem(none)
            vendorSubmenuItem.isHidden = false
            return
        }
        for v in entries {
            let it = NSMenuItem(title: v.name, action: #selector(switchVendor(_:)), keyEquivalent: "")
            it.target = self
            it.representedObject = v.id
            it.state = (v.id == active) ? .on : .off
            vendorSubmenu.addItem(it)
        }
        // Synthetic overview target — same one the ⌥⌘\ ring ends on.
        vendorSubmenu.addItem(.separator())
        let ov = NSMenuItem(title: "Overview", action: #selector(switchVendor(_:)), keyEquivalent: "")
        ov.target = self
        ov.representedObject = "overview"
        ov.state = (active == "overview") ? .on : .off
        vendorSubmenu.addItem(ov)
        vendorSubmenuItem.isHidden = false
    }

    @objc func switchVendor(_ sender: NSMenuItem) {
        guard let id = sender.representedObject as? String else { return }
        DEF.set(id, forKey: "vendor")
    }

    /// Ask the binary who each surface is signed in as. Same off-main shape as
    /// `refresh()`; failures leave `lastAccountStatus` alone so a transient
    /// hiccup doesn't blank a working menu.
    func fetchAccountStatus() {
        guard let bin = resolveBinary("ai-usagebar") else { return }
        accountStatusFetchedAt = Date()
        accountStatusGeneration += 1
        let generation = accountStatusGeneration
        DispatchQueue.global(qos: .utility).async { [weak self] in
            let p = Process()
            p.executableURL = URL(fileURLWithPath: bin)
            p.arguments = ["account", "status", "--json"]
            p.environment = subprocessEnvironment()
            let pipe = Pipe()
            p.standardOutput = pipe
            p.standardError = FileHandle.nullDevice

            let watchdog = DispatchWorkItem { if p.isRunning { p.terminate() } }
            DispatchQueue.global(qos: .utility)
                .asyncAfter(deadline: .now() + REFRESH_TIMEOUT, execute: watchdog)
            var data = Data()
            do {
                try p.run()
                data = pipe.fileHandleForReading.readDataToEndOfFile()  // read before wait
                p.waitUntilExit()
            } catch {
                watchdog.cancel()
                return
            }
            watchdog.cancel()
            guard let status = parseAccountStatus(data) else { return }
            DispatchQueue.main.async {
                guard let me = self, generation == me.accountStatusGeneration else { return }
                me.applyAccountStatus(status)
            }
        }
    }

    func applyAccountStatus(_ status: AccountStatus) {
        lastAccountStatus = status
        renderAccountMenus()
        rebuildVendorSubmenu()
    }

    func renderAccountMenus() {
        accounts.status = lastAccountStatus
        accounts.switching = accountSwitchInFlight
        // Nil means the binary predates the subcommand: leave the menu exactly
        // as it was before this feature existed.
        guard let status = lastAccountStatus else {
            accountsInfoItem.isHidden = true
            return
        }
        let line = accountsSummaryLine(status)
        accountsInfoItem.isHidden = line.isEmpty
        accountsInfoItem.attributedTitle = run(line, .secondaryLabelColor)
    }

    /// Ask for a label, then hand the interactive part to Terminal: a Desktop
    /// capture waits for a browser sign-in, a CLI one runs `claude`. Neither
    /// belongs in a background subprocess the user cannot see or answer.
    func addAccount(desktop: Bool) {
        guard let bin = resolveBinary("ai-usagebar") else { return }
        let alert = NSAlert()
        alert.messageText = desktop ? "Add a Claude Desktop account"
                                    : "Add a Claude Code account"
        alert.informativeText = desktop
            ? "Choose a name. The app will quit and reopen at its login screen so you can "
                + "sign in as the new account; the current one is restored if you cancel."
            : "Choose a name. `claude` opens in Terminal for you to sign in; your default "
                + "login is left alone."
        let field = NSTextField(frame: NSRect(x: 0, y: 0, width: 220, height: 24))
        field.placeholderString = "work"
        alert.accessoryView = field
        alert.addButton(withTitle: "Continue")
        alert.addButton(withTitle: "Cancel")
        NSApp.activate(ignoringOtherApps: true)
        alert.window.initialFirstResponder = field
        guard alert.runModal() == .alertFirstButtonReturn else { return }
        let label = field.stringValue.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !label.isEmpty else { return }
        runInTerminal(addAccountScript(binary: bin, label: label, desktop: desktop))
    }

    /// Quits and reopens Claude.app, so confirm first — an unsent message or an
    /// in-flight Cowork run would go with it. The CLI switch has no visible
    /// side effect and needs no prompt.
    func switchDesktopAccount(to label: String) {
        let alert = NSAlert()
        alert.messageText = "Switch the Claude Desktop account to “\(label)”?"
        alert.informativeText = "The app will quit and reopen. Your local history is merged into that "
            + "account before the switch, and a backup is written."
        alert.addButton(withTitle: "Switch and restart")
        alert.addButton(withTitle: "Cancel")
        NSApp.activate(ignoringOtherApps: true)
        guard alert.runModal() == .alertFirstButtonReturn else { return }
        // Routines deleted in one account but alive in another would be handed
        // straight back by the merge. Decide before the switch starts, since a
        // background subprocess has no way to ask.
        guard let doomed = resolveDeletionConflicts() else { return }
        runAccountSwitch(label: label, desktop: true, deleting: doomed)
    }

    /// Returns the routine ids to delete everywhere, or nil if the user backed
    /// out of the whole switch. An empty array means "keep them all".
    private func resolveDeletionConflicts() -> [String]? {
        let conflicts = lastAccountStatus?.deletionConflicts ?? []
        if conflicts.isEmpty { return [] }

        let alert = NSAlert()
        alert.messageText = conflicts.count == 1
            ? "1 item was deleted in one account and still exists in another"
            : "\(conflicts.count) items were deleted in one account and still exist in another"
        alert.informativeText = conflictPreview(conflicts)
            + "\n\nKeeping restores the deleted ones. Deleting removes them from every account — a chat loses only its index, the transcript stays."
        alert.addButton(withTitle: "Keep all")
        alert.addButton(withTitle: "Delete everywhere")
        alert.addButton(withTitle: "Choose…")
        NSApp.activate(ignoringOtherApps: true)
        switch alert.runModal() {
        case .alertFirstButtonReturn: return []
        case .alertSecondButtonReturn: return conflicts.map { $0.key }
        default: return chooseDeletionConflicts(conflicts)
        }
    }

    /// A checkbox per conflict — checked means keep. Everything left unchecked
    /// is deleted everywhere, so the destructive outcome takes a deliberate
    /// uncheck rather than being the default.
    private func chooseDeletionConflicts(_ conflicts: [DeletionConflict]) -> [String]? {
        let rowHeight = 22
        let list = NSStackView(frame: NSRect(x: 0, y: 0, width: 420,
                                             height: rowHeight * conflicts.count))
        list.orientation = .vertical
        list.alignment = .leading
        list.spacing = 4
        var boxes: [NSButton] = []
        for conflict in conflicts {
            let box = NSButton(checkboxWithTitle: conflict.line, target: nil, action: nil)
            box.state = .on
            boxes.append(box)
            list.addArrangedSubview(box)
        }
        let scroll = NSScrollView(frame: NSRect(x: 0, y: 0, width: 420,
                                                height: min(260, rowHeight * conflicts.count + 8)))
        scroll.hasVerticalScroller = true
        scroll.documentView = list

        let alert = NSAlert()
        alert.messageText = "What should be kept?"
        alert.informativeText = "Checked items stay. Unchecked ones are deleted in every account."
        alert.accessoryView = scroll
        alert.addButton(withTitle: "Confirm")
        alert.addButton(withTitle: "Cancel")
        NSApp.activate(ignoringOtherApps: true)
        guard alert.runModal() == .alertFirstButtonReturn else { return nil }
        return zip(conflicts, boxes).filter { $0.1.state != .on }.map { $0.0.key }
    }

    func switchCliAccount(to label: String) {
        runAccountSwitch(label: label, desktop: false)
    }

    private func runAccountSwitch(label: String, desktop: Bool, deleting: [String] = []) {
        guard let bin = resolveBinary("ai-usagebar"), !accountSwitchInFlight else { return }
        accountSwitchInFlight = true
        renderAccountMenus()
        let args = switchArgs(label: label, desktop: desktop, deleting: deleting)
        DispatchQueue.global(qos: .utility).async { [weak self] in
            let p = Process()
            p.executableURL = URL(fileURLWithPath: bin)
            p.arguments = args
            p.environment = subprocessEnvironment()
            let pipe = Pipe()
            p.standardOutput = pipe
            p.standardError = pipe
            let failure: String?
            do {
                try p.run()
                let data = pipe.fileHandleForReading.readDataToEndOfFile()
                p.waitUntilExit()
                if p.terminationStatus != 0 {
                    let detail = String(decoding: data, as: UTF8.self)
                        .trimmingCharacters(in: .whitespacesAndNewlines)
                    failure = detail.isEmpty
                        ? "ai-usagebar exited with status \(p.terminationStatus)."
                        : String(detail.prefix(2_000))
                } else {
                    failure = nil
                }
            } catch {
                failure = "Could not start ai-usagebar: \(error.localizedDescription)"
            }
            DispatchQueue.main.async {
                guard let me = self else { return }
                me.accountSwitchInFlight = false
                me.fetchAccountStatus()
                if let failure {
                    let alert = NSAlert()
                    alert.alertStyle = .warning
                    alert.messageText = "Could not switch account"
                    alert.informativeText = failure
                    alert.addButton(withTitle: "OK")
                    NSApp.activate(ignoringOtherApps: true)
                    alert.runModal()
                } else {
                    // The usage numbers belong to whoever is signed in now.
                    me.refresh()
                }
            }
        }
    }

    /// Toggle whether a provider appears in the Overview top-bar summary, from
    /// its dropdown row. The UserDefaults observer re-renders from the last
    /// fetch and consumes this presentation-only change without re-fetching.
    @objc func toggleOverviewProvider(_ sender: NSMenuItem) {
        guard let id = sender.representedObject as? String else { return }
        overviewVisibilityChangePending = true
        setOverviewProvider(id, hidden: !overviewHiddenProviders().contains(id))
    }

    func setError(_ msg: String) {
        lastSnapshot = nil
        statusItem.button?.attributedTitle = run("⚠ ai", hexColor(COLOR_CRITICAL))
        let appearance = statusItem.button?.effectiveAppearance ?? NSApp.effectiveAppearance
        headerItem.attributedTitle = run(msg, menuBarTextColor(appearance))
        for (_, it) in rows { it.isHidden = true }
        for it in overviewRows { it.isHidden = true }
        compactItem.isHidden = true
        accountsInfoItem.isHidden = true
    }
}

#if !SWIFT_TEST_HARNESS
@main
struct AppMain {
    // NSApplication.delegate is `weak`; in optimized (-O) builds ARC can free a
    // main()-local delegate before app.run() returns since it sees no later
    // textual use, taking the status item down with it — the menu bar icon
    // vanishes, intermittently, mid-session. Retain it here instead.
    static var delegate: AppDelegate!

    static func main() {
        DEF.register(defaults: SETTINGS_DEFAULTS)
        let app = NSApplication.shared
        delegate = AppDelegate()
        app.delegate = delegate
        app.setActivationPolicy(.accessory)   // menu-bar agent, no Dock icon
        app.run()
    }
}
#endif
